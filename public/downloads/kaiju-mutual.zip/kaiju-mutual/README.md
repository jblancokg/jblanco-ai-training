# Kaiju Mutual

Insurance for kaiju attacks. A training codebase for learning to work with AI agents.

Not sure how to get started? Ask your agent.
