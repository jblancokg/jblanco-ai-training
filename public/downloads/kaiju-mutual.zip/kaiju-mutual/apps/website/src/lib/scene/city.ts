import {
  BoxGeometry,
  Color,
  DoubleSide,
  Group,
  InstancedMesh,
  Matrix4,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  PlaneGeometry,
  Quaternion,
  Vector3,
} from 'three'

const CELL = 1.7
const AVENUE_HALF_WIDTH = 2.4
const X_RANGE = 14
const Z_NEAR = 10
const Z_FAR = -44
const ROWS = Math.round((Z_NEAR - Z_FAR) / CELL)
const COLLAPSE_SECONDS = 0.8

export type Building = { x: number; z: number; w: number; d: number; h: number }

export type City = {
  group: Group
  /**
   * Collapse every standing building within `radius` of (x, z). Returns the ones that
   * just started falling so the caller can add dust and shake.
   */
  crush(x: number, z: number, radius: number, now: number): Building[]
  /** Animate collapses in progress. `now` is seconds on the same clock as `crush`. */
  update(now: number): void
  /** Put every building back. */
  reset(): void
  dispose(): void
}

function layout(random: () => number, avenueX: number): Building[] {
  const buildings: Building[] = []
  for (let row = 0; row < ROWS; row++) {
    const z = Z_NEAR - row * CELL
    for (let x = -X_RANGE; x <= X_RANGE; x += CELL) {
      if (Math.abs(x - avenueX) < AVENUE_HALF_WIDTH) continue
      if (random() < 0.12) continue
      const tower = random() < 0.08
      const h = tower ? 3.2 + random() * 2 : 0.5 + random() * 1.9
      const w = 0.9 + random() * 0.5
      const d = 0.9 + random() * 0.5
      buildings.push({ x: x + (random() - 0.5) * 0.3, z, w, d, h })
    }
  }
  return buildings
}

function seeded(seed: number): () => number {
  let s = seed
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296
    return s / 4294967296
  }
}

const easeOut = (p: number) => 1 - (1 - p) ** 3

export function createCity(avenueX: number): City {
  const group = new Group()
  const random = seeded(7)
  const buildings = layout(random, avenueX)

  const block = new BoxGeometry(1, 1, 1).translate(0, 0.5, 0)
  const blockMaterial = new MeshStandardMaterial({ color: new Color('#1b2b3f'), roughness: 0.95 })
  const blocks = new InstancedMesh(block, blockMaterial, buildings.length)
  const up = new Quaternion()
  const m = new Matrix4()
  const standing = buildings.map((b) =>
    new Matrix4().compose(new Vector3(b.x, 0, b.z), up, new Vector3(b.w, b.h, b.d)),
  )
  group.add(blocks)

  // Lit windows: small emissive panes on the face of each building that looks onto the avenue.
  const pane = new BoxGeometry(0.1, 0.14, 0.02)
  const sideways = new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), Math.PI / 2)
  const one = new Vector3(1, 1, 1)
  const windows: Matrix4[] = []
  const windowsOf: number[][] = []
  buildings.forEach((b, i) => {
    const facing = b.x < avenueX ? 1 : -1
    const faceX = b.x + (facing * b.w) / 2 + facing * 0.01
    const floors = Math.floor(b.h / 0.34)
    const cols = Math.max(1, Math.floor(b.d / 0.32))
    const mine: number[] = []
    for (let f = 0; f < floors; f++) {
      for (let c = 0; c < cols; c++) {
        if (random() < 0.55) continue
        const y = 0.22 + f * 0.34
        const z = b.z - b.d / 2 + 0.16 + c * 0.32
        mine.push(windows.length)
        windows.push(new Matrix4().compose(new Vector3(faceX, y, z), sideways, one))
      }
    }
    windowsOf[i] = mine
  })
  const paneMaterial = new MeshBasicMaterial({ color: new Color('#ffd27a') })
  const panes = new InstancedMesh(pane, paneMaterial, windows.length)
  const dark = new Matrix4().makeScale(0, 0, 0)
  group.add(panes)

  const groundGeometry = new PlaneGeometry(80, 140)
  const groundMaterial = new MeshStandardMaterial({
    color: new Color('#0c1521'),
    roughness: 1,
    side: DoubleSide,
  })
  const ground = new Mesh(groundGeometry, groundMaterial)
  ground.rotation.x = -Math.PI / 2
  ground.position.z = -20
  group.add(ground)

  // Per-building collapse state: when it started, and which way it leans.
  const fallStart = new Float64Array(buildings.length).fill(-1)
  const lean = buildings.map(() => new Quaternion())
  const falling = new Set<number>()

  const reset = () => {
    fallStart.fill(-1)
    falling.clear()
    standing.forEach((matrix, i) => {
      blocks.setMatrixAt(i, matrix)
    })
    windows.forEach((matrix, i) => {
      panes.setMatrixAt(i, matrix)
    })
    blocks.instanceMatrix.needsUpdate = true
    panes.instanceMatrix.needsUpdate = true
  }
  reset()

  return {
    group,
    crush(x, z, radius, now) {
      const hit: Building[] = []
      buildings.forEach((b, i) => {
        if (fallStart[i] >= 0) return
        if ((b.x - x) ** 2 + (b.z - z) ** 2 > radius * radius) return
        fallStart[i] = now
        falling.add(i)
        const away = new Vector3(b.x - x, 0, b.z - z).normalize()
        const axis = new Vector3(away.z, 0, -away.x)
        lean[i].setFromAxisAngle(axis, 0.35 + random() * 0.3)
        for (const w of windowsOf[i] ?? []) panes.setMatrixAt(w, dark)
        panes.instanceMatrix.needsUpdate = true
        hit.push(b)
      })
      return hit
    },
    update(now) {
      if (falling.size === 0) return
      for (const i of falling) {
        const b = buildings[i]
        const p = Math.min((now - fallStart[i]) / COLLAPSE_SECONDS, 1)
        const e = easeOut(p)
        up.slerpQuaternions(new Quaternion(), lean[i], e)
        m.compose(
          new Vector3(b.x, -b.h * 0.15 * e, b.z),
          up,
          new Vector3(b.w, b.h * (1 - 0.8 * e), b.d),
        )
        blocks.setMatrixAt(i, m)
        if (p >= 1) falling.delete(i)
      }
      blocks.instanceMatrix.needsUpdate = true
    },
    reset,
    dispose() {
      block.dispose()
      pane.dispose()
      groundGeometry.dispose()
      blockMaterial.dispose()
      paneMaterial.dispose()
      groundMaterial.dispose()
    },
  }
}
