// The one quote modal lives in the layout; buttons open it through here.
// See docs/training/website.md.

export const planNames = ['Household', 'Business', 'Municipal'] as const
export type PlanName = (typeof planNames)[number]

// `plan` is null for a button with no plan preference.
export const quoteModal = $state<{ open: boolean; plan: PlanName | null }>({
  open: false,
  plan: null,
})

export function openQuote(plan: PlanName | null = null) {
  quoteModal.plan = plan
  quoteModal.open = true
}

export function closeQuote() {
  quoteModal.open = false
}
