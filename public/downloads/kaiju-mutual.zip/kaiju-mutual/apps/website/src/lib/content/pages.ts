export type Limit = {
  peril: string
  household: string
  business: string
  municipal: string
}

export const limits: Limit[] = [
  {
    peril: 'Structural damage',
    household: 'Rebuild cost',
    business: 'Rebuild cost',
    municipal: 'Negotiated',
  },
  {
    peril: 'Thermal and breath weapons',
    household: 'Rebuild cost',
    business: 'Rebuild cost',
    municipal: 'Negotiated',
  },
  {
    peril: 'Debris and falling objects',
    household: '$1m',
    business: '$5m',
    municipal: 'Negotiated',
  },
  {
    peril: 'Evacuation and temporary housing',
    household: '90 days',
    business: '6 months interruption',
    municipal: 'Shelter operations',
  },
  {
    peril: 'Contents and vehicles',
    household: '$250k',
    business: 'Replacement value',
    municipal: 'Fleet and plant',
  },
]

export const exclusions = [
  'Damage you cause while attempting to fight, capture or feed a kaiju.',
  'Anything built, bought or parked in a district after a warning was issued for it.',
  'Losses from kaiju you were keeping. Pet cover is a separate product and we are not proud of it.',
  'Radiation cleanup beyond what the civic response covers.',
]

export const duringAttack = [
  'Go to the nearest marked shelter. Underground car parks count. Bridges do not.',
  'Leave vehicles. A car is $30k. It is also a projectile.',
  'Do not film from your balcony. Assessors use city sensors, not your footage.',
  'If you are more than 2 km from the creature, you are outside the stomp radius. Keep it that way.',
]

export const afterAttack = [
  'Wait for the district all-clear. Structures can fall for hours after the kaiju has gone.',
  'Start your claim from the portal. A photo of the front of your building is enough to begin.',
  'Book temporary housing anywhere. Keep receipts. We reimburse the same day.',
  'An assessor contacts you within 48 hours to arrange a visit.',
]

export const figures = [
  { value: '1961', label: 'Founded by 40 harbour-front businesses' },
  { value: '1.2 million', label: 'Households insured' },
  { value: '90,000', label: 'Businesses insured' },
  { value: '212', label: 'Kaiju events paid out, none disputed' },
]

export const about = [
  'Kaiju Mutual was formed in 1961 by 40 harbour-front businesses who could not get anyone else to insure them. It is still a mutual: policyholders own it, and profits go into lower premiums and a bigger response fleet.',
  'We insure 1.2 million households and 90,000 businesses in 14 coastal cities. We have paid out on 212 declared kaiju events and disputed none of them on the grounds that a kaiju was not, in fact, a kaiju.',
  'Our assessors are engineers first. Most came from bridge inspection, demolition or the civic response corps, which is where you learn what a footprint does to a foundation.',
]
