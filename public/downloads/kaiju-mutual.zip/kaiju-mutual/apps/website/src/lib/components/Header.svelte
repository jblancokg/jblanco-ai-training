<script lang="ts">
import { links, nav } from '$lib/content/links'
import { openQuote } from '$lib/quote.svelte'

let { overlay = false }: { overlay?: boolean } = $props()
</script>

<header class="header" class:header--overlay={overlay}>
  <div class="wrap header__row">
    <a class="brand" href="/">
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
        <path d="M14 2 L26 8 V15 C26 21 20 25 14 27 C8 25 2 21 2 15 V8 Z" fill="currentColor" />
        <path d="M9 12 L14 8 L19 12 L17 19 L11 19 Z" fill="var(--siren)" />
      </svg>
      <span>Kaiju Mutual</span>
    </a>
    <nav class="nav" aria-label="Main">
      {#each nav as item}
        <a href={item.href}>{item.label}</a>
      {/each}
      <a class="nav__portal" href={links.portal}>Sign in</a>
    </nav>
    <button type="button" class="button header__cta" onclick={() => openQuote()}>
      Get a quote
    </button>
  </div>
</header>

<style>
  .header {
    padding-block: 1.1rem;
    color: var(--ink);
  }
  .header--overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 2;
    color: var(--paper);
  }
  .header__row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 1rem 2rem;
  }
  .brand {
    display: inline-flex;
    align-items: center;
    gap: 0.6rem;
    font-weight: 800;
    font-size: 1.2rem;
    letter-spacing: -0.02em;
    text-decoration: none;
  }
  .nav {
    display: flex;
    flex-basis: 100%;
    order: 3;
    gap: 1.25rem;
    font-weight: 500;
  }
  .nav a {
    text-decoration: none;
  }
  .nav a:hover {
    text-decoration: underline;
  }
  .nav__portal {
    opacity: 0.75;
  }
  .header__cta {
    margin-left: auto;
    padding: 0.65em 1.2em;
  }
  @media (min-width: 760px) {
    .nav {
      flex-basis: auto;
      order: 0;
      gap: 1.75rem;
      margin-left: auto;
    }
    .header__cta {
      margin-left: 0;
    }
  }
</style>
