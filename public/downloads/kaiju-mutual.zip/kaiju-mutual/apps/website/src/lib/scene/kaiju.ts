import type { Euler, Group, Object3D } from 'three'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'

// Names come from the Blender script at tools/kaiju.py. Each part's origin is its joint.
// GLTFLoader strips dots from node names, which is why the script avoids them.
const partNames = [
  'Hips',
  'Chest',
  'Head',
  'Jaw',
  'ArmL',
  'ArmR',
  'LegL',
  'LegR',
  'Tail0',
  'Tail1',
  'Tail2',
  'Tail3',
] as const

type PartName = (typeof partNames)[number]
type Parts = Record<PartName, Object3D>

export type Pose = {
  /** Seconds. Drives the stride and the idle motion. */
  t: number
  /** 0 = standing still, 1 = full walk. */
  stride: number
  /** 0 = mouth closed, 1 = full roar. */
  roar: number
}

export type KaijuRig = {
  root: Group
  pose(pose: Pose): void
}

/** Strides per second. Slow and heavy. Tuned against the walk distance in scene.ts. */
export const STRIDE_HZ = 0.4
const SWING = 0.34

export async function loadKaiju(url: string): Promise<KaijuRig> {
  const gltf = await new GLTFLoader().loadAsync(url)
  const root = gltf.scene

  const parts = {} as Parts
  for (const name of partNames) {
    const part = root.getObjectByName(name)
    if (!part) throw new Error(`kaiju model is missing part "${name}"`)
    parts[name] = part
  }

  const rest = {} as Record<PartName, Euler>
  for (const name of partNames) rest[name] = parts[name].rotation.clone()
  const hipsY = parts.Hips.position.y
  const legY = { L: parts.LegL.position.y, R: parts.LegR.position.y }
  const tail = [parts.Tail0, parts.Tail1, parts.Tail2, parts.Tail3]

  return {
    root,
    pose({ t, stride, roar }) {
      const phase = t * STRIDE_HZ * Math.PI * 2
      const swing = Math.sin(phase) * stride
      const lift = Math.cos(phase) * stride
      const stomp = Math.abs(Math.sin(phase)) * stride

      // A leg lifts while it swings forward, so the planted foot is the one moving back.
      parts.LegL.rotation.x = rest.LegL.x + swing * SWING
      parts.LegR.rotation.x = rest.LegR.x - swing * SWING
      parts.LegL.position.y = legY.L + Math.max(0, lift) * 0.3
      parts.LegR.position.y = legY.R + Math.max(0, -lift) * 0.3
      parts.ArmL.rotation.x = rest.ArmL.x - swing * 0.25 - roar * 0.9
      parts.ArmR.rotation.x = rest.ArmR.x + swing * 0.25 - roar * 0.9

      parts.Hips.position.y = hipsY + stomp * 0.12
      parts.Hips.rotation.z = rest.Hips.z + swing * 0.05
      parts.Hips.rotation.y = rest.Hips.y + swing * 0.1
      parts.Chest.rotation.y = rest.Chest.y - swing * 0.14
      parts.Chest.rotation.x = rest.Chest.x + Math.sin(phase * 2) * 0.03 * stride - roar * 0.12

      parts.Head.rotation.y = rest.Head.y + Math.sin(t * 0.6) * 0.22 * (1 - roar)
      parts.Head.rotation.x = rest.Head.x + Math.sin(phase * 2 + 1) * 0.04 * stride - roar * 0.55
      const chew = (0.5 + 0.5 * Math.sin(t * 0.9)) * 0.18
      parts.Jaw.rotation.x = rest.Jaw.x + chew * (1 - roar) + roar * 0.6

      tail.forEach((segment, i) => {
        const name = `Tail${i}` as PartName
        segment.rotation.y = rest[name].y + Math.sin(phase - i * 0.7) * 0.2 * (0.3 + 0.7 * stride)
      })
    },
  }
}
