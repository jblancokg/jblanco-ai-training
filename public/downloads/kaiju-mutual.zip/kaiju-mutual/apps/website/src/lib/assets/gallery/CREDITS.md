# Gallery photos

Photos for an about page gallery. Nothing uses them yet.

All are from Wikimedia Commons under the licence shown. CC BY and CC BY-SA need the photographer credited wherever the photo is shown.

| File | Photographer | Licence | Source |
| --- | --- | --- | --- |
| gamera-king-kong.jpg | Todd Murray from Bloomington, MN, USA | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0) | [Gamera-King Kong-20070707.jpg](https://commons.wikimedia.org/wiki/File:Gamera-King_Kong-20070707.jpg) |
| godzilla-plaque.jpg | Michael Ocampo from United States | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0) | [矢口 蘭堂 (30647012357).jpg](https://commons.wikimedia.org/wiki/File:%E7%9F%A2%E5%8F%A3_%E8%98%AD%E5%A0%82_(30647012357).jpg) |
| godzilla-square.jpg | Wpcpey | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Godzilla Square 2018.jpg](https://commons.wikimedia.org/wiki/File:Godzilla_Square_2018.jpg) |
| godzilla-street.jpg | Kakidai | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Shinjuku Toho Building from Godzilla Street.jpg](https://commons.wikimedia.org/wiki/File:Shinjuku_Toho_Building_from_Godzilla_Street.jpg) |
| kabukicho-cinema.jpg | Suginami | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [歌舞伎町TOHOシネマズのゴジラ.jpg](https://commons.wikimedia.org/wiki/File:%E6%AD%8C%E8%88%9E%E4%BC%8E%E7%94%BATOHO%E3%82%B7%E3%83%8D%E3%83%9E%E3%82%BA%E3%81%AE%E3%82%B4%E3%82%B8%E3%83%A9.jpg) |
| mardi-gras-godzilla.jpg | Infrogmation of New Orleans | [CC BY 2.5](https://creativecommons.org/licenses/by/2.5) | [MGD01GodzillaPereAntoine.jpg](https://commons.wikimedia.org/wiki/File:MGD01GodzillaPereAntoine.jpg) |
| shinjuku-rooftop.jpg | Stephen Kelly from San Francisco, CA, USA | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0) | [Godzilla in Shinjuku (53416845058).jpg](https://commons.wikimedia.org/wiki/File:Godzilla_in_Shinjuku_(53416845058).jpg) |
| unicorn-gundam.jpg | Pelpinosas R. Justin James | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [Life-Sized Unicorn Gundam Statue.jpg](https://commons.wikimedia.org/wiki/File:Life-Sized_Unicorn_Gundam_Statue.jpg) |
