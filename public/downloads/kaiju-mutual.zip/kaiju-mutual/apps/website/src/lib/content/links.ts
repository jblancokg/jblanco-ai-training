import { env } from '$env/dynamic/public'

// The portals run on their own origins in dev. See docs/training/apps.md.
const portal = env.PUBLIC_CONSUMER_PORTAL_URL || 'http://localhost:5174'

export const links = {
  portal,
  claim: `${portal}/claims/new`,
} as const

export const nav = [
  { href: '/coverage', label: 'Coverage' },
  { href: '/claims', label: 'Claims' },
  { href: '/about', label: 'About' },
] as const
