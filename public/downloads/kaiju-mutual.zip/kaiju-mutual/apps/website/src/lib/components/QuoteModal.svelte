<script lang="ts">
import { closeQuote, type PlanName, planNames, quoteModal } from '$lib/quote.svelte'

type Draft = {
  plan: PlanName
  name: string
  email: string
  property: string
  address: string
  district: string
}

type Quote = Draft & { id: string; monthly: number; expiresOn: string }

const plans: { value: PlanName; hint: string }[] = [
  { value: 'Household', hint: 'Homes and apartments' },
  { value: 'Business', hint: 'Shops, offices, warehouses' },
  { value: 'Municipal', hint: 'Districts, utilities, transit' },
]

// Typed fields survive close and reload; the quote never does.
const draftKey = 'kaiju.quote-draft'

const blank = (): Draft => ({
  plan: 'Household',
  name: '',
  email: '',
  property: '',
  address: '',
  district: '',
})

function readDraft(): Draft {
  try {
    const stored = JSON.parse(localStorage.getItem(draftKey) ?? 'null')
    return stored && typeof stored === 'object' ? { ...blank(), ...stored } : blank()
  } catch {
    return blank()
  }
}

const money = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
})
// expiresOn is a calendar date; don't read it as UTC midnight.
const day = new Intl.DateTimeFormat('en-US', { dateStyle: 'long', timeZone: 'UTC' })

let dialog: HTMLDialogElement
let opener: HTMLElement | null = null
let draft = $state<Draft>(blank())
let quote = $state<Quote | null>(null)
let error = $state('')
let sending = $state(false)

$effect(() => {
  if (quoteModal.open && !dialog.open) {
    opener = document.activeElement instanceof HTMLElement ? document.activeElement : null
    // A plan card's plan wins over the saved draft.
    draft = quoteModal.plan ? { ...readDraft(), plan: quoteModal.plan } : readDraft()
    quote = null
    error = ''
    dialog.showModal()
  } else if (!quoteModal.open && dialog.open) {
    dialog.close()
  }
})

$effect(() => {
  if (!quoteModal.open || quote) return
  const typed = [draft.name, draft.email, draft.property, draft.address, draft.district]
  if (typed.some((value) => value.trim())) localStorage.setItem(draftKey, JSON.stringify(draft))
  else localStorage.removeItem(draftKey)
})

function onclose() {
  closeQuote()
  opener?.focus()
}

// Only backdrop clicks reach the dialog element itself.
function onclick(event: MouseEvent) {
  if (event.target === dialog) dialog.close()
}

async function submit(event: SubmitEvent) {
  event.preventDefault()
  sending = true
  error = ''
  try {
    const res = await fetch('/api/quotes', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(draft),
    })
    if (res.status !== 201) {
      const body = (await res.json().catch(() => null)) as {
        error?: string
        requestId?: string
      } | null
      const detail = body?.requestId ? ` Quote reference ${body.requestId} to support.` : ''
      error = `${body?.error ?? `Request failed with ${res.status}`}.${detail}`
      return
    }
    quote = (await res.json()) as Quote
    localStorage.removeItem(draftKey)
    draft = { ...blank(), plan: draft.plan }
  } catch {
    error = 'We couldn’t reach Kaiju Mutual. Check your connection and try again.'
  } finally {
    sending = false
  }
}
</script>

<dialog class="quote" bind:this={dialog} aria-labelledby="quote-title" {onclose} {onclick}>
  <div class="quote__panel">
    <button
      type="button"
      class="quote__close"
      aria-label="Close"
      onclick={() => dialog.close()}
    >
      <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
        <path d="M4 4 L16 16 M16 4 L4 16" stroke="currentColor" stroke-width="2.5" />
      </svg>
    </button>

    {#if quote}
      <div class="quote__head">
        <h2 id="quote-title">Your quote</h2>
        <p>
          Nothing is charged yet. Give us the reference below when you’re ready to take out the
          policy.
        </p>
      </div>
      <div class="result">
        <p class="result__what">{quote.plan} cover for {quote.property}, {quote.address}</p>
        <p class="result__price">
          {money.format(quote.monthly)}<span> / month</span>
        </p>
        <dl class="result__facts">
          <div>
            <dt>Reference</dt>
            <dd class="result__ref">{quote.id}</dd>
          </div>
          <div>
            <dt>Price holds until</dt>
            <dd>{day.format(new Date(quote.expiresOn))}</dd>
          </div>
        </dl>
      </div>
      <button type="button" class="button button--ghost" onclick={() => (quote = null)}>
        Quote another property
      </button>
    {:else}
      <form class="form" onsubmit={submit}>
        <div class="quote__head">
          <h2 id="quote-title">Get a quote</h2>
          <p>No account needed. It takes a minute. Fields marked * are required.</p>
        </div>

        <fieldset class="plans">
          <legend>Plan</legend>
          {#each plans as plan}
            <label class="plans__item">
              <input type="radio" name="plan" value={plan.value} bind:group={draft.plan} />
              <span class="plans__name">{plan.value}</span>
              <span class="plans__hint">{plan.hint}</span>
            </label>
          {/each}
        </fieldset>

        <div class="form__row">
          <label class="field">
            <span>Your name <abbr class="field__required" title="Required">*</abbr></span>
            <input name="name" autocomplete="name" required bind:value={draft.name} />
          </label>
          <label class="field">
            <span>Email <abbr class="field__required" title="Required">*</abbr></span>
            <input
              name="email"
              type="email"
              autocomplete="email"
              required
              placeholder="you@example.com"
              bind:value={draft.email}
            />
          </label>
        </div>

        <label class="field">
          <span>What are we covering? <abbr class="field__required" title="Required">*</abbr></span>
          <input
            name="property"
            required
            placeholder="Apartment, corner shop, water treatment plant"
            bind:value={draft.property}
          />
        </label>

        <div class="form__row form__row--address">
          <label class="field">
            <span>Address <abbr class="field__required" title="Required">*</abbr></span>
            <input
              name="address"
              autocomplete="street-address"
              required
              bind:value={draft.address}
            />
          </label>
          <label class="field">
            <span>District <abbr class="field__required" title="Required">*</abbr></span>
            <input name="district" required placeholder="Lower Cheswick" bind:value={draft.district} />
          </label>
        </div>

        {#if error}
          <p class="form__error" role="alert">{error}</p>
        {/if}

        <button type="submit" class="button" disabled={sending}>
          {sending ? 'Pricing…' : 'Get my price'}
        </button>
      </form>
    {/if}
  </div>
</dialog>

<style>
  :global(body:has(dialog.quote[open])) {
    overflow: hidden;
  }

  .quote {
    width: min(100% - 2rem, 40rem);
    max-height: calc(100svh - 2rem);
    margin: auto;
    padding: 0;
    border: 0;
    border-radius: 4px;
    background: var(--paper);
    color: var(--ink);
    box-shadow: 0 30px 80px rgb(0 0 0 / 0.4);
  }
  .quote::backdrop {
    background: rgb(14 27 42 / 0.7);
  }
  @media (prefers-reduced-motion: no-preference) {
    .quote[open] {
      animation: rise 180ms ease-out;
    }
    .quote[open]::backdrop {
      animation: fade 180ms ease-out;
    }
  }
  @keyframes rise {
    from {
      opacity: 0;
      transform: translateY(12px);
    }
  }
  @keyframes fade {
    from {
      opacity: 0;
    }
  }

  .quote__panel {
    position: relative;
    display: grid;
    gap: 2rem;
    padding: clamp(1.5rem, 5vw, 3rem);
  }
  .quote__close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    display: inline-grid;
    place-items: center;
    width: 2.5rem;
    height: 2.5rem;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: var(--ink);
    cursor: pointer;
  }
  .quote__close:hover {
    background: var(--concrete);
  }
  .quote__head {
    display: grid;
    gap: 0.5rem;
    padding-right: 3rem;
  }
  .quote__head h2 {
    font-size: 2rem;
  }
  .quote__head p {
    color: var(--ink-soft);
  }

  .form {
    display: grid;
    gap: 1.5rem;
  }
  .form__row {
    display: grid;
    gap: 1.5rem;
  }
  .form__error {
    padding: 0.85rem 1rem;
    border-left: 4px solid var(--siren-deep);
    background: var(--concrete);
    color: var(--ink);
  }
  .form .button {
    justify-self: start;
  }
  .form .button:disabled {
    opacity: 0.6;
    cursor: wait;
  }
  @media (min-width: 560px) {
    .form__row {
      grid-template-columns: 1fr 1fr;
    }
    .form__row--address {
      grid-template-columns: 2fr 1fr;
    }
  }

  .plans {
    display: grid;
    gap: 0.5rem;
    margin: 0;
    padding: 0;
    border: 0;
  }
  .plans legend {
    padding: 0;
    margin-bottom: 0.5rem;
    font-weight: 700;
  }
  .plans__item {
    display: grid;
    grid-template-columns: auto 1fr;
    column-gap: 0.75rem;
    align-items: center;
    padding: 0.75rem 1rem;
    border: 2px solid var(--rule);
    border-radius: 4px;
    cursor: pointer;
  }
  .plans__item:has(input:checked) {
    border-color: var(--ink);
  }
  .plans__item:has(input:focus-visible) {
    outline: 3px solid var(--siren);
    outline-offset: 3px;
  }
  .plans__item input {
    grid-row: span 2;
    margin: 0;
    accent-color: var(--siren-deep);
  }
  .plans__item input:focus-visible {
    outline: none;
  }
  .plans__name {
    font-weight: 700;
  }
  .plans__hint {
    font-size: 0.9rem;
    color: var(--ink-soft);
  }
  @media (min-width: 560px) {
    .plans {
      grid-template-columns: repeat(3, 1fr);
    }
    .plans legend {
      grid-column: 1 / -1;
    }
  }

  .field {
    display: grid;
    gap: 0.4rem;
    font-weight: 700;
  }
  .field input {
    padding: 0.7em 0.9em;
    border: 2px solid var(--rule);
    border-radius: 4px;
    background: #fff;
    color: var(--ink);
    font: inherit;
    font-weight: 400;
  }
  .field input:focus-visible {
    border-color: var(--ink);
  }
  .field__required {
    text-decoration: none;
    color: var(--siren-deep);
  }

  .result {
    display: grid;
    gap: 1rem;
    padding: 1.5rem;
    border: 2px solid var(--rule);
    background: #fff;
  }
  .result__what {
    color: var(--ink-soft);
  }
  .result__price {
    font-size: 3rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1;
  }
  .result__price span {
    font-size: 1rem;
    font-weight: 500;
    letter-spacing: 0;
    color: var(--ink-soft);
  }
  .result__facts {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin: 0;
  }
  .result__facts dt {
    font-size: 0.9rem;
    color: var(--ink-soft);
  }
  .result__facts dd {
    margin: 0;
    font-weight: 700;
  }
  .result__ref {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  }
</style>
