import type { PlanName } from '$lib/quote.svelte'

export type Peril = {
  name: string
  description: string
}

export const perils: Peril[] = [
  {
    name: 'Structural damage',
    description:
      'Footfall, tail sweeps, and anything a kaiju leans on. Covers the building, the foundation, and the neighbours it landed on.',
  },
  {
    name: 'Thermal and breath weapons',
    description:
      'Atomic breath, plasma, acid, sonic blasts. We settle on the damage done, not on what the creature technically emitted.',
  },
  {
    name: 'Debris and falling objects',
    description:
      'Thrown vehicles, collapsed cranes, downed aircraft. Includes military ordnance that missed.',
  },
  {
    name: 'Evacuation and temporary housing',
    description:
      'Hotel, meals and transport from the moment sirens sound until your street is declared clear.',
  },
  {
    name: 'Contents and vehicles',
    description:
      'Everything inside, and everything parked outside, at replacement value. No depreciation for stomping.',
  },
]

export type Step = {
  title: string
  body: string
}

export const claimSteps: Step[] = [
  {
    title: 'Get to a shelter',
    body: 'Nothing in your policy asks you to stay and take photos. Leave. We use city sensor data to confirm the event.',
  },
  {
    title: 'Tell us it happened',
    body: 'Start a claim in the portal or call the hotline. It takes two minutes and you can add details later.',
  },
  {
    title: 'An assessor visits',
    body: 'Within 48 hours of the all-clear. They bring a drone for anything too tall or too radioactive to climb.',
  },
  {
    title: 'We pay',
    body: 'Temporary housing is paid the same day. Structural claims settle within 30 days of the assessment.',
  },
]

export type Plan = {
  name: PlanName
  price: string
  audience: string
  includes: string[]
  featured?: boolean
}

export const plans: Plan[] = [
  {
    name: 'Household',
    price: '$48',
    audience: 'Homes and apartments',
    includes: ['All five perils', 'Contents up to $250k', 'Temporary housing, 90 days'],
  },
  {
    name: 'Business',
    price: '$210',
    audience: 'Shops, offices, warehouses',
    includes: [
      'All five perils',
      'Business interruption, 6 months',
      'Stock and equipment at replacement value',
      'Priority assessor',
    ],
    featured: true,
  },
  {
    name: 'Municipal',
    price: 'Quoted',
    audience: 'Districts, utilities, transit',
    includes: [
      'Bridges, tunnels and grid',
      'Multi-event cover',
      'Dedicated response team',
      'Pre-attack risk survey',
    ],
  },
]

export type Sighting = {
  name: string
  location: string
  status: 'Active' | 'Contained' | 'Dormant'
  size: string
}

export const sightings: Sighting[] = [
  { name: 'Tarrasque-9', location: 'Port of Oakhaven', status: 'Active', size: 'Class 4 · 88 m' },
  { name: 'Meridian', location: 'Lower Cheswick', status: 'Contained', size: 'Class 3 · 61 m' },
  { name: 'Old Gravel', location: 'Hollow Bay trench', status: 'Dormant', size: 'Class 5 · 140 m' },
]

export type Question = {
  q: string
  a: string
}

export const faq: Question[] = [
  {
    q: 'Is a kaiju attack not an act of God?',
    a: 'Not on our policies. Most home insurers exclude "giant creature events" under acts of God. We exist because of that clause.',
  },
  {
    q: 'What if the damage was caused by the military, not the kaiju?',
    a: 'Covered. Collateral damage from any response to a declared kaiju event counts, whether that was a missile, a mech or a very large net.',
  },
  {
    q: 'Do I need to prove it was a kaiju?',
    a: 'No. We match your claim against the civic seismic and sighting network. If a kaiju was declared in your district, that is proof enough.',
  },
  {
    q: 'What is not covered?',
    a: 'Damage you cause trying to fight the kaiju yourself, and anything you built after a warning was issued for your block.',
  },
  {
    q: 'Can I get cover if a kaiju is currently in my city?',
    a: 'Yes, but the new policy starts 72 hours after the all-clear. Nobody wants to be the person who signs up mid-stomp.',
  },
]
