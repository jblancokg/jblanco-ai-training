<script lang="ts">
import { onMount } from 'svelte'
import { createHeroScene } from './scene'

let canvas: HTMLCanvasElement
let failed = $state(false)

onMount(() => {
  const scene = createHeroScene(canvas)
  scene.start().catch((error: unknown) => {
    console.error('Hero scene unavailable', error)
    failed = true
  })
  return () => scene.dispose()
})
</script>

<canvas bind:this={canvas} class:failed aria-hidden="true"></canvas>

<style>
  canvas {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    display: block;
  }
  canvas.failed {
    display: none;
  }
</style>
