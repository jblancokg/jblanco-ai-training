<script lang="ts">
import { links, nav } from '$lib/content/links'
</script>

<footer class="footer">
  <div class="wrap footer__grid">
    <div>
      <p class="footer__brand">Kaiju Mutual</p>
      <p class="footer__note">
        A fictional insurer built for training. No policies, premiums or kaiju described here are
        real.
      </p>
    </div>
    <nav aria-label="Footer">
      {#each nav as item}
        <a href={item.href}>{item.label}</a>
      {/each}
      <a href={links.portal}>Policyholder portal</a>
      <a href={links.claim}>Start a claim</a>
    </nav>
    <div class="footer__hotline">
      <p>Attack in progress?</p>
      <p class="footer__phone">0800 KAIJU 00</p>
      <p class="footer__note">Get to shelter first. We'll still be here.</p>
    </div>
  </div>
</footer>

<style>
  .footer {
    background: var(--ink);
    color: var(--concrete);
    padding-block: 4rem 3rem;
  }
  .footer__grid {
    display: grid;
    gap: 2.5rem;
  }
  .footer__brand {
    font-weight: 800;
    font-size: 1.25rem;
  }
  .footer__note {
    opacity: 0.65;
    max-width: 36ch;
    margin-top: 0.5rem;
  }
  nav {
    display: grid;
    gap: 0.6rem;
    align-content: start;
  }
  nav a {
    text-decoration: none;
  }
  nav a:hover {
    text-decoration: underline;
  }
  .footer__phone {
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.02em;
    color: var(--siren);
  }
  @media (min-width: 760px) {
    .footer__grid {
      grid-template-columns: 1.4fr 1fr 1fr;
    }
  }
</style>
