import { CanvasTexture, Color, Group, Sprite, SpriteMaterial } from 'three'

const POOL = 32
const LIFE = 1.4

export type Dust = {
  group: Group
  puff(x: number, y: number, z: number, size: number, now: number): void
  update(now: number): void
  dispose(): void
}

function softDisc(): CanvasTexture {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = 64
  const ctx = canvas.getContext('2d')
  if (ctx) {
    const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
    g.addColorStop(0, 'rgba(255,255,255,0.9)')
    g.addColorStop(0.5, 'rgba(255,255,255,0.35)')
    g.addColorStop(1, 'rgba(255,255,255,0)')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, 64, 64)
  }
  return new CanvasTexture(canvas)
}

/** A small pool of expanding, fading sprites for collapse dust. */
export function createDust(): Dust {
  const group = new Group()
  const texture = softDisc()
  const born = new Float64Array(POOL).fill(-Infinity)
  const sizes = new Float64Array(POOL)
  let next = 0

  const sprites = Array.from({ length: POOL }, () => {
    const material = new SpriteMaterial({
      map: texture,
      color: new Color('#6b7a8c'),
      transparent: true,
      opacity: 0,
      depthWrite: false,
    })
    const sprite = new Sprite(material)
    sprite.visible = false
    group.add(sprite)
    return sprite
  })

  return {
    group,
    puff(x, y, z, size, now) {
      const i = next
      next = (next + 1) % POOL
      born[i] = now
      sizes[i] = size
      sprites[i].position.set(x, y, z)
      sprites[i].visible = true
    },
    update(now) {
      sprites.forEach((sprite, i) => {
        const p = (now - born[i]) / LIFE
        if (p >= 1) {
          sprite.visible = false
          return
        }
        const s = sizes[i] * (0.6 + 2.4 * p)
        sprite.scale.set(s, s * 0.7, 1)
        sprite.position.y += 0.012
        sprite.material.opacity = 0.55 * (1 - p) ** 1.5
      })
    },
    dispose() {
      texture.dispose()
      for (const sprite of sprites) sprite.material.dispose()
    },
  }
}
