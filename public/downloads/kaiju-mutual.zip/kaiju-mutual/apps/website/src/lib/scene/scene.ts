import {
  ACESFilmicToneMapping,
  AdditiveBlending,
  Color,
  ConeGeometry,
  DirectionalLight,
  Fog,
  HemisphereLight,
  Mesh,
  MeshBasicMaterial,
  PerspectiveCamera,
  PointLight,
  Scene,
  Vector2,
  Vector3,
  WebGLRenderer,
} from 'three'
import { createCity } from './city'
import { createDust } from './dust'
import { type KaijuRig, loadKaiju } from './kaiju'

const NIGHT = new Color('#0e1b2a')
const EXPOSURE = 1.1

// The loop: fade in, walk out of the fog down the avenue crushing what's beside it,
// stop close to the camera, roar, fade out, reset.
const LOOP = 30
const FADE = 1
const WALK_END = 25.5
const ROAR_START = 26.5
const ROAR_END = 29
// The path angles off the avenue into the near buildings, so the last stretch flattens them.
const PATH_X = 3.2
const PATH_START = new Vector3(PATH_X, 0, -31)
const PATH_END = new Vector3(6.8, 0, 2.5)
const HEADING = Math.atan2(PATH_END.x - PATH_START.x, PATH_END.z - PATH_START.z)
const CRUSH_RADIUS = 3.6
const KAIJU_SCALE = 2.1

const CAMERA_HOME = new Vector3(9.5, 6.5, 24)
const LOOK_AT = new Vector3(PATH_X - 1, 4, 0)

export type HeroScene = {
  /** Loads the model and starts rendering. Rejects if WebGL or the model is unavailable. */
  start(): Promise<void>
  dispose(): void
}

const clamp01 = (v: number) => Math.min(Math.max(v, 0), 1)
const smooth = (p: number) => p * p * (3 - 2 * p)

function searchlight(color: string): Mesh {
  const geometry = new ConeGeometry(2.2, 40, 24, 1, true)
  geometry.translate(0, 20, 0)
  const material = new MeshBasicMaterial({
    color: new Color(color),
    transparent: true,
    opacity: 0.06,
    blending: AdditiveBlending,
    depthWrite: false,
  })
  return new Mesh(geometry, material)
}

export function createHeroScene(canvas: HTMLCanvasElement): HeroScene {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

  const renderer = new WebGLRenderer({
    canvas,
    antialias: true,
    powerPreference: 'high-performance',
  })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.toneMapping = ACESFilmicToneMapping
  renderer.toneMappingExposure = EXPOSURE

  const scene = new Scene()
  scene.background = NIGHT
  scene.fog = new Fog(NIGHT, 14, 55)

  const camera = new PerspectiveCamera(32, 1, 0.1, 120)
  camera.position.copy(CAMERA_HOME)
  camera.lookAt(LOOK_AT)

  scene.add(new HemisphereLight(new Color('#4a6fa5'), new Color('#0b1420'), 1.1))
  const moon = new DirectionalLight(new Color('#b8cdea'), 2.2)
  moon.position.set(-12, 22, 8)
  scene.add(moon)
  const siren = new PointLight(new Color('#ff5a1f'), 10, 22, 1.6)
  siren.position.set(7, 0.8, 5)
  scene.add(siren)

  const city = createCity(PATH_X)
  scene.add(city.group)
  const dust = createDust()
  scene.add(dust.group)

  const beams = [searchlight('#9fc7ff'), searchlight('#ffd27a')]
  beams[0].position.set(-9, 0, -14)
  beams[1].position.set(12, 0, -22)
  for (const beam of beams) scene.add(beam)

  const pointer = new Vector2()
  const onPointerMove = (event: PointerEvent) => {
    pointer.set(
      (event.clientX / window.innerWidth) * 2 - 1,
      (event.clientY / window.innerHeight) * 2 - 1,
    )
  }

  const resize = () => {
    const { clientWidth, clientHeight } = canvas
    if (clientWidth === 0 || clientHeight === 0) return
    renderer.setSize(clientWidth, clientHeight, false)
    camera.aspect = clientWidth / clientHeight
    camera.fov = camera.aspect < 0.9 ? 52 : 32
    camera.updateProjectionMatrix()
  }
  const observer = new ResizeObserver(resize)

  let visible = true
  const visibility = new IntersectionObserver(([entry]) => {
    visible = entry?.isIntersecting ?? true
  })

  let frame = 0
  let last = performance.now()
  let elapsed = 0
  let loops = 0
  let shake = 0
  let lastStep = 0
  let kaiju: KaijuRig | undefined
  let disposed = false

  const lookAt = new Vector3()

  /** Place and pose everything for a moment `t` seconds into the loop. */
  const setMoment = (t: number, now: number) => {
    if (!kaiju) return
    const walk = clamp01(t / WALK_END)
    const stride = t < WALK_END ? 1 : 1 - smooth(clamp01((t - WALK_END) / 0.8))
    const roar =
      smooth(clamp01((t - ROAR_START) / 0.6)) * (1 - smooth(clamp01((t - ROAR_END) / 0.6)))

    kaiju.root.position.lerpVectors(PATH_START, PATH_END, walk)
    kaiju.root.rotation.y = HEADING - roar * 0.35
    kaiju.pose({ t: now, stride, roar })

    const hit = city.crush(kaiju.root.position.x, kaiju.root.position.z, CRUSH_RADIUS, now)
    for (const b of hit) {
      dust.puff(b.x, b.h * 0.5, b.z, 1.2 + b.h * 0.4, now)
      shake = Math.min(shake + 0.35, 1)
    }

    // Footfalls: the stride phase crosses zero when a foot plants.
    const step = Math.floor(now * 0.4 * 2)
    if (stride > 0.5 && step !== lastStep) {
      lastStep = step
      shake = Math.min(shake + 0.25, 1)
    }
    if (roar > 0.95 && shake < 0.3) shake = 0.5

    const fade = smooth(clamp01(t / FADE)) * smooth(clamp01((LOOP - t) / FADE))
    renderer.toneMappingExposure = EXPOSURE * fade
    siren.intensity = (9 + Math.sin(now * 6) * 3 + Math.sin(now * 17) * 1.5) * (1 + roar * 2)
  }

  const render = (now: number) => {
    frame = requestAnimationFrame(render)
    const dt = Math.min((now - last) / 1000, 0.05)
    last = now
    if (!visible) return
    elapsed += dt

    const loop = Math.floor(elapsed / LOOP)
    if (loop !== loops) {
      loops = loop
      city.reset()
    }
    setMoment(elapsed - loop * LOOP, elapsed)
    city.update(elapsed)
    dust.update(elapsed)

    beams[0].rotation.set(Math.sin(elapsed * 0.35) * 0.35, 0, 0.55 + Math.cos(elapsed * 0.27) * 0.3)
    beams[1].rotation.set(Math.cos(elapsed * 0.31) * 0.3, 0, -0.5 + Math.sin(elapsed * 0.22) * 0.35)

    shake *= 1 - Math.min(dt * 6, 1)
    const jolt = shake * 0.12
    camera.position.x += (CAMERA_HOME.x + pointer.x * 1.6 - camera.position.x) * 0.04
    camera.position.y += (CAMERA_HOME.y - pointer.y * 0.8 - camera.position.y) * 0.04
    lookAt.copy(LOOK_AT)
    if (kaiju) lookAt.z = kaiju.root.position.z * 0.25
    lookAt.x += (Math.random() - 0.5) * jolt
    lookAt.y += (Math.random() - 0.5) * jolt
    camera.lookAt(lookAt)
    renderer.render(scene, camera)
  }

  return {
    async start() {
      const rig = await loadKaiju('/models/kaiju.glb')
      if (disposed) return
      rig.root.scale.setScalar(KAIJU_SCALE)
      scene.add(rig.root)
      kaiju = rig

      observer.observe(canvas)
      visibility.observe(canvas)
      resize()

      if (reducedMotion) {
        // One still from mid-walk, no loop.
        setMoment(14, 14)
        city.update(Number.POSITIVE_INFINITY)
        camera.lookAt(LOOK_AT)
        renderer.render(scene, camera)
        return
      }
      window.addEventListener('pointermove', onPointerMove, { passive: true })
      frame = requestAnimationFrame(render)
    },
    dispose() {
      disposed = true
      cancelAnimationFrame(frame)
      window.removeEventListener('pointermove', onPointerMove)
      observer.disconnect()
      visibility.disconnect()
      city.dispose()
      dust.dispose()
      for (const beam of beams) {
        beam.geometry.dispose()
        ;(beam.material as MeshBasicMaterial).dispose()
      }
      renderer.dispose()
    },
  }
}
