<script lang="ts">
import { about, figures } from '$lib/content/pages'
</script>

<svelte:head>
  <title>About · Kaiju Mutual</title>
</svelte:head>

<div class="page-head">
  <div class="wrap">
    <h1>Owned by the people it covers</h1>
    <p>Sixty years of paying out on things other insurers call impossible.</p>
  </div>
</div>

<section class="figures-band">
  <div class="wrap">
    <dl class="figures">
      {#each figures as figure}
        <div class="figure">
          <dt>{figure.label}</dt>
          <dd>{figure.value}</dd>
        </div>
      {/each}
    </dl>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="prose">
    {#each about as paragraph}
      <p>{paragraph}</p>
    {/each}
  </div>
    </div>
</section>

<style>
  .figures-band {
    background: var(--night);
    color: var(--concrete);
    padding-block: clamp(2.5rem, 6vw, 4rem);
  }
  /* One row of four, per the design. */
  .figures {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
    margin: 0;
  }
  .figure {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    border-top: 2px solid var(--siren);
    padding-top: 1rem;
  }
  .figure dd {
    order: -1;
    margin: 0;
    font-size: clamp(2.5rem, 4.5vw, 3.75rem);
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1;
    white-space: nowrap;
  }
  .figure dt {
    font-size: 0.95rem;
    opacity: 0.75;
  }
</style>
