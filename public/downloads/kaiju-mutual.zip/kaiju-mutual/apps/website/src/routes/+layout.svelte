<script lang="ts">
import { page } from '$app/state'
import favicon from '$lib/assets/favicon.svg'
import Footer from '$lib/components/Footer.svelte'
import Header from '$lib/components/Header.svelte'
import QuoteModal from '$lib/components/QuoteModal.svelte'
import '../app.css'

let { children } = $props()
let home = $derived(page.url.pathname === '/')
</script>

<svelte:head>
  <link rel="icon" href={favicon} />
</svelte:head>

<Header overlay={home} />
<main>
  {@render children()}
</main>
<Footer />
<QuoteModal />
