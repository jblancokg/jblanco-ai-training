<script lang="ts">
import { exclusions, limits } from '$lib/content/pages'
import { openQuote } from '$lib/quote.svelte'
</script>

<svelte:head>
  <title>Coverage · Kaiju Mutual</title>
</svelte:head>

<div class="page-head">
  <div class="wrap">
    <h1>What each plan covers</h1>
    <p>Same five perils on every plan. The limits change with what you're protecting.</p>
  </div>
</div>

<section class="section">
  <div class="wrap">
    <div class="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Peril</th>
            <th>Household</th>
            <th>Business</th>
            <th>Municipal</th>
          </tr>
        </thead>
        <tbody>
          {#each limits as row}
            <tr>
              <th scope="row">{row.peril}</th>
              <td>{row.household}</td>
              <td>{row.business}</td>
              <td>{row.municipal}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="prose">
    <h2>What isn't covered</h2>
    <ul>
      {#each exclusions as item}
        <li>{item}</li>
      {/each}
    </ul>
    <p style="margin-top: 2rem">
      <button type="button" class="button" onclick={() => openQuote()}>Get a quote</button>
    </p>
  </div>
    </div>
</section>

<style>
  .table-scroll {
    overflow-x: auto;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    min-width: 640px;
  }
  th,
  td {
    text-align: left;
    padding: 1rem 1rem 1rem 0;
    border-bottom: 1px solid var(--rule);
    vertical-align: top;
  }
  thead th {
    border-bottom: 2px solid var(--ink);
    font-weight: 700;
  }
  tbody th {
    font-weight: 700;
    width: 30%;
  }
  td {
    color: var(--ink-soft);
  }
</style>
