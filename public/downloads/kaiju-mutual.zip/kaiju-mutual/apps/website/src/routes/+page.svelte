<script lang="ts">
import { claimSteps, faq, perils, plans, sightings } from '$lib/content/home'
import { openQuote } from '$lib/quote.svelte'
import KaijuScene from '$lib/scene/KaijuScene.svelte'
</script>

<svelte:head>
  <title>Kaiju Mutual · Insurance for kaiju attacks</title>
  <meta
    name="description"
    content="Household, business and municipal cover for giant creature events. Claims settled within 30 days of the all-clear."
  />
</svelte:head>

<section class="hero">
  <KaijuScene />
  <div class="wrap">
    <div class="hero__copy">
    <h1>Insurance for the day the ground shakes.</h1>
    <p>
      Household cover from $48 a month. Every peril a 90-metre lizard can cause, settled within 30
      days of the all-clear.
    </p>
    <div class="hero__actions">
      <button type="button" class="button" onclick={() => openQuote()}>Get a quote</button>
      <a class="button button--ghost" href="/coverage">See what's covered</a>
    </div>
    </div>
  </div>
</section>

<section class="board" aria-labelledby="board-title">
  <div class="wrap">
    <div class="board__row">
      <h2 id="board-title" class="board__title">Current activity</h2>
      <ul class="board__list">
        {#each sightings as s}
          <li class="board__item">
            <span class="board__status board__status--{s.status.toLowerCase()}">{s.status}</span>
            <span class="board__name">{s.name}</span>
            <span class="board__meta">{s.location}</span>
            <span class="board__meta">{s.size}</span>
          </li>
        {/each}
      </ul>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="perils-title">
  <div class="wrap">
    <div class="section__head">
      <h2 id="perils-title">Five perils. One policy.</h2>
      <p>
        Most home insurance excludes giant creature events as an act of God. We wrote a policy
        that starts where theirs stops.
      </p>
    </div>
    <dl class="perils">
      {#each perils as peril}
        <div class="perils__row">
          <dt>{peril.name}</dt>
          <dd>{peril.description}</dd>
        </div>
      {/each}
    </dl>
  </div>
</section>

<section class="section" aria-labelledby="steps-title">
  <div class="wrap">
    <div class="section__head">
      <h2 id="steps-title">How a claim works</h2>
      <p>Four steps, in this order. The first one matters more than the other three.</p>
    </div>
    <ol class="steps">
      {#each claimSteps as step, i}
        <li class="steps__item">
          <span class="steps__index" aria-hidden="true">{i + 1}</span>
          <h3>{step.title}</h3>
          <p>{step.body}</p>
        </li>
      {/each}
    </ol>
  </div>
</section>

<section class="section" aria-labelledby="plans-title">
  <div class="wrap">
    <div class="section__head">
      <h2 id="plans-title">Plans</h2>
      <p>Prices are per month and include every peril. Excess is $500 for household, $2,500 for business.</p>
    </div>
    <div class="plans">
      {#each plans as plan}
        <article class="plan" class:plan--featured={plan.featured}>
          <h3>{plan.name}</h3>
          <p class="plan__audience">{plan.audience}</p>
          <p class="plan__price">
            <span class="plan__from" class:plan__from--none={plan.price === 'Quoted'}>from</span>{plan.price}<span
              >{plan.price === 'Quoted' ? '' : ' / month'}</span
            >
          </p>
          <ul>
            {#each plan.includes as line}
              <li>{line}</li>
            {/each}
          </ul>
          <button type="button" class="button" onclick={() => openQuote(plan.name)}>
            {plan.price === 'Quoted' ? 'Talk to us' : 'Get a quote'}
          </button>
        </article>
      {/each}
    </div>
  </div>
</section>

<section class="section" aria-labelledby="faq-title">
  <div class="wrap faq">
    <h2 id="faq-title">Questions we get a lot</h2>
    <div class="faq__list">
      {#each faq as item}
        <details class="faq__item">
          <summary>{item.q}</summary>
          <p>{item.a}</p>
        </details>
      {/each}
    </div>
  </div>
</section>

<section class="closer">
  <div class="wrap closer__row">
    <h2>Cover starts 72 hours after the all-clear. Don't wait for the sirens.</h2>
    <button type="button" class="button" onclick={() => openQuote()}>Get a quote</button>
  </div>
</section>

<style>
  .hero {
    position: relative;
    min-height: 100svh;
    display: flex;
    align-items: flex-end;
    background: var(--night);
    color: var(--paper);
    overflow: hidden;
  }
  .hero .wrap {
    position: relative;
    z-index: 1;
  }
  .hero__copy {
    padding-block: clamp(3rem, 8vh, 6rem);
    max-width: 44rem;
  }
  .hero__copy p {
    margin-top: 1.5rem;
    font-size: clamp(1.1rem, 1.6vw, 1.35rem);
    max-width: 38ch;
    text-shadow: 0 1px 12px rgb(0 0 0 / 0.5);
  }
  .hero h1 {
    text-shadow: 0 2px 24px rgb(0 0 0 / 0.5);
  }
  .hero__actions {
    margin-top: 2rem;
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
  }

  .board {
    background: var(--ink);
    color: var(--concrete);
    padding-block: 1.25rem;
    border-top: 2px solid rgb(255 255 255 / 0.08);
  }
  .board__row {
    display: grid;
    gap: 1rem;
    align-items: center;
  }
  .board__title {
    font-size: 0.95rem;
    font-weight: 600;
    opacity: 0.7;
  }
  .board__list {
    list-style: none;
    margin: 0;
    padding: 0;
    display: grid;
    gap: 0.75rem;
  }
  .board__item {
    display: grid;
    grid-template-columns: auto 1fr;
    column-gap: 0.75rem;
    align-items: baseline;
  }
  .board__status {
    grid-row: span 3;
    align-self: start;
    display: inline-block;
    padding: 0.15em 0.6em;
    border-radius: 999px;
    font-size: 0.85rem;
    font-weight: 700;
    background: rgb(255 255 255 / 0.12);
  }
  .board__status--active {
    background: var(--siren);
    color: var(--ink);
  }
  .board__status--contained {
    background: #3f6191;
  }
  .board__name {
    font-weight: 700;
  }
  .board__meta {
    font-size: 0.95rem;
    opacity: 0.7;
  }
  @media (min-width: 900px) {
    .board__row {
      grid-template-columns: 10rem 1fr;
    }
    .board__list {
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
    }
  }

  .perils {
    margin: 0;
    border-top: 2px solid var(--ink);
  }
  .perils__row {
    display: grid;
    gap: 0.5rem 3rem;
    padding-block: 1.5rem;
    border-bottom: 1px solid var(--rule);
  }
  .perils dt {
    font-weight: 700;
    font-size: 1.375rem;
    letter-spacing: -0.01em;
  }
  .perils dd {
    margin: 0;
    color: var(--ink-soft);
  }
  @media (min-width: 760px) {
    .perils__row {
      grid-template-columns: 1fr 2fr;
    }
  }

  .steps {
    list-style: none;
    margin: 0;
    padding: 0;
    display: grid;
    gap: 2rem;
    counter-reset: step;
  }
  .steps__item {
    display: grid;
    grid-template-columns: 3.5rem 1fr;
    grid-template-rows: auto auto;
    column-gap: 1rem;
  }
  .steps__index {
    grid-row: span 2;
    font-size: 3rem;
    font-weight: 800;
    line-height: 1;
    color: var(--siren-deep);
    letter-spacing: -0.04em;
  }
  .steps__item p {
    margin-top: 0.5rem;
    color: var(--ink-soft);
  }
  @media (min-width: 900px) {
    .steps {
      grid-template-columns: repeat(4, 1fr);
      gap: 2.5rem;
    }
    .steps__item {
      grid-template-columns: 1fr;
    }
    .steps__index {
      grid-row: auto;
      margin-bottom: 1rem;
    }
  }

  .plans {
    display: grid;
    gap: 1.5rem;
  }
  .plan {
    background: var(--paper);
    border: 2px solid var(--rule);
    padding: 2rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  .plan--featured {
    border-color: var(--ink);
    background: var(--ink);
    color: var(--concrete);
  }
  .plan__audience {
    color: inherit;
    opacity: 0.7;
  }
  .plan__price {
    font-size: 3rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1;
    margin-top: 1rem;
  }
  .plan__price .plan__from {
    display: block;
    margin-bottom: 0.25rem;
    font-size: 0.875rem;
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
  .plan__from--none {
    visibility: hidden;
  }
  .plan__price span {
    font-size: 1rem;
    font-weight: 500;
    letter-spacing: 0;
    opacity: 0.7;
  }
  .plan ul {
    margin: 1rem 0 1.5rem;
    padding-left: 1.1em;
    flex: 1;
  }
  .plan li + li {
    margin-top: 0.35rem;
  }
  .plan .button {
    align-self: flex-start;
  }
  @media (min-width: 900px) {
    .plans {
      grid-template-columns: repeat(3, 1fr);
    }
  }

  .faq {
    display: grid;
    gap: 2rem;
  }
  .faq__list {
    border-top: 2px solid var(--ink);
  }
  .faq__item {
    border-bottom: 1px solid var(--rule);
  }
  .faq__item summary {
    cursor: pointer;
    padding-block: 1.1rem;
    font-weight: 700;
    font-size: 1.15rem;
    list-style: none;
    display: flex;
    justify-content: space-between;
    gap: 1rem;
  }
  .faq__item summary::-webkit-details-marker {
    display: none;
  }
  .faq__item summary::after {
    content: '+';
    font-weight: 500;
    color: var(--siren-deep);
  }
  .faq__item[open] summary::after {
    content: '–';
  }
  .faq__item p {
    padding-bottom: 1.25rem;
    color: var(--ink-soft);
  }
  @media (min-width: 900px) {
    .faq {
      grid-template-columns: 1fr 2fr;
      align-items: start;
    }
  }

  .closer {
    background: var(--siren);
    color: var(--ink);
    padding-block: clamp(3rem, 7vw, 6rem);
  }
  .closer__row {
    display: grid;
    gap: 2rem;
    align-items: center;
  }
  .closer h2 {
    max-width: 22ch;
  }
  .closer .button {
    background: var(--ink);
    color: var(--concrete);
    justify-self: start;
  }
  .closer .button:hover {
    background: #22323f;
  }
  @media (min-width: 900px) {
    .closer__row {
      grid-template-columns: 1fr auto;
    }
  }
</style>
