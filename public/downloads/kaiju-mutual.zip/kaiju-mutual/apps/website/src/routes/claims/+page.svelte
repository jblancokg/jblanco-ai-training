<script lang="ts">
import { claimSteps } from '$lib/content/home'
import { links } from '$lib/content/links'
import { afterAttack, duringAttack } from '$lib/content/pages'
</script>

<svelte:head>
  <title>Claims · Kaiju Mutual</title>
</svelte:head>

<div class="page-head">
  <div class="wrap">
    <h1>During, after, and how we settle</h1>
    <p>Your safety is not a condition of the policy. Everything else can wait until the all-clear.</p>
  </div>
</div>

<section class="section">
  <div class="wrap columns">
    <div class="prose">
      <h2>During an attack</h2>
      <ul>
        {#each duringAttack as item}
          <li>{item}</li>
        {/each}
      </ul>
    </div>
    <div class="prose">
      <h2>After the all-clear</h2>
      <ul>
        {#each afterAttack as item}
          <li>{item}</li>
        {/each}
      </ul>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="prose">
    <h2>How a claim is settled</h2>
    <ol>
      {#each claimSteps as step}
        <li><strong>{step.title}.</strong> {step.body}</li>
      {/each}
    </ol>
    <p style="margin-top: 2rem">
      <a class="button" href={links.claim}>Start a claim</a>
    </p>
  </div>
    </div>
</section>

<style>
  .columns {
    display: grid;
    gap: 3rem;
  }
  .columns h2,
  .prose h2 {
    margin-top: 0;
  }
  ol {
    padding-left: 1.2em;
  }
  ol li + li {
    margin-top: 0.75em;
  }
  @media (min-width: 900px) {
    .columns {
      grid-template-columns: 1fr 1fr;
    }
  }
</style>
