"""Builds the low-poly Kaiju Mutual mascot and exports it as static/models/kaiju.glb.

Run headless from the repo root:

    /Applications/Blender.app/Contents/MacOS/Blender -b -P apps/website/tools/kaiju.py

It also runs from Blender's Scripting tab. It works in its own scene called "Kaiju" and never
touches other scenes, but object names must be free: an open file that already has an object
called "Head" makes the export fail rather than silently renaming parts to "Head.001".

Object names matter: the website animates the walk by rotating parts by name
(see apps/website/src/lib/scene/kaiju.ts), so keep them if you change the shape.
No dots in names: three.js's GLTFLoader strips them.
"""

import math
import os

import bmesh
import bpy
from mathutils import Vector

SCENE_NAME = "Kaiju"
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
OUT_PATH = os.path.normpath(os.path.join(HERE, "..", "static", "models", "kaiju.glb"))

COLORS = {
    "hide": (0.11, 0.36, 0.33, 1.0),
    "belly": (0.62, 0.70, 0.52, 1.0),
    "spine": (1.0, 0.35, 0.12, 1.0),
    "eye": (1.0, 0.82, 0.30, 1.0),
    "claw": (0.90, 0.88, 0.80, 1.0),
}


def scene():
    sc = bpy.data.scenes.get(SCENE_NAME)
    if sc is None:
        sc = bpy.data.scenes.new(SCENE_NAME)
    bpy.context.window.scene = sc
    # start clean every run
    for obj in list(sc.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.orphans_purge(do_recursive=True)
    return sc


def new_object(name, data):
    obj = bpy.data.objects.new(name, data)
    if obj.name != name:
        bpy.data.objects.remove(obj)
        raise RuntimeError(f'an object named "{name}" already exists in this file; run the script in a fresh file')
    bpy.context.scene.collection.objects.link(obj)
    return obj


def attach(obj, parent):
    """Parent without moving: the parent's world matrix is only valid after a depsgraph update."""
    if parent is None:
        return
    bpy.context.view_layer.update()
    obj.parent = parent
    obj.matrix_parent_inverse = parent.matrix_world.inverted()


def material(name):
    key = f"Kaiju.{name}"
    mat = bpy.data.materials.get(key)
    if mat is None:
        mat = bpy.data.materials.new(key)
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes["Principled BSDF"]
        bsdf.inputs["Base Color"].default_value = COLORS[name]
        bsdf.inputs["Roughness"].default_value = 0.85
        if name == "eye":
            bsdf.inputs["Emission Color"].default_value = COLORS[name]
            bsdf.inputs["Emission Strength"].default_value = 2.0
    return mat


def box(name, size, pivot, center=None, taper=1.0, color="hide", bevel=0.08, parent=None):
    """A bevelled box. `pivot` is the object origin (the joint), `center` the box centre.

    `taper` scales the top face relative to the bottom, for chunky limbs and tail segments.
    """
    center = Vector(center) if center is not None else Vector(pivot)
    pivot = Vector(pivot)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co.x *= size[0]
        v.co.y *= size[1]
        v.co.z *= size[2]
        if v.co.z > 0:
            v.co.x *= taper
            v.co.y *= taper
        v.co += center - pivot
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = new_object(name, mesh)
    obj.location = pivot
    obj.data.materials.append(material(color))
    if bevel:
        mod = obj.modifiers.new("Bevel", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        mod.limit_method = "ANGLE"
    attach(obj, parent)
    return obj


def cone(name, radius, depth, location, rotation=(0, 0, 0), color="spine", parent=None):
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=6, radius1=radius, radius2=0.0, depth=depth)
    for v in bm.verts:
        v.co.z += depth / 2
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = new_object(name, mesh)
    obj.location = location
    obj.rotation_euler = rotation
    obj.data.materials.append(material(color))
    attach(obj, parent)
    return obj


def sphere(name, radius, location, color="eye", parent=None):
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=1, radius=radius)
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = new_object(name, mesh)
    obj.location = location
    obj.data.materials.append(material(color))
    attach(obj, parent)
    return obj


def build():
    sc = scene()

    root = new_object("Kaiju", None)

    # The kaiju faces -Y in Blender, which is +Z (towards the camera) after glTF export.
    hips = box("Hips", (1.1, 0.9, 0.6), pivot=(0, 0, 1.7), taper=1.15, parent=root)
    chest = box("Chest", (1.25, 1.0, 1.1), pivot=(0, 0, 2.0), center=(0, -0.05, 2.55), taper=0.85, parent=hips)
    box("Belly", (0.8, 0.5, 1.4), pivot=(0, -0.33, 2.2), center=(0, -0.33, 2.2), taper=0.8, color="belly", bevel=0.1, parent=chest)

    head = box("Head", (0.9, 1.15, 0.75), pivot=(0, -0.25, 3.15), center=(0, -0.55, 3.45), taper=0.9, parent=chest)
    box("Snout", (0.65, 0.7, 0.4), pivot=(0, -1.0, 3.3), center=(0, -1.25, 3.3), color="hide", parent=head)
    box("Jaw", (0.6, 0.9, 0.22), pivot=(0, -0.7, 3.05), center=(0, -1.05, 3.02), color="belly", bevel=0.05, parent=head)
    box("Brow", (1.0, 0.5, 0.18), pivot=(0, -0.8, 3.8), center=(0, -0.8, 3.8), parent=head)
    sphere("EyeL", 0.13, (0.36, -0.95, 3.65), parent=head)
    sphere("EyeR", 0.13, (-0.36, -0.95, 3.65), parent=head)
    for i, x in enumerate((-0.18, 0.18)):
        cone(f"Tooth{i}", 0.05, 0.16, (x, -1.45, 3.12), rotation=(math.pi, 0, 0), color="claw", parent=head)

    # arms: origin at the shoulder, hanging forward
    for side, x in (("L", 0.78), ("R", -0.78)):
        arm = box(f"Arm{side}", (0.3, 0.3, 0.9), pivot=(x, -0.3, 2.85), center=(x, -0.45, 2.45), taper=0.8, parent=chest)
        arm.rotation_euler = (math.radians(35), 0, 0)
        for j, dx in enumerate((-0.08, 0.08)):
            cone(f"Claw{side}{j}", 0.05, 0.22, (x + dx, -0.55, 2.02), rotation=(math.radians(-90 - 35), 0, 0), color="claw", parent=arm)

    # legs: origin at the hip, foot as a child so it rotates with the leg
    for side, x in (("L", 0.55), ("R", -0.55)):
        leg = box(f"Leg{side}", (0.5, 0.55, 1.4), pivot=(x, 0, 1.55), center=(x, 0, 0.85), taper=1.3, parent=hips)
        box(f"Foot{side}", (0.55, 0.95, 0.3), pivot=(x, -0.1, 0.15), center=(x, -0.25, 0.15), parent=leg)
        for j, dx in enumerate((-0.16, 0.0, 0.16)):
            cone(f"Toe{side}{j}", 0.07, 0.28, (x + dx, -0.72, 0.15), rotation=(math.radians(-90), 0, 0), color="claw", parent=leg)

    # tail: a chain, each segment parented to the previous so a sway propagates
    parent = hips
    y, z = 0.3, 1.75
    sizes = ((0.95, 0.9, 0.7), (0.75, 0.9, 0.55), (0.55, 0.9, 0.4), (0.35, 0.9, 0.26))
    for i, size in enumerate(sizes):
        seg = box(f"Tail{i}", size, pivot=(0, y, z), center=(0, y + size[1] / 2, z - 0.05), color="hide", parent=parent)
        seg.rotation_euler = (math.radians(6), 0, 0)
        parent = seg
        y += size[1] - 0.08
        z += 0.02

    # dorsal spines, growing smaller down the back
    spine_parents = ((head, 3.85, -0.45), (chest, 3.05, 0.62), (chest, 2.65, 0.68), (chest, 2.25, 0.66), (hips, 1.9, 0.55))
    for i, (par, z, y) in enumerate(spine_parents):
        s = 0.42 - i * 0.05
        cone(f"Spine{i}", s * 0.55, s * 1.4, (0, y, z), rotation=(math.radians(-35), 0, 0), parent=par)

    return root


def export(root):
    bpy.ops.object.select_all(action="DESELECT")
    root.select_set(True)
    for child in root.children_recursive:
        child.select_set(True)
    bpy.context.view_layer.objects.active = root
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    bpy.ops.export_scene.gltf(
        filepath=OUT_PATH,
        export_format="GLB",
        use_selection=True,
        export_apply=True,
        export_yup=True,
        export_materials="EXPORT",
        export_animations=False,
        export_skins=False,
        export_morph=False,
    )
    return OUT_PATH


if __name__ == "__main__":
    print("exported", export(build()))
