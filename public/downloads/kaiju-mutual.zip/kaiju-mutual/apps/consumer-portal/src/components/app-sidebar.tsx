import { Link, useMatchRoute, useNavigate } from '@tanstack/react-router'
import {
  CalculatorIcon,
  ChevronsUpDownIcon,
  CreditCardIcon,
  FileTextIcon,
  LayoutDashboardIcon,
  LifeBuoyIcon,
  LogOutIcon,
  ShieldIcon,
  UserIcon,
} from 'lucide-react'
import { api } from '@/api'
import type { User } from '@/auth'
import { BrandMark } from '@/components/brand'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from '@/components/ui/sidebar'

const nav = [
  { to: '/', label: 'Overview', icon: LayoutDashboardIcon },
  { to: '/policies', label: 'Policies', icon: ShieldIcon },
  { to: '/claims', label: 'Claims', icon: FileTextIcon },
  { to: '/billing', label: 'Billing', icon: CreditCardIcon },
  { to: '/new-quote', label: 'Get a quote', icon: CalculatorIcon },
] as const

export function AppSidebar({ user }: { user: User }) {
  const matchRoute = useMatchRoute()
  const navigate = useNavigate()
  // The mobile sidebar is a sheet; close it once a page is picked.
  const { setOpenMobile } = useSidebar()
  const initials = user.name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild tooltip="Kaiju Mutual">
              <Link to="/">
                <BrandMark className="size-8! text-paper" />
                <span className="grid leading-tight">
                  <span className="text-base font-extrabold tracking-tight text-paper">
                    Kaiju Mutual
                  </span>
                  <span className="text-xs text-sidebar-foreground/70">Policyholder portal</span>
                </span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="gap-1">
              {nav.map((item) => (
                <SidebarMenuItem key={item.to}>
                  <SidebarMenuButton
                    asChild
                    tooltip={item.label}
                    isActive={Boolean(matchRoute({ to: item.to, fuzzy: item.to !== '/' }))}
                    className="h-9 text-[0.9375rem] data-active:bg-sidebar-accent data-active:shadow-[inset_3px_0_0_var(--siren)]"
                  >
                    <Link to={item.to} onClick={() => setOpenMobile(false)}>
                      <item.icon />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <div className="mx-2 mb-2 grid gap-1 rounded-lg border border-sidebar-border p-3 text-sm group-data-[collapsible=icon]:hidden">
          <span className="flex items-center gap-2 font-semibold text-paper">
            <LifeBuoyIcon className="size-4 text-siren" />
            24-hour hotline
          </span>
          <a href="tel:+18005248580" className="text-sidebar-foreground/80 hover:text-paper">
            1-800-524-8580
          </a>
        </div>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg" tooltip={user.name}>
                  <Avatar className="size-8 rounded-lg">
                    <AvatarFallback className="rounded-lg bg-siren font-bold text-night">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <span className="grid min-w-0 flex-1 leading-tight">
                    <span className="truncate font-semibold text-paper">{user.name}</span>
                    <span className="truncate text-xs text-sidebar-foreground/70">
                      {user.email}
                    </span>
                  </span>
                  <ChevronsUpDownIcon className="ml-auto" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                side="top"
                align="start"
                className="w-(--radix-dropdown-menu-trigger-width) min-w-56"
              >
                <DropdownMenuLabel className="font-normal text-muted-foreground">
                  Signed in as {user.email}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/profile">
                    <UserIcon />
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onSelect={async () => {
                    await api.session.$delete()
                    navigate({ to: '/login' })
                  }}
                >
                  <LogOutIcon />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
