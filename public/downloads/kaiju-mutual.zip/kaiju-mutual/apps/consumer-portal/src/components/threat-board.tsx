import { type ThreatLevel, threatLevels } from '@kaiju/api/enums'
import type { InferResponseType } from 'hono/client'
import type { api } from '@/api'
import { dateTime } from '@/lib/format'
import { cn } from '@/lib/utils'

type District = InferResponseType<typeof api.me.district.$get, 200>

// How we talk to customers about each level, so it lives here rather than in the forecast.
const advice: Record<ThreatLevel, string> = {
  Clear: 'No kaiju activity near your district. Nothing to do.',
  Watch:
    'A kaiju is contained nearby. Keep your go-bag by the door and your phone charged. No need to leave.',
  Advisory: 'Move vehicles off the avenue and check your nearest shelter is open.',
  Warning: 'Get ready to leave. Your temporary housing cover starts the moment sirens sound.',
  Evacuate: 'Leave now. Do not stop to photograph damage. You can start a claim from the shelter.',
}

const levelColor: Record<ThreatLevel, string> = {
  Clear: 'bg-hide',
  Watch: 'bg-[#e8b13a]',
  Advisory: 'bg-[#f48a2c]',
  Warning: 'bg-siren',
  Evacuate: 'bg-[#d43f0a]',
}

const levelText: Record<ThreatLevel, string> = {
  Clear: 'text-[#7fc4bd]',
  Watch: 'text-[#e8b13a]',
  Advisory: 'text-[#f48a2c]',
  Warning: 'text-siren',
  Evacuate: 'text-[#ff7a48]',
}

// The civil-defence board for the policyholder's district. It is the one loud
// thing on the overview page; everything around it stays quiet.
export function ThreatBoard({ district }: { district: District }) {
  const current = threatLevels.indexOf(district.level)
  const { driver, updatedAt } = district

  return (
    <section
      aria-labelledby="threat-heading"
      className="relative overflow-hidden rounded-2xl bg-night text-sidebar-foreground"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.07] [background-image:repeating-linear-gradient(-45deg,var(--paper)_0_2px,transparent_2px_14px)]"
      />
      <div className="relative grid gap-8 p-6 md:grid-cols-[1.4fr_1fr] md:p-8">
        <div className="grid content-start gap-6">
          <div className="grid gap-1">
            <h2 id="threat-heading" className="text-base font-medium text-sidebar-foreground/80">
              Threat level in {district.district}
            </h2>
            <p
              className={cn(
                'text-6xl leading-none font-extrabold tracking-[-0.04em] md:text-7xl',
                levelText[district.level],
              )}
            >
              {district.level}
            </p>
          </div>

          <ol className="grid grid-cols-5 gap-1.5" aria-label="Threat scale">
            {threatLevels.map((level, i) => (
              <li key={level} className="grid gap-2">
                <span
                  className={cn(
                    'h-2.5 rounded-full motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-left-2 motion-safe:fill-mode-both motion-safe:duration-500',
                    i <= current ? levelColor[district.level] : 'bg-white/12',
                  )}
                  style={{ animationDelay: `${i * 90}ms` }}
                />
                <span
                  className={cn(
                    'text-xs',
                    i === current ? 'font-semibold text-paper' : 'text-sidebar-foreground/55',
                  )}
                >
                  {level}
                </span>
              </li>
            ))}
          </ol>
        </div>

        <div className="grid content-between gap-6 border-white/10 md:border-l md:pl-8">
          <p className="text-lg leading-snug text-paper">{advice[district.level]}</p>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            <div>
              <dt className="text-sidebar-foreground/60">Nearest kaiju</dt>
              <dd className="font-semibold text-paper">
                {driver ? `${driver.name}, ${driver.status.toLowerCase()}` : 'No kaiju nearby'}
              </dd>
            </div>
            {driver && (
              <>
                <div>
                  <dt className="text-sidebar-foreground/60">Where</dt>
                  <dd className="font-semibold text-paper">{driver.location}</dd>
                </div>
                <div>
                  <dt className="text-sidebar-foreground/60">Size</dt>
                  <dd className="font-semibold text-paper">
                    {driver.class}, {driver.heightM} m
                  </dd>
                </div>
              </>
            )}
            {updatedAt && (
              <div>
                <dt className="text-sidebar-foreground/60">Updated</dt>
                <dd className="font-semibold text-paper">
                  {/* SQLite's `YYYY-MM-DD HH:MM:SS` is UTC but carries no zone. */}
                  {dateTime.format(new Date(`${updatedAt.replace(' ', 'T')}Z`))}
                </dd>
              </div>
            )}
          </dl>
        </div>
      </div>
    </section>
  )
}
