import { type ClaimStage, claimStages } from '@kaiju/api/enums'
import { cn } from '@/lib/utils'

// Claims move through a fixed sequence of stages, so this shows every stage and
// fills in the ones already reached.
export function ClaimProgress({ stage }: { stage: ClaimStage }) {
  const reached = claimStages.indexOf(stage)
  return (
    <ol className="grid grid-cols-4 gap-1.5" aria-label={`Claim stage: ${stage}`}>
      {claimStages.map((name, i) => (
        <li key={name} className="grid gap-1.5" aria-current={i === reached ? 'step' : undefined}>
          <span className={cn('h-1.5 rounded-full', i <= reached ? 'bg-hide' : 'bg-rule/70')} />
          <span
            className={cn(
              'text-xs',
              i === reached ? 'font-semibold text-foreground' : 'text-muted-foreground',
            )}
          >
            {name}
          </span>
        </li>
      ))}
    </ol>
  )
}
