import type { ReactNode } from 'react'

type Props = { title: string; description?: string; actions?: ReactNode }

export function PageHeader({ title, description, actions }: Props) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 border-b-2 border-rule pb-6">
      <div className="grid gap-2">
        <h1 className="text-3xl font-extrabold md:text-4xl">{title}</h1>
        {description && <p className="max-w-[60ch] text-muted-foreground">{description}</p>}
      </div>
      {actions}
    </div>
  )
}
