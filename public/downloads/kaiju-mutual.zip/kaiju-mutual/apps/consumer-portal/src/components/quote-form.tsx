import type { InferRequestType, InferResponseType } from 'hono/client'
import { type FormEvent, type ReactNode, useState } from 'react'
import { api, toastError, unwrap } from '@/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { day, money } from '@/lib/format'

type QuoteRequest = InferRequestType<typeof api.quotes.$post>['json']
type Quote = InferResponseType<typeof api.quotes.$post, 201>

// Starting values only; every field stays editable.
export type QuoteDefaults = Partial<Pick<QuoteRequest, 'name' | 'email' | 'district'>>

const plans: { value: QuoteRequest['plan']; hint: string }[] = [
  { value: 'Household', hint: 'Homes and apartments' },
  { value: 'Business', hint: 'Shops, offices, warehouses' },
  { value: 'Municipal', hint: 'Districts, utilities, transit' },
]

type Props = { defaults?: QuoteDefaults; heading?: ReactNode }

export function QuoteForm({ defaults = {}, heading }: Props) {
  const [quote, setQuote] = useState<Quote | null>(null)
  const [sending, setSending] = useState(false)

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const field = (name: string) => String(form.get(name) ?? '')
    setSending(true)
    try {
      const quote = await unwrap(
        api.quotes.$post({
          json: {
            plan: field('plan') as QuoteRequest['plan'],
            name: field('name'),
            email: field('email'),
            property: field('property'),
            address: field('address'),
            district: field('district'),
          },
        }),
      )
      setQuote(quote)
    } catch (err) {
      toastError(err)
    } finally {
      setSending(false)
    }
  }

  if (quote) return <QuoteResult quote={quote} onAgain={() => setQuote(null)} />

  return (
    <form onSubmit={submit} className="grid w-full max-w-xl gap-8">
      {heading}
      <FieldGroup>
        <FieldSet>
          <FieldLegend variant="label">Plan</FieldLegend>
          <RadioGroup name="plan" defaultValue="Household" className="grid gap-2 sm:grid-cols-3">
            {plans.map((plan) => (
              <FieldLabel key={plan.value} htmlFor={plan.value}>
                <Field orientation="horizontal">
                  <RadioGroupItem value={plan.value} id={plan.value} />
                  <FieldContent>
                    <span className="font-medium">{plan.value}</span>
                    <FieldDescription>{plan.hint}</FieldDescription>
                  </FieldContent>
                </Field>
              </FieldLabel>
            ))}
          </RadioGroup>
        </FieldSet>

        <div className="grid gap-6 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="name">Your name</FieldLabel>
            <Input
              id="name"
              name="name"
              autoComplete="name"
              required
              defaultValue={defaults.name}
              className="bg-white"
            />
          </Field>
          <Field>
            <FieldLabel htmlFor="email">Email</FieldLabel>
            <Input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              placeholder="you@example.com"
              defaultValue={defaults.email}
              className="bg-white"
            />
          </Field>
        </div>

        <Field>
          <FieldLabel htmlFor="property">What are we covering?</FieldLabel>
          <Input
            id="property"
            name="property"
            required
            placeholder="Apartment, corner shop, water treatment plant"
            className="bg-white"
          />
        </Field>

        <div className="grid gap-6 sm:grid-cols-[2fr_1fr]">
          <Field>
            <FieldLabel htmlFor="address">Address</FieldLabel>
            <Input
              id="address"
              name="address"
              autoComplete="street-address"
              required
              className="bg-white"
            />
          </Field>
          <Field>
            <FieldLabel htmlFor="district">District</FieldLabel>
            <Input
              id="district"
              name="district"
              required
              placeholder="Lower Cheswick"
              defaultValue={defaults.district}
              className="bg-white"
            />
          </Field>
        </div>
      </FieldGroup>
      <Button type="submit" size="lg" className="h-11 text-base" disabled={sending}>
        {sending ? 'Pricing…' : 'Get my price'}
      </Button>
    </form>
  )
}

function QuoteResult({ quote, onAgain }: { quote: Quote; onAgain: () => void }) {
  return (
    <div className="grid w-full max-w-md gap-6">
      <div className="grid gap-2">
        <h2 className="text-3xl font-extrabold">Your quote</h2>
        <p className="text-muted-foreground">
          Nothing is charged yet. Give us the reference below when you’re ready to take out the
          policy.
        </p>
      </div>
      <Card>
        <CardContent className="grid gap-4">
          <div>
            <p className="text-sm text-muted-foreground">
              {quote.plan} cover for {quote.property}, {quote.address}
            </p>
            <p className="text-5xl font-extrabold tracking-tight">
              {money.format(quote.monthly)}
              <span className="text-lg font-medium text-muted-foreground"> / month</span>
            </p>
          </div>
          <dl className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <dt className="text-muted-foreground">Reference</dt>
              <dd className="font-mono font-semibold">{quote.id}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Price holds until</dt>
              <dd className="font-semibold">{day.format(new Date(quote.expiresOn))}</dd>
            </div>
          </dl>
        </CardContent>
      </Card>
      <Button type="button" variant="outline" size="lg" onClick={onAgain}>
        Quote another property
      </Button>
    </div>
  )
}
