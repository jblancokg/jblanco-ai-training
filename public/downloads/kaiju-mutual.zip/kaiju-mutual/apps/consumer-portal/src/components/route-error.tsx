import { type ErrorComponentProps, useRouter } from '@tanstack/react-router'
import { ApiError } from '@/api'
import { PageHeader } from '@/components/page-header'
import { Button } from '@/components/ui/button'

// Shown in place of a page whose data didn't load. The request ID lets support find it.
export function RouteError({ error }: ErrorComponentProps) {
  const router = useRouter()
  return (
    <>
      <PageHeader
        title="Couldn't load this page"
        description={error instanceof Error ? error.message : String(error)}
      />
      {error instanceof ApiError && error.requestId && (
        <p className="text-sm text-muted-foreground">
          Quote reference <span className="font-mono text-foreground">{error.requestId}</span> to
          support.
        </p>
      )}
      <Button variant="outline" className="justify-self-start" onClick={() => router.invalidate()}>
        Try again
      </Button>
    </>
  )
}
