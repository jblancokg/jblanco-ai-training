import { createFileRoute, Link } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { PageHeader } from '@/components/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { day, money } from '@/lib/format'

export const Route = createFileRoute('/_portal/policies')({
  loader: () => unwrap(api.me.policies.$get()),
  component: Policies,
})

function Policies() {
  const policies = Route.useLoaderData()
  return (
    <>
      <PageHeader title="Policies" description="What each policy covers and how much of it." />
      <div className="grid gap-6">
        {policies.map((policy) => (
          <Card key={policy.id}>
            <CardHeader>
              <CardTitle className="text-xl">{policy.property}</CardTitle>
              <CardDescription>
                {policy.address}. Policy {policy.id}
              </CardDescription>
              <CardAction>
                <Badge variant="secondary">{policy.plan}</Badge>
              </CardAction>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cover</TableHead>
                    <TableHead className="text-right">Limit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {policy.cover.map((row) => (
                    <TableRow key={row.item}>
                      <TableCell>{row.item}</TableCell>
                      <TableCell className="text-right font-medium">{row.limit}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex flex-wrap items-center justify-between gap-4 border-t bg-muted/50 py-4">
              <p className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">
                  {money.format(policy.monthly)} a month
                </span>
                , renews {day.format(new Date(policy.renewsOn))}
              </p>
              <Button variant="outline" asChild>
                <Link to="/claims/new" search={{ policy: policy.id }}>
                  Start a claim on this policy
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </>
  )
}
