import { createFileRoute, Link, Outlet, redirect } from '@tanstack/react-router'
import { PlusIcon } from 'lucide-react'
import { getUser } from '@/auth'
import { AppSidebar } from '@/components/app-sidebar'
import { Button } from '@/components/ui/button'
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'

// Every page behind sign-in lives under this layout.
export const Route = createFileRoute('/_portal')({
  // Asks the API on every navigation, so the portal never decides whose data to show.
  beforeLoad: async ({ location }) => {
    const user = await getUser()
    if (!user) throw redirect({ to: '/login', search: { redirect: location.href } })
    return { user }
  },
  component: PortalLayout,
})

function PortalLayout() {
  const { user } = Route.useRouteContext()
  return (
    <SidebarProvider>
      <AppSidebar user={user} />
      <SidebarInset className="bg-background">
        <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b border-rule/60 bg-background/90 px-4 backdrop-blur md:px-8">
          <SidebarTrigger className="-ml-1" />
          <Button asChild className="ml-auto">
            <Link to="/claims/new">
              <PlusIcon />
              Start a claim
            </Link>
          </Button>
        </header>
        <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-8 md:px-8 md:py-10">
          <Outlet />
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
