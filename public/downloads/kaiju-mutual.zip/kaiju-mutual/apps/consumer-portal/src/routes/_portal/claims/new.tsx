import { plansCovered } from '@kaiju/api/enums'
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { TriangleAlertIcon } from 'lucide-react'
import { type FormEvent, useState } from 'react'
import { toast } from 'sonner'
import { api, toastError, unwrap } from '@/api'
import { PageHeader } from '@/components/page-header'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Field,
  FieldDescription,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'

type NewClaimSearch = { policy?: string }

export const Route = createFileRoute('/_portal/claims/new')({
  validateSearch: (search: Record<string, unknown>): NewClaimSearch => ({
    policy: typeof search.policy === 'string' ? search.policy : undefined,
  }),
  loader: async () => {
    const [policies, perils, kaiju] = await Promise.all([
      unwrap(api.me.policies.$get()),
      unwrap(api.reference.perils.$get()),
      unwrap(api.kaiju.$get()),
    ])
    return { policies, perils, kaiju }
  },
  component: NewClaim,
})

// A Select item can't have an empty value, so this stands in for not knowing.
const unknownKaiju = 'unknown'

function NewClaim() {
  const search = Route.useSearch()
  const { policies, perils, kaiju } = Route.useLoaderData()
  const navigate = useNavigate()
  const [policyId, setPolicyId] = useState(
    policies.find((p) => p.id === search.policy)?.id ?? policies[0]?.id ?? '',
  )
  // Only the perils the policy's plan covers can be claimed for.
  const coveredBy = (id: string) => {
    const plan = policies.find((p) => p.id === id)?.plan
    return perils.filter((p) => plan !== undefined && plansCovered[p.covered].includes(plan))
  }
  const covered = coveredBy(policyId)
  const [peril, setPeril] = useState(covered[0]?.name ?? '')
  const [sending, setSending] = useState(false)

  // Keep the chosen peril if the new policy covers it too.
  const choosePolicy = (id: string) => {
    setPolicyId(id)
    const next = coveredBy(id)
    if (!next.some((p) => p.name === peril)) setPeril(next[0]?.name ?? '')
  }

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const field = (name: string) => String(form.get(name) ?? '')
    setSending(true)
    try {
      const claim = await unwrap(
        api.me.claims.$post({
          json: {
            policyId,
            title: field('title'),
            peril,
            occurredOn: field('occurredOn'),
            kaiju: field('kaiju') === unknownKaiju ? null : field('kaiju'),
            description: field('description'),
          },
        }),
      )
      toast.success(`Claim ${claim.id} started`, {
        description: 'An assessor will call within 48 hours of the all-clear.',
      })
      await navigate({ to: '/claims' })
    } catch (err) {
      toastError(err)
    } finally {
      setSending(false)
    }
  }

  return (
    <>
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link to="/claims">Claims</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>Start a claim</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <PageHeader
        title="Start a claim"
        description="Tell us what happened. It takes two minutes and you can add photos and details later."
      />

      <Alert className="border-siren/40 bg-siren/10">
        <TriangleAlertIcon className="text-siren" />
        <AlertTitle>Is the kaiju still in your district?</AlertTitle>
        <AlertDescription>
          Get to a shelter first. Nothing in your policy asks you to stay and take photos.
        </AlertDescription>
      </Alert>

      <Card>
        <CardContent>
          <form onSubmit={submit} className="grid max-w-2xl gap-8">
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="policy">Policy</FieldLabel>
                <Select value={policyId} onValueChange={choosePolicy} required>
                  <SelectTrigger id="policy" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {policies.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.property}, {p.address}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field>
                <FieldLabel htmlFor="title">In a few words</FieldLabel>
                <Input
                  id="title"
                  name="title"
                  required
                  placeholder="Garden wall flattened by a tail sweep"
                />
              </Field>

              <FieldSet>
                <FieldLegend variant="label">What was damaged?</FieldLegend>
                <RadioGroup
                  value={peril}
                  onValueChange={setPeril}
                  required
                  className="grid gap-2 sm:grid-cols-2"
                >
                  {covered.map((p) => (
                    <FieldLabel key={p.id} htmlFor={p.id}>
                      <Field orientation="horizontal">
                        <RadioGroupItem value={p.name} id={p.id} />
                        <span className="font-medium">{p.name}</span>
                      </Field>
                    </FieldLabel>
                  ))}
                </RadioGroup>
              </FieldSet>

              <div className="grid gap-6 sm:grid-cols-2">
                <Field>
                  <FieldLabel htmlFor="occurredOn">When did it happen?</FieldLabel>
                  <Input id="occurredOn" name="occurredOn" type="date" required />
                </Field>
                <Field>
                  <FieldLabel htmlFor="kaiju">Which kaiju?</FieldLabel>
                  <Select name="kaiju" defaultValue={unknownKaiju}>
                    <SelectTrigger id="kaiju" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={unknownKaiju}>I don’t know</SelectItem>
                      {kaiju.map((k) => (
                        <SelectItem key={k.id} value={k.name}>
                          {k.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FieldDescription>
                    We match it against the city sighting network.
                  </FieldDescription>
                </Field>
              </div>

              <Field>
                <FieldLabel htmlFor="description">What happened?</FieldLabel>
                <Textarea
                  id="description"
                  name="description"
                  rows={5}
                  required
                  placeholder="The tail took out the garden wall and the shed behind it."
                />
              </Field>
            </FieldGroup>

            <div className="flex flex-wrap gap-3">
              <Button type="submit" size="lg" disabled={sending}>
                {sending ? 'Sending…' : 'Start claim'}
              </Button>
              <Button type="button" variant="ghost" size="lg" asChild>
                <Link to="/claims">Cancel</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </>
  )
}
