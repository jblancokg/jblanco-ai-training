import { createFileRoute, Link } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ClaimProgress } from '@/components/claim-progress'
import { ThreatBoard } from '@/components/threat-board'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { day, money } from '@/lib/format'

export const Route = createFileRoute('/_portal/')({
  loader: async () => {
    const [district, claims, payments, policies] = await Promise.all([
      unwrap(api.me.district.$get()),
      unwrap(api.me.claims.$get()),
      unwrap(api.me.payments.$get()),
      unwrap(api.me.policies.$get()),
    ])
    return { district, claims, payments, policies }
  },
  component: Overview,
})

function Overview() {
  const { user } = Route.useRouteContext()
  const { district, claims, payments, policies } = Route.useLoaderData()
  const openClaims = claims.filter((claim) => claim.stage !== 'Paid')
  // Newest first, so the soonest scheduled payment is the last one.
  const nextPayment = payments.findLast((payment) => payment.status === 'Scheduled')

  return (
    <>
      <h1 className="text-3xl font-extrabold md:text-4xl">Hello, {user.name.split(' ')[0]}</h1>

      <ThreatBoard district={district} />

      <div className="grid items-start gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Open claims</CardTitle>
            <CardAction>
              <Button variant="link" asChild className="h-auto p-0 text-foreground">
                <Link to="/claims">All claims</Link>
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent className="grid gap-5">
            {openClaims.length === 0 && (
              <p className="text-muted-foreground">
                No open claims. If something is damaged, start a claim and an assessor will be in
                touch.
              </p>
            )}
            {openClaims.map((claim) => (
              <div key={claim.id} className="grid gap-3">
                <div className="grid gap-0.5">
                  <p className="font-semibold">{claim.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {claim.id}, reported {day.format(new Date(claim.reportedOn))}
                  </p>
                </div>
                <ClaimProgress stage={claim.stage} />
                {claim.note && <p className="text-sm">{claim.note}</p>}
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="grid content-start gap-6">
          {nextPayment && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Next payment</CardTitle>
                <CardAction>
                  <Button variant="link" asChild className="h-auto p-0 text-foreground">
                    <Link to="/billing">Billing</Link>
                  </Button>
                </CardAction>
              </CardHeader>
              <CardContent className="grid gap-1">
                <p className="text-3xl font-extrabold tabular-nums">
                  {money.format(nextPayment.amount)}
                </p>
                <p className="text-sm text-muted-foreground">
                  {user.card
                    ? `Taken from ${user.card.brand} ending ${user.card.last4} on `
                    : 'Due on '}
                  {day.format(new Date(nextPayment.date))}
                </p>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your policies</CardTitle>
              <CardAction>
                <Button variant="link" asChild className="h-auto p-0 text-foreground">
                  <Link to="/policies">Details</Link>
                </Button>
              </CardAction>
            </CardHeader>
            <CardContent>
              <ul className="grid divide-y divide-rule/60">
                {policies.map((policy) => (
                  <li
                    key={policy.id}
                    className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0"
                  >
                    <div className="grid min-w-0">
                      <span className="truncate font-semibold">{policy.property}</span>
                      <span className="truncate text-sm text-muted-foreground">
                        {policy.address}
                      </span>
                    </div>
                    <Badge variant="outline">{policy.plan}</Badge>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
