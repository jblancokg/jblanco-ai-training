import { createFileRoute } from '@tanstack/react-router'
import type { InferResponseType } from 'hono/client'
import { api, unwrap } from '@/api'
import { ClaimProgress } from '@/components/claim-progress'
import { PageHeader } from '@/components/page-header'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { day, money } from '@/lib/format'

export const Route = createFileRoute('/_portal/claims/')({
  loader: () => unwrap(api.me.claims.$get()),
  component: Claims,
})

type Claim = InferResponseType<typeof api.me.claims.$get, 200>[number]

function Claims() {
  const claims = Route.useLoaderData()
  const open = claims.filter((claim) => claim.stage !== 'Paid')
  const settled = claims.filter((claim) => claim.stage === 'Paid')

  return (
    <>
      <PageHeader
        title="Claims"
        description="Every claim goes from report, to an assessor visit, to a decision, to payment. Temporary housing is paid the same day."
      />
      <Tabs defaultValue="open">
        <TabsList className="bg-rule/50">
          <TabsTrigger value="open" className="data-active:bg-paper">
            Open ({open.length})
          </TabsTrigger>
          <TabsTrigger value="settled" className="data-active:bg-paper">
            Settled ({settled.length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value="open" className="mt-4">
          <ClaimList claims={open} empty="No open claims." />
        </TabsContent>
        <TabsContent value="settled" className="mt-4">
          <ClaimList claims={settled} empty="No settled claims yet." />
        </TabsContent>
      </Tabs>
    </>
  )
}

function ClaimList({ claims, empty }: { claims: Claim[]; empty: string }) {
  if (claims.length === 0) return <p className="text-muted-foreground">{empty}</p>
  return (
    <div className="grid gap-4">
      {claims.map((claim) => (
        <Card key={claim.id}>
          <CardContent className="grid gap-5 md:grid-cols-[1fr_20rem] md:items-center md:gap-8">
            <div className="grid gap-1">
              <p className="text-lg font-semibold">{claim.title}</p>
              <p className="text-sm text-muted-foreground">
                {claim.id} on {claim.policyProperty}. Caused by{' '}
                {claim.kaiju ?? 'a kaiju we haven’t matched yet'}, reported{' '}
                {day.format(new Date(claim.reportedOn))}.
              </p>
              {claim.note && <p className="mt-2 text-sm">{claim.note}</p>}
            </div>
            <div className="grid gap-3">
              <ClaimProgress stage={claim.stage} />
              {claim.stage === 'Paid' && (
                <p className="text-sm text-muted-foreground">
                  Settled for{' '}
                  <span className="font-semibold text-foreground">
                    {money.format(claim.estimate)}
                  </span>
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
