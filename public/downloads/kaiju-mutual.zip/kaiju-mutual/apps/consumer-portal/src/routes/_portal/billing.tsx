import type { PaymentStatus } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { CreditCardIcon, EllipsisIcon } from 'lucide-react'
import { useState } from 'react'
import { api, unwrap } from '@/api'
import { PageHeader } from '@/components/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { day, money } from '@/lib/format'

export const Route = createFileRoute('/_portal/billing')({
  loader: async () => {
    const [payments, policies] = await Promise.all([
      unwrap(api.me.payments.$get()),
      unwrap(api.me.policies.$get()),
    ])
    return { payments, policies }
  },
  component: Billing,
})

const statusVariant = {
  Scheduled: 'default',
  Paid: 'outline',
  Refunded: 'secondary',
} as const satisfies Record<PaymentStatus, 'default' | 'outline' | 'secondary'>

type Payment = Awaited<ReturnType<typeof Route.useLoaderData>>['payments'][number]

type ReceiptCopy = { title: string; charged: string }

// Every payment is either taken or about to be.
const receiptCopy: Record<string, ReceiptCopy> = {
  Paid: { title: 'Payment receipt', charged: 'Charged to' },
  Scheduled: { title: 'Upcoming payment', charged: 'Will be charged to' },
}

function Billing() {
  const { user } = Route.useRouteContext()
  const { payments, policies } = Route.useLoaderData()
  const monthly = policies.reduce((total, policy) => total + policy.monthly, 0)
  // Newest first, so the soonest scheduled payment is the last one.
  const next = payments.findLast((payment) => payment.status === 'Scheduled')
  const [receipt, setReceipt] = useState<Payment>()

  return (
    <>
      <PageHeader title="Billing" description="Premiums are taken on the first of each month." />

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Monthly premium</CardDescription>
            <CardTitle className="text-3xl font-extrabold tabular-nums">
              {money.format(monthly)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            Across {policies.length} policies
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Next payment</CardDescription>
            <CardTitle className="text-3xl font-extrabold">
              {next ? day.format(new Date(next.date)) : 'None scheduled'}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            {next ? money.format(next.amount) : 'Your policies are paid up'}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Paying with</CardDescription>
            <CardTitle className="flex items-center gap-2 text-xl">
              <CreditCardIcon className="size-5" />
              {user.card ? `${user.card.brand} ending ${user.card.last4}` : 'No card on file'}
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-1 text-sm text-muted-foreground">
            {user.card && <span>Expires {user.card.expires}</span>}
            <span>
              To change your card, call{' '}
              <a href="tel:+18005248580" className="font-medium text-foreground underline">
                1-800-524-8580
              </a>
              .
            </span>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Payment history</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="w-10">
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell className="whitespace-nowrap">
                    {day.format(new Date(payment.date))}
                  </TableCell>
                  <TableCell>{payment.description}</TableCell>
                  <TableCell>
                    <Badge variant={statusVariant[payment.status]}>{payment.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium tabular-nums">
                    {money.format(payment.amount)}
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="size-8">
                          <EllipsisIcon />
                          <span className="sr-only">More for {payment.description}</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onSelect={() => setReceipt(payment)}>
                          View receipt
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onSelect={() => navigator.clipboard.writeText(payment.id)}
                        >
                          Copy reference
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Sheet open={!!receipt} onOpenChange={(open) => !open && setReceipt(undefined)}>
        <SheetContent>{receipt && <Receipt payment={receipt} />}</SheetContent>
      </Sheet>
    </>
  )
}

function Receipt({ payment }: { payment: Payment }) {
  const { user } = Route.useRouteContext()
  const copy = receiptCopy[payment.status] as ReceiptCopy
  return (
    <>
      <SheetHeader>
        <SheetTitle>{copy.title}</SheetTitle>
        <SheetDescription>Reference {payment.id}</SheetDescription>
      </SheetHeader>
      <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 px-4 text-sm">
        <dt className="text-muted-foreground">Date</dt>
        <dd>{day.format(new Date(payment.date))}</dd>
        <dt className="text-muted-foreground">For</dt>
        <dd>{payment.description}</dd>
        <dt className="text-muted-foreground">Amount</dt>
        <dd className="font-semibold tabular-nums">{money.format(payment.amount)}</dd>
        <dt className="text-muted-foreground">{copy.charged}</dt>
        <dd>{user.card ? `${user.card.brand} ending ${user.card.last4}` : 'No card on file'}</dd>
      </dl>
    </>
  )
}
