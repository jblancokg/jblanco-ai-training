import { createFileRoute } from '@tanstack/react-router'
import { type FormEvent, useState } from 'react'
import { api, useSave } from '@/api'
import { PageHeader } from '@/components/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldGroup,
  FieldLabel,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'

export const Route = createFileRoute('/_portal/profile')({
  component: Profile,
})

const notifications = [
  {
    key: 'notifyThreat',
    label: 'Threat level changes',
    hint: 'When your district moves up or down the scale. Warnings and evacuations are always sent.',
  },
  {
    key: 'notifyClaims',
    label: 'Claim updates',
    hint: 'Assessor bookings, decisions and payments.',
  },
  { key: 'notifyBilling', label: 'Payment reminders', hint: 'Three days before each premium.' },
  {
    key: 'notifyNews',
    label: 'Newsletter',
    hint: 'Seasonal migration forecasts and shelter news.',
  },
] as const

function Profile() {
  const { user } = Route.useRouteContext()
  const save = useSave()
  const [saving, setSaving] = useState(false)

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    // Blank clears the phone or address.
    const optional = (name: string) => String(form.get(name) ?? '').trim() || null
    setSaving(true)
    await save(
      api.me.$patch({
        json: {
          name: String(form.get('name') ?? ''),
          email: String(form.get('email') ?? ''),
          phone: optional('phone'),
          address: optional('address'),
        },
      }),
      'Contact details saved',
    )
    setSaving(false)
  }

  return (
    <>
      <PageHeader
        title="Profile"
        description="How we reach you before, during and after an attack."
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Contact details</CardTitle>
          <CardDescription>Your phone number is where evacuation alerts go.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="grid max-w-2xl gap-6">
            <FieldGroup className="grid gap-6 sm:grid-cols-2">
              <Field>
                <FieldLabel htmlFor="name">Full name</FieldLabel>
                <Input id="name" name="name" required defaultValue={user.name} />
              </Field>
              <Field>
                <FieldLabel htmlFor="email">Email</FieldLabel>
                <Input id="email" name="email" type="email" required defaultValue={user.email} />
              </Field>
              <Field>
                <FieldLabel htmlFor="phone">Mobile phone</FieldLabel>
                <Input id="phone" name="phone" type="tel" defaultValue={user.phone ?? ''} />
              </Field>
              <Field>
                <FieldLabel htmlFor="address">Home address</FieldLabel>
                <Input id="address" name="address" defaultValue={user.address ?? ''} />
              </Field>
            </FieldGroup>
            <div>
              <Button type="submit" disabled={saving}>
                {saving ? 'Saving…' : 'Save changes'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Notifications</CardTitle>
        </CardHeader>
        <CardContent className="grid max-w-2xl gap-4">
          {notifications.map((item, i) => (
            <div key={item.key} className="grid gap-4">
              {i > 0 && <Separator />}
              <Field orientation="horizontal">
                <FieldContent>
                  <FieldLabel htmlFor={item.key}>{item.label}</FieldLabel>
                  <FieldDescription>{item.hint}</FieldDescription>
                </FieldContent>
                <Switch
                  id={item.key}
                  checked={user[item.key]}
                  onCheckedChange={(on) =>
                    save(
                      api.me.$patch({ json: { [item.key]: on } }),
                      `${item.label} turned ${on ? 'on' : 'off'}`,
                    )
                  }
                />
              </Field>
            </div>
          ))}
        </CardContent>
      </Card>
    </>
  )
}
