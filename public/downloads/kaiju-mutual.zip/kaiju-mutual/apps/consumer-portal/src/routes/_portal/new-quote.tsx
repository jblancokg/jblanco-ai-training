import { createFileRoute } from '@tanstack/react-router'
import { PageHeader } from '@/components/page-header'
import { QuoteForm } from '@/components/quote-form'
import { Card, CardContent } from '@/components/ui/card'

// Not `/quote`: this layout is pathless, so that path belongs to the public page.
export const Route = createFileRoute('/_portal/new-quote')({
  component: NewQuote,
})

function NewQuote() {
  const { user } = Route.useRouteContext()

  return (
    <>
      <PageHeader
        title="Get a quote"
        description="Cover another home, shop or site. We’ve filled in your details and home district; change anything that doesn’t apply."
      />

      <Card>
        <CardContent>
          {/* No property or address: a new quote is rarely for a covered place. */}
          <QuoteForm defaults={{ name: user.name, email: user.email, district: user.district }} />
        </CardContent>
      </Card>
    </>
  )
}
