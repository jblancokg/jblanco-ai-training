import { createFileRoute, redirect, useNavigate } from '@tanstack/react-router'
import { type FormEvent, useState } from 'react'
import { ApiError, api, unwrap } from '@/api'
import { getUser } from '@/auth'
import { BrandMark } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'

type LoginSearch = { redirect?: string }

export const Route = createFileRoute('/login')({
  validateSearch: (search: Record<string, unknown>): LoginSearch => ({
    redirect: typeof search.redirect === 'string' ? search.redirect : undefined,
  }),
  beforeLoad: async () => {
    if (await getUser()) throw redirect({ to: '/' })
  },
  component: Login,
})

function Login() {
  const { redirect: back } = Route.useSearch()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setSending(true)
    setError(null)
    try {
      await unwrap(api.session.$post({ json: { email } }))
      await navigate({ to: back ?? '/' })
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : 'We couldn’t reach Kaiju Mutual. Check your connection and try again.',
      )
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="grid min-h-svh lg:grid-cols-[1.1fr_1fr]">
      <aside className="relative flex flex-col justify-between gap-12 overflow-hidden bg-night p-8 text-paper md:p-12">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:repeating-linear-gradient(-45deg,var(--paper)_0_2px,transparent_2px_14px)]"
        />
        <div className="relative flex items-center gap-3 text-xl font-extrabold tracking-tight">
          <BrandMark className="size-8" />
          Kaiju Mutual
        </div>
        <div className="relative grid gap-5">
          <h1 className="max-w-[14ch] text-5xl leading-[0.95] font-extrabold tracking-[-0.035em] md:text-6xl">
            Your cover, your claims, your district.
          </h1>
          <p className="max-w-[44ch] text-lg text-sidebar-foreground">
            See what your policy covers, follow a claim from report to payment, and check the threat
            level where you live.
          </p>
        </div>
        <p className="relative text-sm text-sidebar-foreground/80">
          Kaiju in your street right now? Leave first. Call{' '}
          <a
            href="tel:+18005248580"
            className="font-semibold text-paper underline underline-offset-4"
          >
            1-800-524-8580
          </a>{' '}
          from the shelter.
        </p>
      </aside>

      <main className="flex items-center justify-center bg-paper p-8 md:p-12">
        <form onSubmit={submit} className="grid w-full max-w-sm gap-8">
          <div className="grid gap-2">
            <h2 className="text-3xl font-extrabold">Sign in</h2>
            <p className="text-muted-foreground">Use the email address on your policy.</p>
          </div>
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="email">Email</FieldLabel>
              <Input
                id="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                aria-invalid={error ? true : undefined}
                className="h-10 bg-white"
              />
              <FieldError>{error}</FieldError>
            </Field>
            <Field>
              <FieldLabel htmlFor="password">Password</FieldLabel>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                className="h-10 bg-white"
              />
              <FieldDescription>
                Any password works while the portal is in training. Try{' '}
                <span className="font-medium text-foreground">dana.okafor@example.com</span>.
              </FieldDescription>
            </Field>
          </FieldGroup>
          <Button type="submit" size="lg" className="h-11 text-base" disabled={sending}>
            {sending ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>
      </main>
    </div>
  )
}
