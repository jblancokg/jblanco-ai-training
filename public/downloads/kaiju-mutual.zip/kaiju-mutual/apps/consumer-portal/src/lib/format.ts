export const money = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
})

// API dates are plain `YYYY-MM-DD`, which JS parses as UTC midnight, so read them in UTC too.
export const day = new Intl.DateTimeFormat('en-US', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  timeZone: 'UTC',
})

// For timestamps, in the customer's own time zone. Don't use `day` for these: it reads in UTC
// and can land on the wrong date.
export const dateTime = new Intl.DateTimeFormat('en-US', {
  day: 'numeric',
  month: 'short',
  hour: 'numeric',
  minute: '2-digit',
})
