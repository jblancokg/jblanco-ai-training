// Sign-in is the API's job: it sets a cookie and answers who that is. The password is ignored.
// See docs/training/consumer-portal.md.
import { ApiError, api, unwrap } from '@/api'

// The signed-in policyholder's profile, or null when nobody is signed in.
export async function getUser() {
  try {
    return await unwrap(api.me.$get())
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) return null
    throw err
  }
}

export type User = NonNullable<Awaited<ReturnType<typeof getUser>>>
