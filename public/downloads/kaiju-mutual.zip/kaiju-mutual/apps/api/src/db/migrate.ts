// drizzle-kit migrate can't open bun:sqlite databases, so migrations run through the ORM instead.
import { migrate } from 'drizzle-orm/bun-sqlite/migrator'
import { rootLogger } from '../log'
import { db } from '.'

migrate(db, { migrationsFolder: 'drizzle' })
rootLogger.info('migrations applied')
