import { Database } from 'bun:sqlite'
import { drizzle } from 'drizzle-orm/bun-sqlite'
import { sqlLogger } from '../log'
import * as schema from './schema'

export const dbFile = 'kaiju.db'

const sqlite = new Database(dbFile)
// SQLite leaves foreign keys unchecked unless asked, per connection.
sqlite.run('PRAGMA foreign_keys = ON')

export const db = drizzle(sqlite, { schema, logger: sqlLogger })
