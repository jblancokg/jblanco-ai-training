// Drizzle table definitions live here. Run `bun run db:generate` after changing them.
import { sql } from 'drizzle-orm'
import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core'
import {
  claimStages,
  eventTypes,
  handlerTeams,
  kaijuStatuses,
  municipalAssetKinds,
  paymentStatuses,
  perilCoverage,
  planNames,
  policyStatuses,
  regionCoasts,
  type ThreatLevel,
  threatLevels,
} from '../enums'

// Every table spreads these in. Rows are soft-deleted: set `deletedAt` instead of deleting,
// and filter on `isNull(table.deletedAt)` when reading.
const timestamps = {
  createdAt: text().notNull().default(sql`(current_timestamp)`),
  updatedAt: text()
    .notNull()
    .default(sql`(current_timestamp)`)
    .$onUpdate(() => sql`(current_timestamp)`),
  deletedAt: text(),
}

// Rows point at a reference list entry by its name, so renaming the entry renames it everywhere.
const followRenames = { onUpdate: 'cascade' } as const

// Readable ids for rows staff quote to customers: a prefix and 8 random characters from an
// alphabet without look-alikes (no 0/O or 1/I). 40 bits, so collisions are not a concern.
const idAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
export function newId(prefix: string) {
  const bytes = crypto.getRandomValues(new Uint8Array(8))
  return `${prefix}-${Array.from(bytes, (b) => idAlphabet[b % idAlphabet.length]).join('')}`
}

// Reference lists. Staff add, edit and delete these; the server makes the ids.

export const regions = sqliteTable('regions', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('RG')),
  name: text().notNull().unique(),
  coast: text({ enum: regionCoasts }).notNull(),
  ...timestamps,
})

export const districts = sqliteTable('districts', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('DS')),
  code: text().notNull().unique(),
  name: text().notNull().unique(),
  region: text()
    .notNull()
    .references(() => regions.name, followRenames),
  shelterBeds: integer().notNull(),
  ...timestamps,
})

export const kaijuClasses = sqliteTable('kaiju_classes', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('KC')),
  name: text().notNull().unique(),
  minHeightM: integer().notNull(),
  maxHeightM: integer().notNull(),
  description: text().notNull(),
  ...timestamps,
})

export const perils = sqliteTable('perils', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('PE')),
  name: text().notNull().unique(),
  covered: text({ enum: perilCoverage }).notNull(),
  ...timestamps,
})

export const plans = sqliteTable('plans', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('PL')),
  name: text({ enum: planNames }).notNull().unique(),
  // Whole dollars.
  monthlyFrom: integer().notNull(),
  excess: integer().notNull(),
  ...timestamps,
})

// What a plan covers, and up to what, in the words the portal shows.
export const planCover = sqliteTable('plan_cover', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('CV')),
  plan: text({ enum: planNames })
    .notNull()
    .references(() => plans.name, followRenames),
  item: text().notNull(),
  // Free text, such as "Rebuild cost" or "90 days".
  limit: text().notNull(),
  ...timestamps,
})

export const handlers = sqliteTable('handlers', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('HD')),
  name: text().notNull().unique(),
  email: text().notNull(),
  team: text({ enum: handlerTeams }).notNull(),
  ...timestamps,
})

// Claims handling.

export const policyholders = sqliteTable('policyholders', {
  id: text().primaryKey(),
  name: text().notNull(),
  email: text().notNull(),
  phone: text(),
  // Home address.
  address: text(),
  district: text()
    .notNull()
    .references(() => districts.name, followRenames),
  // ISO date (YYYY-MM-DD).
  customerSince: text().notNull(),
  // What they want to hear about.
  notifyThreat: integer({ mode: 'boolean' }).notNull().default(true),
  notifyClaims: integer({ mode: 'boolean' }).notNull().default(true),
  notifyBilling: integer({ mode: 'boolean' }).notNull().default(true),
  notifyNews: integer({ mode: 'boolean' }).notNull().default(false),
  // The card premiums are taken from. Never the full number. Expires is MM/YY.
  cardBrand: text(),
  cardLast4: text(),
  cardExpires: text(),
  ...timestamps,
})

export const policies = sqliteTable('policies', {
  id: text().primaryKey(),
  policyholderId: text()
    .notNull()
    .references(() => policyholders.id),
  plan: text({ enum: planNames })
    .notNull()
    .references(() => plans.name, followRenames),
  property: text().notNull(),
  address: text().notNull(),
  district: text()
    .notNull()
    .references(() => districts.name, followRenames),
  // Whole dollars.
  monthly: integer().notNull(),
  // ISO date (YYYY-MM-DD).
  renewsOn: text().notNull(),
  status: text({ enum: policyStatuses }).notNull(),
  ...timestamps,
})

// Kaiju watch.

export const kaiju = sqliteTable('kaiju', {
  id: text().primaryKey(),
  name: text().notNull().unique(),
  class: text()
    .notNull()
    .references(() => kaijuClasses.name, followRenames),
  heightM: integer().notNull(),
  status: text({ enum: kaijuStatuses }).notNull(),
  location: text().notNull(),
  nearestDistrict: text()
    .notNull()
    .references(() => districts.name, followRenames),
  heading: text(),
  // ISO date and time, local.
  lastSeen: text().notNull(),
  ...timestamps,
})

// One threat level per day for seven days, starting at `startsOn`.
export type ForecastDays = [
  ThreatLevel,
  ThreatLevel,
  ThreatLevel,
  ThreatLevel,
  ThreatLevel,
  ThreatLevel,
  ThreatLevel,
]

export const forecasts = sqliteTable('forecasts', {
  id: text().primaryKey(),
  district: text()
    .notNull()
    .unique()
    .references(() => districts.name, followRenames),
  // ISO date (YYYY-MM-DD).
  startsOn: text().notNull(),
  days: text({ mode: 'json' }).$type<ForecastDays>().notNull(),
  // The kaiju behind the forecast, if any.
  driver: text().references(() => kaiju.name, followRenames),
  note: text().notNull(),
  ...timestamps,
})

export const events = sqliteTable('events', {
  id: text().primaryKey(),
  // ISO date and time, local.
  at: text().notNull(),
  type: text({ enum: eventTypes }).notNull(),
  kaiju: text()
    .notNull()
    .references(() => kaiju.name, followRenames),
  district: text()
    .notNull()
    .references(() => districts.name, followRenames),
  summary: text().notNull(),
  // Set on threat level changes.
  level: text({ enum: threatLevels }),
  ...timestamps,
})

export const claims = sqliteTable('claims', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('CL')),
  // The policyholder comes from the policy.
  policyId: text()
    .notNull()
    .references(() => policies.id),
  // The kaiju event that caused it, when we know.
  eventId: text().references(() => events.id),
  title: text().notNull(),
  // The customer's own account of what happened.
  description: text(),
  // Null until someone knows which kaiju it was.
  kaiju: text().references(() => kaiju.name, followRenames),
  peril: text().references(() => perils.name, followRenames),
  // ISO date (YYYY-MM-DD). When the damage happened, if the customer told us.
  occurredOn: text(),
  // ISO date (YYYY-MM-DD).
  reportedOn: text().notNull(),
  stage: text({ enum: claimStages }).notNull(),
  // Whole dollars.
  estimate: integer().notNull(),
  // Unassigned until a handler picks it up.
  handler: text().references(() => handlers.name, followRenames),
  // The latest update, written for the customer to read.
  note: text(),
  ...timestamps,
})

export const payments = sqliteTable('payments', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('PY')),
  policyholderId: text()
    .notNull()
    .references(() => policyholders.id),
  // ISO date (YYYY-MM-DD).
  date: text().notNull(),
  description: text().notNull(),
  // Whole dollars. Negative for a refund.
  amount: integer().notNull(),
  status: text({ enum: paymentStatuses }).notNull(),
  ...timestamps,
})

// The municipality is the policyholder on the policy.
export const municipalAssets = sqliteTable('municipal_assets', {
  id: text().primaryKey(),
  policyId: text()
    .notNull()
    .references(() => policies.id),
  asset: text().notNull(),
  kind: text({ enum: municipalAssetKinds }).notNull(),
  district: text()
    .notNull()
    .references(() => districts.name, followRenames),
  // Whole dollars.
  insuredValue: integer().notNull(),
  ...timestamps,
})

// Quotes. `district` is free text: the public website writes it.

export const quotes = sqliteTable('quotes', {
  id: text()
    .primaryKey()
    .$defaultFn(() => newId('QT')),
  plan: text({ enum: planNames }).notNull(),
  name: text().notNull(),
  email: text().notNull(),
  property: text().notNull(),
  address: text().notNull(),
  district: text().notNull(),
  // Whole dollars, like `monthly` on a policy.
  monthly: integer().notNull(),
  // ISO date (YYYY-MM-DD).
  expiresOn: text().notNull(),
  ...timestamps,
})
