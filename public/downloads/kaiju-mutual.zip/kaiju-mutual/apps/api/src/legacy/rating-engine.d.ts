// Hand-written types for the legacy rating engine. Keep in step with rating-engine.js.

/** Monthly premium in whole dollars, or -1 if the engine can't rate it. */
export function rateQuote(plan: string, district: string, property: string, address: string): number

export function normalizeDistrict(raw: string): string

export const RATING_CONFIG: {
  version: string
  base: Record<string, number>
  minimum: Record<string, number>
  districts: Record<string, number>
  surge: number
  trendYears: [number, number]
  flags: { ENABLE_FLOOD_ZONE_V2: boolean; USE_TREND: boolean; DEBUG: boolean }
}
