// Copies kaiju watch data from Tidewatch, the kaiju monitoring feed, into the database on a timer.
// The portals read the copy, so they keep working when Tidewatch is down.
// See docs/training/api.md#kaiju-watch-feed.
import { eq, isNull } from 'drizzle-orm'
import { z } from 'zod'
import { db } from './db'
import { districts, events, type ForecastDays, forecasts, kaiju, kaijuClasses } from './db/schema'
import { eventTypes, kaijuStatuses, threatLevels } from './enums'
import { rootLogger } from './log'

// Both come from .env; see .env.example.
const baseUrl = process.env.TIDEWATCH_URL
const apiKey = process.env.TIDEWATCH_API_KEY
const syncMinutes = Number(process.env.TIDEWATCH_SYNC_MINUTES ?? 5)

const log = rootLogger.child({ job: 'tidewatch-sync' })

// Tidewatch sends `threat_level` where we have `Threat level`, `approaching` for `Approaching`.
function vendorEnum<const T extends readonly [string, ...string[]]>(values: T) {
  return z
    .string()
    .transform((value) => value.charAt(0).toUpperCase() + value.slice(1).replaceAll('_', ' '))
    .pipe(z.enum(values))
}

const feed = <T extends z.ZodType>(item: T) => z.object({ data: z.array(item) })

const kaijuFeed = feed(
  z.object({
    id: z.string(),
    name: z.string(),
    height_m: z.number().int(),
    status: vendorEnum(kaijuStatuses),
    location: z.string(),
    nearest_district: z.string(),
    heading: z.string().nullable(),
    last_seen: z.string(),
  }),
)

const forecastFeed = feed(
  z.object({
    id: z.string(),
    district: z.string(),
    starts_on: z.string(),
    levels: z
      .array(vendorEnum(threatLevels))
      .length(7)
      .transform((days) => days as ForecastDays),
    driver: z.string().nullable(),
    note: z.string(),
  }),
)

const eventFeed = feed(
  z.object({
    id: z.string(),
    at: z.string(),
    type: vendorEnum(eventTypes),
    kaiju: z.string(),
    district: z.string(),
    summary: z.string(),
    level: vendorEnum(threatLevels).nullable(),
  }),
)

// One GET against Tidewatch. Logs the trace ID Tidewatch asks for in bug reports, and returns
// nothing if the call failed or the body isn't what we expect.
async function get<T extends z.ZodType<{ data: unknown[] }>>(path: string, schema: T) {
  if (!baseUrl || !apiKey) return
  try {
    const res = await fetch(new URL(path, baseUrl), {
      headers: { 'X-Tidewatch-Key': apiKey },
      signal: AbortSignal.timeout(10_000),
    })
    const traceId = res.headers.get('X-Trace-Id')
    if (!res.ok) {
      log.error({ path, status: res.status, traceId }, 'tidewatch request failed')
      return
    }
    const parsed = schema.safeParse(await res.json().catch(() => undefined))
    if (!parsed.success) {
      const issues = parsed.error.issues.map((issue) => issue.path.map(String).join('.'))
      log.error({ path, status: res.status, traceId, issues }, 'tidewatch response not understood')
      return
    }
    log.debug(
      { path, status: res.status, traceId, count: parsed.data.data.length },
      'tidewatch read',
    )
    return parsed.data.data as z.infer<T>['data']
  } catch (err) {
    log.error({ path, err }, 'tidewatch unreachable')
  }
}

// Inserts new rows and updates changed ones. Never deletes: rows Tidewatch stops sending stay.
function save<Row extends { id: string }>(
  resource: string,
  existing: NoInfer<Row>[],
  incoming: Row[],
  write: { insert: (row: Row) => void; update: (row: Row) => void },
) {
  const before = new Map(existing.map((row) => [row.id, row]))
  let written = 0
  db.transaction(() => {
    for (const row of incoming) {
      const old = before.get(row.id)
      if (!old) {
        write.insert(row)
        log.info({ resource, id: row.id }, 'tidewatch row added')
        written++
        continue
      }
      const changed = (Object.keys(row) as (keyof Row)[]).filter(
        (key) => JSON.stringify(row[key] ?? null) !== JSON.stringify(old[key] ?? null),
      )
      if (changed.length === 0) continue
      write.update(row)
      log.info({ resource, id: row.id, changed }, 'tidewatch row updated')
      written++
    }
  })
  log.info({ resource, rows: incoming.length, written }, 'tidewatch resource synced')
}

function districtNames() {
  const rows = db
    .select({ code: districts.code, name: districts.name })
    .from(districts)
    .where(isNull(districts.deletedAt))
    .all()
  return new Map(rows.map((row) => [row.code, row.name]))
}

function kaijuNames() {
  const rows = db.select({ name: kaiju.name }).from(kaiju).where(isNull(kaiju.deletedAt)).all()
  return new Set(rows.map((row) => row.name))
}

// For a row that points at a district, kaiju or class we don't have.
function skip(resource: string, id: string, missing: Record<string, unknown>) {
  log.warn({ resource, id, ...missing }, 'tidewatch row skipped')
}

async function syncKaiju() {
  const data = await get('/v1/kaiju', kaijuFeed)
  if (!data) return
  const names = districtNames()
  const classes = db.select().from(kaijuClasses).where(isNull(kaijuClasses.deletedAt)).all()
  const rows: (typeof kaiju.$inferInsert & { id: string })[] = []
  for (const k of data) {
    const district = names.get(k.nearest_district)
    if (!district) {
      skip('kaiju', k.id, { districtCode: k.nearest_district })
      continue
    }
    // Tidewatch doesn't classify kaiju; our classes go by height.
    const kaijuClass = classes.find((c) => k.height_m >= c.minHeightM && k.height_m < c.maxHeightM)
    if (!kaijuClass) {
      skip('kaiju', k.id, { heightM: k.height_m })
      continue
    }
    rows.push({
      id: k.id,
      name: k.name,
      class: kaijuClass.name,
      heightM: k.height_m,
      status: k.status,
      location: k.location,
      nearestDistrict: district,
      heading: k.heading,
      lastSeen: k.last_seen,
    })
  }
  save('kaiju', db.select().from(kaiju).all(), rows, {
    insert: (row) => db.insert(kaiju).values(row).run(),
    update: (row) => db.update(kaiju).set(row).where(eq(kaiju.id, row.id)).run(),
  })
}

async function syncForecasts() {
  const data = await get('/v1/forecasts', forecastFeed)
  if (!data) return
  const names = districtNames()
  const kaijus = kaijuNames()
  const rows: (typeof forecasts.$inferInsert & { id: string })[] = []
  for (const f of data) {
    const district = names.get(f.district)
    if (!district) {
      skip('forecasts', f.id, { districtCode: f.district })
      continue
    }
    if (f.driver && !kaijus.has(f.driver)) {
      skip('forecasts', f.id, { kaiju: f.driver })
      continue
    }
    rows.push({
      id: f.id,
      district,
      startsOn: f.starts_on,
      days: f.levels,
      driver: f.driver,
      note: f.note,
    })
  }
  save('forecasts', db.select().from(forecasts).all(), rows, {
    insert: (row) => db.insert(forecasts).values(row).run(),
    update: (row) => db.update(forecasts).set(row).where(eq(forecasts.id, row.id)).run(),
  })
}

async function syncEvents() {
  const data = await get('/v1/events', eventFeed)
  if (!data) return
  const names = districtNames()
  const kaijus = kaijuNames()
  const rows: (typeof events.$inferInsert & { id: string })[] = []
  for (const e of data) {
    const district = names.get(e.district)
    if (!district) {
      skip('events', e.id, { districtCode: e.district })
      continue
    }
    if (!kaijus.has(e.kaiju)) {
      skip('events', e.id, { kaiju: e.kaiju })
      continue
    }
    rows.push({
      id: e.id,
      at: e.at,
      type: e.type,
      kaiju: e.kaiju,
      district,
      summary: e.summary,
      level: e.level,
    })
  }
  save('events', db.select().from(events).all(), rows, {
    insert: (row) => db.insert(events).values(row).run(),
    update: (row) => db.update(events).set(row).where(eq(events.id, row.id)).run(),
  })
}

// Each resource syncs on its own, so a failing forecast call doesn't hold up kaiju or events.
// Kaiju go first because forecasts and events point at them by name.
async function sync() {
  log.info({ baseUrl }, 'tidewatch sync started')
  await syncKaiju()
  await Promise.all([syncForecasts(), syncEvents()])
}

export function startTidewatchSync() {
  if (!baseUrl || !apiKey) {
    log.warn(
      'TIDEWATCH_URL or TIDEWATCH_API_KEY not set, so kaiju watch shows the seeded data. Copy .env.example to .env.',
    )
    return
  }
  void sync()
  setInterval(sync, syncMinutes * 60_000)
}
