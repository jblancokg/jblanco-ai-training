import { SQLiteError } from 'bun:sqlite'
import { DrizzleQueryError } from 'drizzle-orm'
import { getContext } from 'hono/context-storage'
import type { LogVariables } from './log'

type Env = { Variables: LogVariables }

// Every rejected request logs why at warn and answers with the request ID, so a bug report
// from a portal points straight at its log lines. Reads the request from `contextStorage()`.
export function reject<Status extends 400 | 401 | 404 | 409>(
  status: Status,
  error: string,
  fields: Record<string, unknown> = {},
) {
  const c = getContext<Env>()
  c.var.log.warn({ status, ...fields }, error)
  return c.json({ error, requestId: c.var.requestId }, status)
}

// The hook for zValidator: rejects with the paths of the bad fields. Never the values: they can
// hold names and emails.
export function rejectInvalid(result: {
  success: boolean
  target: string
  error?: { issues: { path: PropertyKey[] }[] }
}) {
  if (result.error) {
    const issues = result.error.issues.map((issue) => issue.path.map(String).join('.') || '(root)')
    return reject(400, `Invalid ${result.target === 'json' ? 'body' : result.target}`, { issues })
  }
}

// Turns a failed write into a 400 (points at a row that doesn't exist) or 409 (name taken).
// Anything else is a bug and goes to onError.
export function rejectConstraint(err: unknown) {
  // drizzle's own error has the bound params in its message; SQLite's doesn't.
  const cause = err instanceof DrizzleQueryError ? err.cause : err
  if (!(cause instanceof SQLiteError)) throw err
  if (cause.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
    return reject(400, 'Refers to a row that does not exist', { constraint: cause.message })
  }
  if (cause.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    // "UNIQUE constraint failed: districts.name" names the column, never the value.
    const column = cause.message.split('.').at(-1)
    return reject(409, `That ${column} is already taken`, { constraint: cause.message })
  }
  throw err
}
