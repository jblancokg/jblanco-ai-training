import { and, count, eq, isNull, ne } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { claims, policies, policyholders } from '../db/schema'
import type { LogVariables } from '../log'

export const policyholdersRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const holders = db
    .select()
    .from(policyholders)
    .where(isNull(policyholders.deletedAt))
    .orderBy(policyholders.name)
    .all()
  const policyRows = db
    .select()
    .from(policies)
    .where(isNull(policies.deletedAt))
    .orderBy(policies.id)
    .all()
  // Open means not paid yet.
  const openClaims = db
    .select({ policyholderId: policies.policyholderId, count: count() })
    .from(claims)
    .innerJoin(policies, and(eq(claims.policyId, policies.id), isNull(policies.deletedAt)))
    .where(and(isNull(claims.deletedAt), ne(claims.stage, 'Paid')))
    .groupBy(policies.policyholderId)
    .all()
  c.var.log.debug(
    { policyholders: holders.length, policies: policyRows.length },
    'policyholders read',
  )

  const policiesByHolder = Map.groupBy(policyRows, (policy) => policy.policyholderId)
  const openByHolder = new Map(openClaims.map((row) => [row.policyholderId, row.count]))
  return c.json(
    holders.map((holder) => ({
      ...holder,
      policies: policiesByHolder.get(holder.id) ?? [],
      openClaims: openByHolder.get(holder.id) ?? 0,
    })),
  )
})
