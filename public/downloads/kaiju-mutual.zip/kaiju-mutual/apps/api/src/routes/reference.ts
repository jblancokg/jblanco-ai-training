// The reference lists behind dropdowns and labels elsewhere. Each has the same four routes:
// list, add, edit and delete. Written out per list so each one's types reach the portals exactly.
import { zValidator } from '@hono/zod-validator'
import { and, eq, isNull, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import { db } from '../db'
import { districts, handlers, kaijuClasses, perils, plans, regions } from '../db/schema'
import { handlerTeams, perilCoverage, planNames, regionCoasts } from '../enums'
import { reject, rejectConstraint, rejectInvalid } from '../errors'
import type { LogVariables } from '../log'

const text = z.string().trim().min(1)
const count = z.number().int().min(0)

// A PATCH body: any of the fields, but at least one.
function changesTo<Shape extends z.ZodRawShape>(fields: z.ZodObject<Shape>) {
  return fields.partial().refine((changes) => Object.keys(changes).length > 0, 'Nothing to change')
}

const regionsFields = z.object({ name: text, coast: z.enum(regionCoasts) })

const regionsRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db
      .select()
      .from(regions)
      .where(isNull(regions.deletedAt))
      .orderBy(regions.name)
      .all()
    c.var.log.debug({ count: rows.length }, 'regions read')
    return c.json(rows)
  })
  .post('/', zValidator('json', regionsFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(regions).values(c.req.valid('json')).returning().get()
      c.var.log.info({ regionId: row.id }, 'region created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(regionsFields), rejectInvalid), (c) => {
    const regionId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(regions)
        .set(changes)
        .where(and(eq(regions.id, regionId), isNull(regions.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'Region not found', { regionId })
      c.var.log.info({ regionId, fields: Object.keys(changes) }, 'region updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const regionId = c.req.param('id')
    const row = db
      .update(regions)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(regions.id, regionId), isNull(regions.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'Region not found', { regionId })
    c.var.log.info({ regionId }, 'region deleted')
    return c.json(row)
  })

const districtsFields = z.object({
  code: text,
  name: text,
  region: text,
  shelterBeds: count,
})

const districtsRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db
      .select()
      .from(districts)
      .where(isNull(districts.deletedAt))
      .orderBy(districts.name)
      .all()
    c.var.log.debug({ count: rows.length }, 'districts read')
    return c.json(rows)
  })
  .post('/', zValidator('json', districtsFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(districts).values(c.req.valid('json')).returning().get()
      c.var.log.info({ districtId: row.id }, 'district created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(districtsFields), rejectInvalid), (c) => {
    const districtId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(districts)
        .set(changes)
        .where(and(eq(districts.id, districtId), isNull(districts.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'District not found', { districtId })
      c.var.log.info({ districtId, fields: Object.keys(changes) }, 'district updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const districtId = c.req.param('id')
    const row = db
      .update(districts)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(districts.id, districtId), isNull(districts.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'District not found', { districtId })
    c.var.log.info({ districtId }, 'district deleted')
    return c.json(row)
  })

const kaijuClassesFields = z.object({
  name: text,
  minHeightM: count,
  maxHeightM: count,
  description: text,
})

const kaijuClassesRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db
      .select()
      .from(kaijuClasses)
      .where(isNull(kaijuClasses.deletedAt))
      .orderBy(kaijuClasses.minHeightM)
      .all()
    c.var.log.debug({ count: rows.length }, 'kaijuClasses read')
    return c.json(rows)
  })
  .post('/', zValidator('json', kaijuClassesFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(kaijuClasses).values(c.req.valid('json')).returning().get()
      c.var.log.info({ kaijuClassId: row.id }, 'kaiju class created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(kaijuClassesFields), rejectInvalid), (c) => {
    const kaijuClassId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(kaijuClasses)
        .set(changes)
        .where(and(eq(kaijuClasses.id, kaijuClassId), isNull(kaijuClasses.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'Kaiju class not found', { kaijuClassId })
      c.var.log.info({ kaijuClassId, fields: Object.keys(changes) }, 'kaiju class updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const kaijuClassId = c.req.param('id')
    const row = db
      .update(kaijuClasses)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(kaijuClasses.id, kaijuClassId), isNull(kaijuClasses.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'Kaiju class not found', { kaijuClassId })
    c.var.log.info({ kaijuClassId }, 'kaiju class deleted')
    return c.json(row)
  })

const perilsFields = z.object({ name: text, covered: z.enum(perilCoverage) })

const perilsRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db.select().from(perils).where(isNull(perils.deletedAt)).orderBy(perils.name).all()
    c.var.log.debug({ count: rows.length }, 'perils read')
    return c.json(rows)
  })
  .post('/', zValidator('json', perilsFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(perils).values(c.req.valid('json')).returning().get()
      c.var.log.info({ perilId: row.id }, 'peril created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(perilsFields), rejectInvalid), (c) => {
    const perilId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(perils)
        .set(changes)
        .where(and(eq(perils.id, perilId), isNull(perils.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'Peril not found', { perilId })
      c.var.log.info({ perilId, fields: Object.keys(changes) }, 'peril updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const perilId = c.req.param('id')
    const row = db
      .update(perils)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(perils.id, perilId), isNull(perils.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'Peril not found', { perilId })
    c.var.log.info({ perilId }, 'peril deleted')
    return c.json(row)
  })

const plansFields = z.object({ name: z.enum(planNames), monthlyFrom: count, excess: count })

const plansRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db
      .select()
      .from(plans)
      .where(isNull(plans.deletedAt))
      .orderBy(plans.monthlyFrom)
      .all()
    c.var.log.debug({ count: rows.length }, 'plans read')
    return c.json(rows)
  })
  .post('/', zValidator('json', plansFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(plans).values(c.req.valid('json')).returning().get()
      c.var.log.info({ planId: row.id }, 'plan created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(plansFields), rejectInvalid), (c) => {
    const planId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(plans)
        .set(changes)
        .where(and(eq(plans.id, planId), isNull(plans.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'Plan not found', { planId })
      c.var.log.info({ planId, fields: Object.keys(changes) }, 'plan updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const planId = c.req.param('id')
    const row = db
      .update(plans)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(plans.id, planId), isNull(plans.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'Plan not found', { planId })
    c.var.log.info({ planId }, 'plan deleted')
    return c.json(row)
  })

const handlersFields = z.object({ name: text, email: text, team: z.enum(handlerTeams) })

const handlersRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = db
      .select()
      .from(handlers)
      .where(isNull(handlers.deletedAt))
      .orderBy(handlers.name)
      .all()
    c.var.log.debug({ count: rows.length }, 'handlers read')
    return c.json(rows)
  })
  .post('/', zValidator('json', handlersFields, rejectInvalid), (c) => {
    try {
      const row = db.insert(handlers).values(c.req.valid('json')).returning().get()
      c.var.log.info({ handlerId: row.id }, 'handler created')
      return c.json(row, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .patch('/:id', zValidator('json', changesTo(handlersFields), rejectInvalid), (c) => {
    const handlerId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const row = db
        .update(handlers)
        .set(changes)
        .where(and(eq(handlers.id, handlerId), isNull(handlers.deletedAt)))
        .returning()
        .get()
      if (!row) return reject(404, 'Handler not found', { handlerId })
      c.var.log.info({ handlerId, fields: Object.keys(changes) }, 'handler updated')
      return c.json(row)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .delete('/:id', (c) => {
    const handlerId = c.req.param('id')
    const row = db
      .update(handlers)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(handlers.id, handlerId), isNull(handlers.deletedAt)))
      .returning()
      .get()
    if (!row) return reject(404, 'Handler not found', { handlerId })
    c.var.log.info({ handlerId }, 'handler deleted')
    return c.json(row)
  })

export const referenceRoutes = new Hono<{ Variables: LogVariables }>()
  .route('/regions', regionsRoutes)
  .route('/districts', districtsRoutes)
  .route('/kaiju-classes', kaijuClassesRoutes)
  .route('/perils', perilsRoutes)
  .route('/plans', plansRoutes)
  .route('/handlers', handlersRoutes)
