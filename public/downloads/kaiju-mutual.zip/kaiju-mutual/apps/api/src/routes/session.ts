// Consumer sign-in. Deliberately thin: no password and an unsigned cookie holding the
// policyholder's id. It exists so the API, not the browser, decides whose rows a request sees.
import { zValidator } from '@hono/zod-validator'
import { and, eq, isNull, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { deleteCookie, setCookie } from 'hono/cookie'
import { z } from 'zod'
import { db } from '../db'
import { policyholders } from '../db/schema'
import { reject, rejectInvalid } from '../errors'
import type { LogVariables } from '../log'
import { profile, sessionCookie } from './me'

const signIn = z.object({ email: z.string().trim().min(1) })

// Sent with every API request. Only /api/me reads it.
const cookiePath = '/api'

export const sessionRoutes = new Hono<{ Variables: LogVariables }>()
  .post('/', zValidator('json', signIn, rejectInvalid), (c) => {
    const { email } = c.req.valid('json')
    const holder = db
      .select()
      .from(policyholders)
      .where(
        and(
          eq(sql`lower(${policyholders.email})`, email.toLowerCase()),
          isNull(policyholders.deletedAt),
        ),
      )
      .get()
    if (!holder) return reject(401, 'No policy uses that email')
    setCookie(c, sessionCookie, holder.id, { httpOnly: true, sameSite: 'Lax', path: cookiePath })
    c.var.log.info({ policyholderId: holder.id }, 'signed in')
    return c.json(profile(holder))
  })
  .delete('/', (c) => {
    const policyholderId = deleteCookie(c, sessionCookie, { path: cookiePath })
    c.var.log.info({ policyholderId }, 'signed out')
    return c.body(null, 204)
  })
