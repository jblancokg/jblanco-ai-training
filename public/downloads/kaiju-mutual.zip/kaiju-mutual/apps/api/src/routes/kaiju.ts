import { isNull } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { kaiju } from '../db/schema'
import type { LogVariables } from '../log'

export const kaijuRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const rows = db.select().from(kaiju).where(isNull(kaiju.deletedAt)).orderBy(kaiju.name).all()
  c.var.log.debug({ count: rows.length }, 'kaiju read')
  return c.json(rows)
})
