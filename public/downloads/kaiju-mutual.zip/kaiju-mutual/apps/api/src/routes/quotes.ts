import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, isNull, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import { db } from '../db'
import { quotes } from '../db/schema'
import { planNames } from '../enums'
import { reject, rejectInvalid } from '../errors'
import { rateQuote } from '../legacy/rating-engine.js'
import type { LogVariables } from '../log'

// What a customer tells us. The server owns the id, price, expiry and timestamps.
const quoteRequest = z.object({
  plan: z.enum(planNames),
  name: z.string().trim().min(1),
  email: z.string().trim().min(1),
  property: z.string().trim().min(1),
  address: z.string().trim().min(1),
  district: z.string().trim().min(1),
})

// Withdrawn quotes are left out unless asked for.
const listQuery = z.object({ withdrawn: z.enum(['true', 'false']).optional() })

const validDays = 30

// ISO date (YYYY-MM-DD) `days` from today.
function daysFromNow(days: number) {
  const date = new Date()
  date.setUTCDate(date.getUTCDate() + days)
  return date.toISOString().slice(0, 10)
}

export const quotesRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', zValidator('query', listQuery, rejectInvalid), (c) => {
    const withdrawn = c.req.valid('query').withdrawn === 'true'
    const rows = db
      .select()
      .from(quotes)
      .where(withdrawn ? undefined : isNull(quotes.deletedAt))
      .orderBy(desc(quotes.createdAt))
      .all()
    c.var.log.debug({ count: rows.length, withdrawn }, 'quotes read')
    return c.json(rows)
  })
  .post('/', zValidator('json', quoteRequest, rejectInvalid), (c) => {
    const request = c.req.valid('json')
    // The schema fills in the id.
    const quote = db
      .insert(quotes)
      .values({
        ...request,
        monthly: rateQuote(request.plan, request.district, request.property, request.address),
        expiresOn: daysFromNow(validDays),
      })
      .returning()
      .get()
    c.var.log.info({ quoteId: quote.id, plan: quote.plan }, 'quote created')
    return c.json(quote, 201)
  })
  // Withdrawing keeps the quote, so staff can still see what the customer was offered.
  .delete('/:id', (c) => {
    const quoteId = c.req.param('id')
    const quote = db
      .update(quotes)
      .set({ deletedAt: sql`(current_timestamp)` })
      .where(and(eq(quotes.id, quoteId), isNull(quotes.deletedAt)))
      .returning()
      .get()
    if (!quote) return reject(404, 'Quote not found', { quoteId })
    c.var.log.info({ quoteId }, 'quote withdrawn')
    return c.json(quote)
  })
