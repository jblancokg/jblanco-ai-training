// The signed-in policyholder's own rows. Every query is scoped to the policyholder from the
// session cookie, so someone else's policy or claim is a 404, the same as one that doesn't exist.
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, inArray, isNull, ne, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { getCookie } from 'hono/cookie'
import { createMiddleware } from 'hono/factory'
import { z } from 'zod'
import { db } from '../db'
import {
  claims,
  forecasts,
  kaiju,
  payments,
  perils,
  planCover,
  policies,
  policyholders,
} from '../db/schema'
import { plansCovered, type ThreatLevel } from '../enums'
import { reject, rejectConstraint, rejectInvalid } from '../errors'
import type { LogVariables } from '../log'

// Holds the policyholder's id, unsigned. Set by routes/session.ts.
export const sessionCookie = 'kaiju_policyholder'

type Policyholder = typeof policyholders.$inferSelect
type MeVariables = LogVariables & { policyholder: Policyholder }

// What the portal shows about the policyholder. The card is only ever brand, last four and expiry.
export function profile(holder: Policyholder) {
  const { cardBrand, cardLast4, cardExpires } = holder
  return {
    id: holder.id,
    name: holder.name,
    email: holder.email,
    phone: holder.phone,
    address: holder.address,
    district: holder.district,
    customerSince: holder.customerSince,
    notifyThreat: holder.notifyThreat,
    notifyClaims: holder.notifyClaims,
    notifyBilling: holder.notifyBilling,
    notifyNews: holder.notifyNews,
    card:
      cardBrand && cardLast4 && cardExpires
        ? { brand: cardBrand, last4: cardLast4, expires: cardExpires }
        : null,
  }
}

const text = z.string().trim().min(1)

// Contact details and notification choices. A null phone or address clears it.
const profileChanges = z
  .object({
    name: text,
    email: text,
    phone: text.nullable(),
    address: text.nullable(),
    notifyThreat: z.boolean(),
    notifyClaims: z.boolean(),
    notifyBilling: z.boolean(),
    notifyNews: z.boolean(),
  })
  .partial()
  .refine((changes) => Object.keys(changes).length > 0, 'Nothing to change')

// What the claim form sends. The server sets the id, stage, reported date and estimate.
const claimRequest = z.object({
  policyId: text,
  title: text,
  description: text.nullish(),
  peril: text,
  // Not knowing is fine: staff match it later.
  kaiju: text.nullish(),
  occurredOn: z.iso.date().nullish(),
})

// Loads the policyholder from the session cookie, so handlers use `c.var.policyholder`.
const signedIn = createMiddleware<{ Variables: MeVariables }>(async (c, next) => {
  const policyholderId = getCookie(c, sessionCookie)
  const holder =
    policyholderId &&
    db
      .select()
      .from(policyholders)
      .where(and(eq(policyholders.id, policyholderId), isNull(policyholders.deletedAt)))
      .get()
  if (!holder) return reject(401, 'Not signed in')
  c.set('policyholder', holder)
  await next()
})

// The policyholder's live claims, with the property from the policy. Pass `claimId` for one.
function selectClaims(policyholderId: string, claimId?: string) {
  return db
    .select({
      id: claims.id,
      policyId: claims.policyId,
      policyProperty: policies.property,
      title: claims.title,
      description: claims.description,
      kaiju: claims.kaiju,
      peril: claims.peril,
      occurredOn: claims.occurredOn,
      reportedOn: claims.reportedOn,
      stage: claims.stage,
      // Whole dollars. What was paid, once the claim is Paid.
      estimate: claims.estimate,
      note: claims.note,
    })
    .from(claims)
    .innerJoin(policies, and(eq(claims.policyId, policies.id), isNull(policies.deletedAt)))
    .where(
      and(
        eq(policies.policyholderId, policyholderId),
        isNull(claims.deletedAt),
        claimId === undefined ? undefined : eq(claims.id, claimId),
      ),
    )
}

// ISO date (YYYY-MM-DD), UTC.
function today() {
  return new Date().toISOString().slice(0, 10)
}

export const meRoutes = new Hono<{ Variables: MeVariables }>()
  .use(signedIn)
  .get('/', (c) => c.json(profile(c.var.policyholder)))
  .patch('/', zValidator('json', profileChanges, rejectInvalid), (c) => {
    const policyholderId = c.var.policyholder.id
    const changes = c.req.valid('json')
    // Sign-in looks people up by email, so two policyholders can't share one.
    if (changes.email) {
      const taken = db
        .select({ id: policyholders.id })
        .from(policyholders)
        .where(
          and(
            eq(sql`lower(${policyholders.email})`, changes.email.toLowerCase()),
            ne(policyholders.id, policyholderId),
            isNull(policyholders.deletedAt),
          ),
        )
        .get()
      if (taken) return reject(409, 'That email is already taken', { policyholderId })
    }
    const holder = db
      .update(policyholders)
      .set(changes)
      .where(eq(policyholders.id, policyholderId))
      .returning()
      .get()
    if (!holder) throw new Error('signed-in policyholder not found')
    // Keys only: the values are contact details.
    c.var.log.info({ policyholderId, fields: Object.keys(changes) }, 'profile updated')
    return c.json(profile(holder))
  })
  .get('/policies', (c) => {
    const policyholderId = c.var.policyholder.id
    const rows = db
      .select()
      .from(policies)
      .where(and(eq(policies.policyholderId, policyholderId), isNull(policies.deletedAt)))
      .orderBy(policies.id)
      .all()
    const cover = db
      .select({ plan: planCover.plan, item: planCover.item, limit: planCover.limit })
      .from(planCover)
      .where(
        and(
          inArray(
            planCover.plan,
            rows.map((policy) => policy.plan),
          ),
          isNull(planCover.deletedAt),
        ),
      )
      .orderBy(planCover.createdAt, planCover.id)
      .all()
    c.var.log.debug({ policyholderId, count: rows.length }, 'my policies read')

    const coverByPlan = Map.groupBy(cover, (row) => row.plan)
    return c.json(
      rows.map((policy) => ({
        ...policy,
        cover: (coverByPlan.get(policy.plan) ?? []).map(({ item, limit }) => ({ item, limit })),
      })),
    )
  })
  .get('/claims', (c) => {
    const policyholderId = c.var.policyholder.id
    const rows = selectClaims(policyholderId)
      .orderBy(desc(claims.reportedOn), desc(claims.id))
      .all()
    c.var.log.debug({ policyholderId, count: rows.length }, 'my claims read')
    return c.json(rows)
  })
  .post('/claims', zValidator('json', claimRequest, rejectInvalid), (c) => {
    const policyholderId = c.var.policyholder.id
    const request = c.req.valid('json')
    const policy = db
      .select({ plan: policies.plan })
      .from(policies)
      .where(
        and(
          eq(policies.id, request.policyId),
          eq(policies.policyholderId, policyholderId),
          isNull(policies.deletedAt),
        ),
      )
      .get()
    if (!policy) return reject(404, 'Policy not found', { policyId: request.policyId })
    const peril = db
      .select({ covered: perils.covered })
      .from(perils)
      .where(and(eq(perils.name, request.peril), isNull(perils.deletedAt)))
      .get()
    if (!peril || !plansCovered[peril.covered].includes(policy.plan)) {
      return reject(400, 'That policy does not cover that peril', {
        policyId: request.policyId,
        peril: request.peril,
      })
    }
    try {
      // The schema fills in the id.
      const { id: claimId } = db
        .insert(claims)
        .values({ ...request, stage: 'Reported', reportedOn: today(), estimate: 0 })
        .returning({ id: claims.id })
        .get()
      c.var.log.info({ claimId, policyId: request.policyId }, 'claim started')
      const claim = selectClaims(policyholderId, claimId).get()
      if (!claim) throw new Error('new claim not found')
      return c.json(claim, 201)
    } catch (err) {
      return rejectConstraint(err)
    }
  })
  .get('/payments', (c) => {
    const policyholderId = c.var.policyholder.id
    const rows = db
      .select()
      .from(payments)
      .where(and(eq(payments.policyholderId, policyholderId), isNull(payments.deletedAt)))
      .orderBy(desc(payments.date), desc(payments.id))
      .all()
    c.var.log.debug({ policyholderId, count: rows.length }, 'my payments read')
    return c.json(rows)
  })
  .get('/district', (c) => {
    const { district } = c.var.policyholder
    const row = db
      .select({
        startsOn: forecasts.startsOn,
        days: forecasts.days,
        note: forecasts.note,
        updatedAt: forecasts.updatedAt,
        driver: {
          name: kaiju.name,
          status: kaiju.status,
          class: kaiju.class,
          heightM: kaiju.heightM,
          location: kaiju.location,
        },
      })
      .from(forecasts)
      .leftJoin(kaiju, and(eq(forecasts.driver, kaiju.name), isNull(kaiju.deletedAt)))
      .where(and(eq(forecasts.district, district), isNull(forecasts.deletedAt)))
      .get()
    c.var.log.debug({ district, found: Boolean(row) }, 'my district read')
    // No forecast means nothing to worry about. Before the forecast starts, use its first day;
    // after it ends, its last.
    let level: ThreatLevel = 'Clear'
    if (row) {
      const daysIn = Math.round((Date.parse(today()) - Date.parse(row.startsOn)) / 86_400_000)
      level = row.days[Math.min(Math.max(daysIn, 0), row.days.length - 1)] ?? level
    }
    return c.json({
      district,
      level,
      updatedAt: row?.updatedAt ?? null,
      note: row?.note ?? null,
      driver: row?.driver ?? null,
    })
  })
