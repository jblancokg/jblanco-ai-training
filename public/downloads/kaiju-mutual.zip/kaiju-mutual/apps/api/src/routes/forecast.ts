import { isNull } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { forecasts } from '../db/schema'
import type { LogVariables } from '../log'

export const forecastRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const rows = db
    .select()
    .from(forecasts)
    .where(isNull(forecasts.deletedAt))
    .orderBy(forecasts.district)
    .all()
  c.var.log.debug({ count: rows.length }, 'forecast read')
  return c.json(rows)
})
