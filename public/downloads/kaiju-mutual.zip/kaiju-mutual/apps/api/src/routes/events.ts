import { and, count, desc, eq, getTableColumns, isNull, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { claims, events } from '../db/schema'
import type { LogVariables } from '../log'

// Each event with the claims linked to it and what was paid on them, so the totals always
// match the claims.
export const eventsRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const rows = db
    .select({
      ...getTableColumns(events),
      claims: count(claims.id),
      paidOut:
        sql`coalesce(sum(${claims.estimate}) filter (where ${eq(claims.stage, 'Paid')}), 0)`.mapWith(
          Number,
        ),
    })
    .from(events)
    .leftJoin(claims, and(eq(claims.eventId, events.id), isNull(claims.deletedAt)))
    .where(isNull(events.deletedAt))
    .groupBy(events.id)
    .orderBy(desc(events.at))
    .all()
  c.var.log.debug({ count: rows.length }, 'events read')
  return c.json(rows)
})
