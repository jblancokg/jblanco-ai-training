import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, getTableColumns, isNull } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import { db } from '../db'
import { claims, policies, policyholders } from '../db/schema'
import { claimStages } from '../enums'
import { reject, rejectConstraint, rejectInvalid } from '../errors'
import type { LogVariables } from '../log'

// What staff can change on a claim. A null handler unassigns it; a null note clears it.
const claimChanges = z
  .object({
    stage: z.enum(claimStages),
    handler: z.string().trim().min(1).nullable(),
    estimate: z.number().int().min(0),
    note: z.string().trim().min(1).nullable(),
  })
  .partial()
  .refine((changes) => Object.keys(changes).length > 0, 'Nothing to change')

// A claim with its policyholder, who comes from the policy.
function selectClaims() {
  return db
    .select({
      ...getTableColumns(claims),
      policyholderId: policyholders.id,
      policyholderName: policyholders.name,
    })
    .from(claims)
    .innerJoin(policies, and(eq(claims.policyId, policies.id), isNull(policies.deletedAt)))
    .innerJoin(
      policyholders,
      and(eq(policies.policyholderId, policyholders.id), isNull(policyholders.deletedAt)),
    )
}

export const claimsRoutes = new Hono<{ Variables: LogVariables }>()
  .get('/', (c) => {
    const rows = selectClaims()
      .where(isNull(claims.deletedAt))
      .orderBy(desc(claims.reportedOn), desc(claims.id))
      .all()
    c.var.log.debug({ count: rows.length }, 'claims read')
    return c.json(rows)
  })
  .patch('/:id', zValidator('json', claimChanges, rejectInvalid), (c) => {
    const claimId = c.req.param('id')
    const changes = c.req.valid('json')
    try {
      const updated = db
        .update(claims)
        .set(changes)
        .where(and(eq(claims.id, claimId), isNull(claims.deletedAt)))
        .returning({ id: claims.id })
        .get()
      if (!updated) return reject(404, 'Claim not found', { claimId })
    } catch (err) {
      return rejectConstraint(err)
    }
    // Stage, handler and estimate hold nothing personal, so their values are logged too. The
    // note is free text the customer reads, so only that it changed.
    const { note, ...logged } = changes
    c.var.log.info({ claimId, changes: logged, noteChanged: note !== undefined }, 'claim updated')
    const claim = selectClaims().where(eq(claims.id, claimId)).get()
    if (!claim) throw new Error('updated claim not found')
    return c.json(claim)
  })
