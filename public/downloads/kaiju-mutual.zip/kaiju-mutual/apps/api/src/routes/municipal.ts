import { and, eq, getTableColumns, isNull } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { forecasts, municipalAssets, policies, policyholders } from '../db/schema'
import { type ThreatLevel, threatLevels } from '../enums'
import type { LogVariables } from '../log'

// Share of an asset's insured value we expect to pay out at each threat level.
// The actuaries' rough numbers; estimates on /municipal are built from these.
const damageRatio: Record<ThreatLevel, number> = {
  Clear: 0,
  Watch: 0.005,
  Advisory: 0.03,
  Warning: 0.12,
  Evacuate: 0.35,
}

// Each insured asset's expected loss, from the worst day in its district's forecast.
export const municipalRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const assets = db
    .select({ ...getTableColumns(municipalAssets), municipality: policyholders.name })
    .from(municipalAssets)
    .innerJoin(policies, and(eq(municipalAssets.policyId, policies.id), isNull(policies.deletedAt)))
    .innerJoin(
      policyholders,
      and(eq(policies.policyholderId, policyholders.id), isNull(policyholders.deletedAt)),
    )
    .where(isNull(municipalAssets.deletedAt))
    .orderBy(municipalAssets.id)
    .all()
  const forecastRows = db
    .select({ district: forecasts.district, days: forecasts.days })
    .from(forecasts)
    .where(isNull(forecasts.deletedAt))
    .all()
  c.var.log.debug({ assets: assets.length, forecasts: forecastRows.length }, 'municipal read')

  const peaks = new Map(
    forecastRows.map(({ district, days }) => [
      district,
      threatLevels[Math.max(...days.map((day) => threatLevels.indexOf(day)))] ?? 'Clear',
    ]),
  )
  return c.json(
    assets.map((asset) => {
      const peak = peaks.get(asset.district) ?? 'Clear'
      return {
        ...asset,
        peak,
        damageRatio: damageRatio[peak],
        loss: Math.round(asset.insuredValue * damageRatio[peak]),
      }
    }),
  )
})
