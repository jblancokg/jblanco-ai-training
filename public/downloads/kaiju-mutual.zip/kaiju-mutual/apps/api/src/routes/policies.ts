import { and, eq, getTableColumns, isNull } from 'drizzle-orm'
import { Hono } from 'hono'
import { db } from '../db'
import { policies, policyholders } from '../db/schema'
import type { LogVariables } from '../log'

export const policiesRoutes = new Hono<{ Variables: LogVariables }>().get('/', (c) => {
  const rows = db
    .select({ ...getTableColumns(policies), policyholderName: policyholders.name })
    .from(policies)
    .innerJoin(
      policyholders,
      and(eq(policies.policyholderId, policyholders.id), isNull(policyholders.deletedAt)),
    )
    .where(isNull(policies.deletedAt))
    .orderBy(policies.id)
    .all()
  c.var.log.debug({ count: rows.length }, 'policies read')
  return c.json(rows)
})
