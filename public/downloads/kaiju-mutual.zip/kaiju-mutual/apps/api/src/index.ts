import app from './app'
import { dbFile } from './db'
import { rootLogger } from './log'
import { startTidewatchSync } from './tidewatch'

const port = Number(process.env.PORT ?? 3000)
rootLogger.info({ port, logLevel: rootLogger.level, dbFile }, 'api started')
startTidewatchSync()

export default { port, fetch: app.fetch }
