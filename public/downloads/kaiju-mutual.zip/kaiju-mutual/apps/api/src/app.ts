import { DrizzleQueryError, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { contextStorage } from 'hono/context-storage'
import { HTTPException } from 'hono/http-exception'
import { requestId } from 'hono/request-id'
import { db } from './db'
import { type LogVariables, requestLogger } from './log'
import { claimsRoutes } from './routes/claims'
import { eventsRoutes } from './routes/events'
import { forecastRoutes } from './routes/forecast'
import { kaijuRoutes } from './routes/kaiju'
import { meRoutes } from './routes/me'
import { municipalRoutes } from './routes/municipal'
import { policiesRoutes } from './routes/policies'
import { policyholdersRoutes } from './routes/policyholders'
import { quotesRoutes } from './routes/quotes'
import { referenceRoutes } from './routes/reference'
import { sessionRoutes } from './routes/session'

const app = new Hono<{ Variables: LogVariables }>()
  .basePath('/api')
  // Lets code outside a handler, such as the SQL logger, find the current request.
  .use(contextStorage())
  .use(requestId())
  .use(requestLogger)
  .onError((err, c) => {
    // The request ID lets whoever sees this error find its log lines.
    if (err instanceof HTTPException) {
      c.var.log.warn({ status: err.status }, err.message)
      return c.json({ error: err.message, requestId: c.var.requestId }, err.status)
    }
    // drizzle's own error has the bound params in its message, so log the database's error
    // and the SQL instead.
    if (err instanceof DrizzleQueryError) {
      c.var.log.error({ err: err.cause, sql: err.query }, 'unhandled error')
    } else {
      c.var.log.error({ err }, 'unhandled error')
    }
    return c.json({ error: 'Internal Server Error', requestId: c.var.requestId }, 500)
  })
  .get('/health', (c) => {
    // bun-sqlite's get() returns the row as a tuple of values
    const [sqlite] = db.get<[string]>(sql`select sqlite_version()`)
    return c.json({ status: 'ok', sqlite })
  })
  .route('/reference', referenceRoutes)
  .route('/claims', claimsRoutes)
  .route('/policies', policiesRoutes)
  .route('/policyholders', policyholdersRoutes)
  .route('/kaiju', kaijuRoutes)
  .route('/forecast', forecastRoutes)
  .route('/events', eventsRoutes)
  .route('/municipal', municipalRoutes)
  .route('/quotes', quotesRoutes)
  .route('/session', sessionRoutes)
  .route('/me', meRoutes)

export type AppType = typeof app
export default app
