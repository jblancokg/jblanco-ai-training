// Lists the code checks against. No imports, so the portals can use them without pulling in
// the database: `import { claimStages } from '@kaiju/api/enums'`.

export const planNames = ['Household', 'Business', 'Municipal'] as const
export type PlanName = (typeof planNames)[number]

export const regionCoasts = ['Open sea', 'Bay', 'Inland'] as const
export type RegionCoast = (typeof regionCoasts)[number]

// Which plans cover a peril.
export const perilCoverage = ['All plans', 'Business and up', 'Municipal only'] as const
export type PerilCoverage = (typeof perilCoverage)[number]

export const plansCovered: Record<PerilCoverage, readonly PlanName[]> = {
  'All plans': planNames,
  'Business and up': ['Business', 'Municipal'],
  'Municipal only': ['Municipal'],
}

export const handlerTeams = ['Household', 'Commercial', 'Major loss'] as const
export type HandlerTeam = (typeof handlerTeams)[number]

export const policyStatuses = ['Active', 'Renewal due', 'Lapsed'] as const
export type PolicyStatus = (typeof policyStatuses)[number]

// The stages every claim moves through, in order. Same as the consumer portal.
export const claimStages = ['Reported', 'Assessor visit', 'Decision', 'Paid'] as const
export type ClaimStage = (typeof claimStages)[number]

export const paymentStatuses = ['Scheduled', 'Paid', 'Refunded'] as const
export type PaymentStatus = (typeof paymentStatuses)[number]

// Civil-defence threat levels, from least to most worrying.
export const threatLevels = ['Clear', 'Watch', 'Advisory', 'Warning', 'Evacuate'] as const
export type ThreatLevel = (typeof threatLevels)[number]

// From least to most worrying.
export const kaijuStatuses = ['Dormant', 'Contained', 'Tracked', 'Approaching', 'Landfall'] as const
export type KaijuStatus = (typeof kaijuStatuses)[number]

export const eventTypes = [
  'Sighting',
  'Landfall',
  'Containment',
  'Retreat',
  'Threat level',
] as const
export type EventType = (typeof eventTypes)[number]

export const municipalAssetKinds = [
  'Seawall',
  'Transit',
  'Utilities',
  'Civic building',
  'Port',
] as const
export type MunicipalAssetKind = (typeof municipalAssetKinds)[number]
