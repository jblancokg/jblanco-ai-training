import type { Logger as DrizzleLogger } from 'drizzle-orm'
import { tryGetContext } from 'hono/context-storage'
import { createMiddleware } from 'hono/factory'
import type { RequestIdVariables } from 'hono/request-id'
import pino, { type Logger } from 'pino'

export type LogVariables = RequestIdVariables & { log: Logger }

const streams: pino.StreamEntry[] = [{ level: 'trace', stream: pino.destination(1) }]
// Optional: also append every line to this file, relative to apps/api.
if (process.env.LOG_FILE) {
  streams.push({ level: 'trace', stream: pino.destination({ dest: process.env.LOG_FILE }) })
}

const pii = ['name', 'email', 'address']

// One JSON object per line, so logs can be grepped or parsed. The logger's level does the
// filtering; the streams take everything it lets through.
export const rootLogger = pino(
  {
    level: process.env.LOG_LEVEL ?? 'debug',
    base: null,
    timestamp: pino.stdTimeFunctions.isoTime,
    formatters: { level: (label) => ({ level: label }) },
    // A safety net: log ids, not people. Catches these fields at the top level and one level down.
    redact: pii.flatMap((field) => [field, `*.${field}`]),
  },
  pino.multistream(streams),
)

// Gives each handler `c.var.log`, bound to the request ID, and logs the start and end of every
// request. Must run after `requestId()`.
export const requestLogger = createMiddleware<{ Variables: LogVariables }>(async (c, next) => {
  const log = rootLogger.child({ requestId: c.var.requestId })
  c.set('log', log)
  const request = { method: c.req.method, path: c.req.path }
  log.debug(request, 'request started')
  const start = performance.now()
  await next()
  const { status } = c.res
  const level = status >= 500 ? 'error' : status >= 400 ? 'warn' : 'info'
  log[level]({ ...request, status, durationMs: Math.round(performance.now() - start) }, 'request')
})

// Logs every SQL statement at debug, through the current request's logger when there is one
// (needs `contextStorage()`), so the line carries the request ID. Never the params: they hold
// names and emails.
export const sqlLogger: DrizzleLogger = {
  logQuery(query) {
    const log = tryGetContext<{ Variables: LogVariables }>()?.var.log ?? rootLogger
    log.debug({ sql: query }, 'sql')
  },
}
