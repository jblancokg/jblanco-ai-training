CREATE TABLE `claims` (
	`id` text PRIMARY KEY NOT NULL,
	`policyId` text NOT NULL,
	`eventId` text,
	`title` text NOT NULL,
	`kaiju` text NOT NULL,
	`reportedOn` text NOT NULL,
	`stage` text NOT NULL,
	`estimate` integer NOT NULL,
	`handler` text,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`policyId`) REFERENCES `policies`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`eventId`) REFERENCES `events`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`kaiju`) REFERENCES `kaiju`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`handler`) REFERENCES `handlers`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `districts` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`region` text NOT NULL,
	`shelterBeds` integer NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`region`) REFERENCES `regions`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `districts_code_unique` ON `districts` (`code`);--> statement-breakpoint
CREATE UNIQUE INDEX `districts_name_unique` ON `districts` (`name`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`at` text NOT NULL,
	`type` text NOT NULL,
	`kaiju` text NOT NULL,
	`district` text NOT NULL,
	`summary` text NOT NULL,
	`level` text,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`kaiju`) REFERENCES `kaiju`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`district`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `forecasts` (
	`id` text PRIMARY KEY NOT NULL,
	`district` text NOT NULL,
	`startsOn` text NOT NULL,
	`days` text NOT NULL,
	`driver` text,
	`note` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`district`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`driver`) REFERENCES `kaiju`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `forecasts_district_unique` ON `forecasts` (`district`);--> statement-breakpoint
CREATE TABLE `handlers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`team` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `handlers_name_unique` ON `handlers` (`name`);--> statement-breakpoint
CREATE TABLE `kaiju` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`class` text NOT NULL,
	`heightM` integer NOT NULL,
	`status` text NOT NULL,
	`location` text NOT NULL,
	`nearestDistrict` text NOT NULL,
	`heading` text,
	`lastSeen` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`class`) REFERENCES `kaiju_classes`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`nearestDistrict`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `kaiju_name_unique` ON `kaiju` (`name`);--> statement-breakpoint
CREATE TABLE `kaiju_classes` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`minHeightM` integer NOT NULL,
	`maxHeightM` integer NOT NULL,
	`description` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `kaiju_classes_name_unique` ON `kaiju_classes` (`name`);--> statement-breakpoint
CREATE TABLE `municipal_assets` (
	`id` text PRIMARY KEY NOT NULL,
	`policyId` text NOT NULL,
	`asset` text NOT NULL,
	`kind` text NOT NULL,
	`district` text NOT NULL,
	`insuredValue` integer NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`policyId`) REFERENCES `policies`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`district`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `perils` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`covered` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `perils_name_unique` ON `perils` (`name`);--> statement-breakpoint
CREATE TABLE `plans` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`monthlyFrom` integer NOT NULL,
	`excess` integer NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `plans_name_unique` ON `plans` (`name`);--> statement-breakpoint
CREATE TABLE `policies` (
	`id` text PRIMARY KEY NOT NULL,
	`policyholderId` text NOT NULL,
	`plan` text NOT NULL,
	`property` text NOT NULL,
	`district` text NOT NULL,
	`monthly` integer NOT NULL,
	`renewsOn` text NOT NULL,
	`status` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`policyholderId`) REFERENCES `policyholders`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`plan`) REFERENCES `plans`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`district`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `policyholders` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`district` text NOT NULL,
	`customerSince` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`district`) REFERENCES `districts`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `regions` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`coast` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `regions_name_unique` ON `regions` (`name`);