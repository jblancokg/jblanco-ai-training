CREATE TABLE `payments` (
	`id` text PRIMARY KEY NOT NULL,
	`policyholderId` text NOT NULL,
	`date` text NOT NULL,
	`description` text NOT NULL,
	`amount` integer NOT NULL,
	`status` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`policyholderId`) REFERENCES `policyholders`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `plan_cover` (
	`id` text PRIMARY KEY NOT NULL,
	`plan` text NOT NULL,
	`item` text NOT NULL,
	`limit` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`plan`) REFERENCES `plans`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_claims` (
	`id` text PRIMARY KEY NOT NULL,
	`policyId` text NOT NULL,
	`eventId` text,
	`title` text NOT NULL,
	`description` text,
	`kaiju` text,
	`peril` text,
	`occurredOn` text,
	`reportedOn` text NOT NULL,
	`stage` text NOT NULL,
	`estimate` integer NOT NULL,
	`handler` text,
	`note` text,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text,
	FOREIGN KEY (`policyId`) REFERENCES `policies`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`eventId`) REFERENCES `events`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`kaiju`) REFERENCES `kaiju`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`peril`) REFERENCES `perils`(`name`) ON UPDATE cascade ON DELETE no action,
	FOREIGN KEY (`handler`) REFERENCES `handlers`(`name`) ON UPDATE cascade ON DELETE no action
);
--> statement-breakpoint
-- Edited by hand: drizzle-kit copied the new columns too, which the old table doesn't have.
INSERT INTO `__new_claims`("id", "policyId", "eventId", "title", "kaiju", "reportedOn", "stage", "estimate", "handler", "createdAt", "updatedAt", "deletedAt") SELECT "id", "policyId", "eventId", "title", "kaiju", "reportedOn", "stage", "estimate", "handler", "createdAt", "updatedAt", "deletedAt" FROM `claims`;--> statement-breakpoint
DROP TABLE `claims`;--> statement-breakpoint
ALTER TABLE `__new_claims` RENAME TO `claims`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
-- Edited by hand: SQLite can't add a NOT NULL column without a default. The seed fills it.
ALTER TABLE `policies` ADD `address` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `phone` text;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `address` text;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `notifyThreat` integer DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `notifyClaims` integer DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `notifyBilling` integer DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `notifyNews` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `cardBrand` text;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `cardLast4` text;--> statement-breakpoint
ALTER TABLE `policyholders` ADD `cardExpires` text;