CREATE TABLE `quotes` (
	`id` text PRIMARY KEY NOT NULL,
	`plan` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`property` text NOT NULL,
	`address` text NOT NULL,
	`district` text NOT NULL,
	`monthly` integer NOT NULL,
	`expiresOn` text NOT NULL,
	`createdAt` text DEFAULT (current_timestamp) NOT NULL,
	`updatedAt` text DEFAULT (current_timestamp) NOT NULL,
	`deletedAt` text
);
