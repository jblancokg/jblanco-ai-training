import type { AppType } from '@kaiju/api'
import { useRouter } from '@tanstack/react-router'
import { type ClientResponse, DetailedError, hc, parseResponse } from 'hono/client'
import { toast } from 'sonner'

export const api = hc<AppType>('/').api

// A failed API call. Every API error carries a request ID, which points at its log lines.
export class ApiError extends Error {
  readonly requestId: string | undefined

  constructor(status: number, body: unknown) {
    const fields = typeof body === 'object' && body !== null ? body : {}
    super('error' in fields && typeof fields.error === 'string' ? fields.error : `HTTP ${status}`)
    this.name = 'ApiError'
    this.requestId =
      'requestId' in fields && typeof fields.requestId === 'string' ? fields.requestId : undefined
  }
}

// The body of a successful response, typed from the route. Anything else throws an ApiError.
export async function unwrap<T extends ClientResponse<unknown>>(request: Promise<T>) {
  try {
    return await parseResponse(request)
  } catch (err) {
    if (err instanceof DetailedError) throw new ApiError(err.statusCode, err.detail?.data)
    throw err
  }
}

// Sends a change, toasts how it went and reloads every loader on the page.
// Resolves to whether it saved, so a dialog knows to close.
export function useSave() {
  const router = useRouter()
  return async (request: Promise<ClientResponse<unknown>>, success: string) => {
    try {
      await unwrap(request)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : String(err), {
        description:
          err instanceof ApiError && err.requestId ? `Request ${err.requestId}` : undefined,
      })
      return false
    }
    toast.success(success)
    await router.invalidate()
    return true
  }
}
