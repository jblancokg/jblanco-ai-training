import { type ClaimStage, claimStages } from '@kaiju/api/enums'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { type FormEvent, useState } from 'react'
import { api, useSave } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { StageBadge } from '@/components/stage-badge'
import { Button } from '@/components/ui/button'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { day, money } from '@/lib/format'

export type Claim = InferResponseType<typeof api.claims.$get, 200>[number]
export type Handler = InferResponseType<typeof api.reference.handlers.$get, 200>[number]

type Props = { claims: Claim[]; handlers: Handler[]; empty: string }

const col = createColumnHelper<Features, Claim>()
const columns = col.columns([
  col.accessor('id', {
    header: 'Claim',
    meta: { className: 'min-w-48 whitespace-normal' },
    cell: ({ row }) => (
      <>
        <span className="block font-medium">{row.original.title}</span>
        <span className="block font-mono text-xs text-muted-foreground">
          {row.original.id} · {row.original.policyId}
        </span>
      </>
    ),
  }),
  col.accessor('policyholderName', { header: 'Policyholder' }),
  col.accessor((claim) => claim.kaiju ?? 'Unknown', { id: 'kaiju', header: 'Kaiju' }),
  col.accessor('reportedOn', {
    header: 'Reported',
    cell: ({ getValue }) => day.format(new Date(getValue())),
  }),
  // Sorts in pipeline order, not alphabetically.
  col.accessor((claim) => claimStages.indexOf(claim.stage), {
    id: 'stage',
    header: 'Stage',
    sortDescFirst: false,
    cell: ({ row }) => <StageBadge stage={row.original.stage} />,
  }),
  col.accessor((claim) => claim.handler ?? '', {
    id: 'handler',
    header: 'Handler',
    cell: ({ getValue }) => getValue() || <span className="text-muted-foreground">Unassigned</span>,
  }),
  col.accessor('estimate', {
    header: 'Estimate',
    meta: { numeric: true },
    cell: ({ getValue }) => money.format(getValue()),
  }),
])

// Click a claim to work it in a side sheet.
export function ClaimsTable({ claims, handlers, empty }: Props) {
  const [open, setOpen] = useState<Claim | null>(null)
  return (
    <>
      <DataTable
        data={claims}
        columns={columns}
        empty={empty}
        initialSort={[{ id: 'reportedOn', desc: true }]}
        onRowClick={setOpen}
      />
      <Sheet open={open !== null} onOpenChange={(next) => !next && setOpen(null)}>
        <SheetContent>
          {open && (
            <ClaimForm
              key={open.id}
              claim={open}
              handlers={handlers}
              onDone={() => setOpen(null)}
            />
          )}
        </SheetContent>
      </Sheet>
    </>
  )
}

// Radix's Select can't hold an empty value, so "no handler" needs a stand-in.
const UNASSIGNED = 'unassigned'

type FormProps = { claim: Claim; handlers: Handler[]; onDone: () => void }

function ClaimForm({ claim, handlers, onDone }: FormProps) {
  const save = useSave()
  const [handler, setHandler] = useState(claim.handler ?? UNASSIGNED)
  const [stage, setStage] = useState<ClaimStage>(claim.stage)
  const [estimate, setEstimate] = useState(String(claim.estimate))
  const [saving, setSaving] = useState(false)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setSaving(true)
    const saved = await save(
      api.claims[':id'].$patch({
        param: { id: claim.id },
        json: {
          handler: handler === UNASSIGNED ? null : handler,
          stage,
          estimate: Number(estimate),
        },
      }),
      `Saved ${claim.id}`,
    )
    setSaving(false)
    if (saved) onDone()
  }

  return (
    <form onSubmit={submit} className="flex h-full flex-col gap-4">
      <SheetHeader>
        <SheetTitle>{claim.title}</SheetTitle>
        <SheetDescription>
          <span className="font-mono">{claim.id}</span> · {claim.policyholderName} ·{' '}
          {claim.kaiju ?? 'Unknown'}
        </SheetDescription>
      </SheetHeader>
      <FieldGroup className="px-4">
        <Field>
          <FieldLabel htmlFor="claim-handler">Handler</FieldLabel>
          <Select value={handler} onValueChange={setHandler}>
            <SelectTrigger id="claim-handler" className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={UNASSIGNED}>Unassigned</SelectItem>
              {handlers.map((h) => (
                <SelectItem key={h.id} value={h.name}>
                  {h.name} <span className="text-muted-foreground">({h.team})</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field>
          <FieldLabel htmlFor="claim-stage">Stage</FieldLabel>
          <Select
            value={stage}
            onValueChange={(next) => setStage(claimStages.find((s) => s === next) ?? stage)}
          >
            <SelectTrigger id="claim-stage" className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {claimStages.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field>
          <FieldLabel htmlFor="claim-estimate">Estimate ($)</FieldLabel>
          <Input
            id="claim-estimate"
            type="number"
            min={0}
            step={1}
            required
            value={estimate}
            onChange={(event) => setEstimate(event.target.value)}
          />
        </Field>
      </FieldGroup>
      <SheetFooter>
        <Button type="submit" disabled={saving}>
          Save
        </Button>
        <Button type="button" variant="outline" onClick={onDone}>
          Cancel
        </Button>
      </SheetFooter>
    </form>
  )
}
