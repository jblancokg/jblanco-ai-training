import type { PolicyStatus } from '@kaiju/api/enums'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const tone: Record<PolicyStatus, string> = {
  Active: 'border-hide/30 bg-hide/10 text-hide',
  'Renewal due': 'border-siren/40 bg-siren/10 text-foreground',
  Lapsed: 'border-rule bg-muted text-muted-foreground',
}

export function PolicyStatusBadge({ status }: { status: PolicyStatus }) {
  return (
    <Badge variant="outline" className={cn('font-medium', tone[status])}>
      {status}
    </Badge>
  )
}
