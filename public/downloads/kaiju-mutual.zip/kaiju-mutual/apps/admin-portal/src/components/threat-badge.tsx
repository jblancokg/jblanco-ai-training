import type { KaijuStatus, ThreatLevel } from '@kaiju/api/enums'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

// Same scale colours as the consumer portal's threat board.
export const threatTone: Record<ThreatLevel, string> = {
  Clear: 'bg-hide/15 text-hide',
  Watch: 'bg-[#e8b13a]/25 text-foreground',
  Advisory: 'bg-[#f48a2c]/30 text-foreground',
  Warning: 'bg-siren text-night',
  Evacuate: 'bg-[#d43f0a] text-paper',
}

export function ThreatBadge({ level }: { level: ThreatLevel }) {
  return (
    <Badge className={cn('border-transparent font-semibold', threatTone[level])}>{level}</Badge>
  )
}

const statusTone: Record<KaijuStatus, string> = {
  Dormant: 'border-rule bg-muted text-muted-foreground',
  Contained: 'border-hide/30 bg-hide/10 text-hide',
  Tracked: 'border-[#e8b13a]/50 bg-[#e8b13a]/15 text-foreground',
  Approaching: 'border-transparent bg-siren text-night',
  Landfall: 'border-transparent bg-[#d43f0a] text-paper',
}

export function KaijuStatusBadge({ status }: { status: KaijuStatus }) {
  return (
    <Badge variant="outline" className={cn('font-semibold', statusTone[status])}>
      {status}
    </Badge>
  )
}
