import { Link, useMatchRoute, useNavigate } from '@tanstack/react-router'
import {
  BookOpenIcon,
  ChevronsUpDownIcon,
  CloudSunIcon,
  FileTextIcon,
  FlameIcon,
  HistoryIcon,
  LandmarkIcon,
  LayoutDashboardIcon,
  LogOutIcon,
  MapIcon,
  MapPinnedIcon,
  ReceiptTextIcon,
  RulerIcon,
  ShieldIcon,
  SkullIcon,
  UserCogIcon,
  UsersIcon,
} from 'lucide-react'
import { signOut, type User } from '@/auth'
import { BrandMark } from '@/components/brand'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from '@/components/ui/sidebar'

const nav = [
  {
    label: 'Claims handling',
    items: [
      { to: '/', label: 'Overview', icon: LayoutDashboardIcon },
      { to: '/claims', label: 'Claims queue', icon: FileTextIcon },
      { to: '/policies', label: 'Policies', icon: ShieldIcon },
      { to: '/policyholders', label: 'Policyholders', icon: UsersIcon },
      { to: '/quotes', label: 'Quotes', icon: ReceiptTextIcon },
    ],
  },
  {
    label: 'Kaiju watch',
    items: [
      { to: '/kaiju', label: 'Kaiju status', icon: SkullIcon },
      { to: '/forecast', label: '7-day forecast', icon: CloudSunIcon },
      { to: '/municipal', label: 'Municipal estimates', icon: LandmarkIcon },
      { to: '/events', label: 'Event history', icon: HistoryIcon },
    ],
  },
  {
    label: 'Reference lists',
    items: [
      { to: '/reference/regions', label: 'Regions', icon: MapIcon },
      { to: '/reference/districts', label: 'Districts', icon: MapPinnedIcon },
      { to: '/reference/kaiju-classes', label: 'Kaiju classes', icon: RulerIcon },
      { to: '/reference/perils', label: 'Perils', icon: FlameIcon },
      { to: '/reference/plans', label: 'Plans', icon: BookOpenIcon },
      { to: '/reference/handlers', label: 'Claim handlers', icon: UserCogIcon },
    ],
  },
] as const

export function AppSidebar({ user }: { user: User }) {
  const matchRoute = useMatchRoute()
  const navigate = useNavigate()
  // The mobile sidebar is a sheet; close it once a page is picked.
  const { setOpenMobile } = useSidebar()
  const initials = user.name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild tooltip="Kaiju Mutual">
              <Link to="/">
                <BrandMark className="size-8! text-paper" />
                <span className="grid leading-tight">
                  <span className="text-base font-extrabold tracking-tight text-paper">
                    Kaiju Mutual
                  </span>
                  <span className="text-xs text-sidebar-foreground/70">Staff portal</span>
                </span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        {nav.map((group) => (
          <SidebarGroup key={group.label}>
            <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="gap-0.5">
                {group.items.map((item) => (
                  <SidebarMenuItem key={item.to}>
                    <SidebarMenuButton
                      asChild
                      tooltip={item.label}
                      isActive={Boolean(matchRoute({ to: item.to, fuzzy: item.to !== '/' }))}
                      className="data-active:bg-sidebar-accent data-active:shadow-[inset_3px_0_0_var(--siren)]"
                    >
                      <Link to={item.to} onClick={() => setOpenMobile(false)}>
                        <item.icon />
                        <span>{item.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg" tooltip={user.name}>
                  <Avatar className="size-8 rounded-lg">
                    <AvatarFallback className="rounded-lg bg-hide font-bold text-paper">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <span className="grid min-w-0 flex-1 leading-tight">
                    <span className="truncate font-semibold text-paper">{user.name}</span>
                    <span className="truncate text-xs text-sidebar-foreground/70">
                      {user.email}
                    </span>
                  </span>
                  <ChevronsUpDownIcon className="ml-auto" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                side="top"
                align="start"
                className="w-(--radix-dropdown-menu-trigger-width) min-w-56"
              >
                <DropdownMenuLabel className="font-normal text-muted-foreground">
                  Signed in as {user.email}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onSelect={() => {
                    signOut()
                    navigate({ to: '/login' })
                  }}
                >
                  <LogOutIcon />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
