import type { ClaimStage } from '@kaiju/api/enums'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const tone: Record<ClaimStage, string> = {
  Reported: 'border-siren/40 bg-siren/10 text-foreground',
  'Assessor visit': 'border-rule bg-muted text-foreground',
  Decision: 'border-night/30 bg-night text-paper',
  Paid: 'border-hide/30 bg-hide/10 text-hide',
}

export function StageBadge({ stage }: { stage: ClaimStage }) {
  return (
    <Badge variant="outline" className={cn('font-medium', tone[stage])}>
      {stage}
    </Badge>
  )
}
