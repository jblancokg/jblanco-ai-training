import {
  createPaginatedRowModel,
  createSortedRowModel,
  metaHelper,
  type PaginationState,
  type RowData,
  rowPaginationFeature,
  rowSortingFeature,
  type SortingState,
  sortFn_alphanumeric,
  sortFn_text,
  type TableOptions,
  tableFeatures,
  useTable,
} from '@tanstack/react-table'
import {
  ArrowDownIcon,
  ArrowUpIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronsUpDownIcon,
} from 'lucide-react'
import { type ReactNode, useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

type ColumnMeta = {
  // Right-aligned with tabular figures.
  numeric?: boolean
  // Added to the column's cells, e.g. to let long text wrap.
  className?: string
  headerClassName?: string
}

// Sorting and paging happen in the browser, on everything the API returned.
export const features = tableFeatures({
  rowSortingFeature,
  sortedRowModel: createSortedRowModel(),
  sortFns: { alphanumeric: sortFn_alphanumeric, text: sortFn_text },
  rowPaginationFeature,
  paginatedRowModel: createPaginatedRowModel(),
  columnMeta: metaHelper<ColumnMeta>(),
})

// Column helpers take this: `createColumnHelper<Features, Row>()`.
export type Features = typeof features

const pageSizes = [25, 50, 100] as const
const count = new Intl.NumberFormat('en-US')

type Props<T extends RowData> = {
  data: readonly T[]
  columns: TableOptions<Features, T>['columns']
  // Shown when `data` is empty.
  empty: string
  // Leave out to keep the order `data` came in.
  initialSort?: SortingState
  // Whatever narrowed `data` (search, filters). A change goes back to page 1,
  // a reload after a save doesn't.
  filters?: readonly unknown[]
  onRowClick?: (row: T) => void
  rowClassName?: (row: T) => string | undefined
  // Rows for a <tfoot>, e.g. totals.
  footer?: ReactNode
}

// Every table in the portal. See docs/training/admin-portal.md.
export function DataTable<T extends RowData>({
  data,
  columns,
  empty,
  initialSort,
  filters,
  onRowClick,
  rowClassName,
  footer,
}: Props<T>) {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: pageSizes[0],
  })
  const table = useTable({
    features,
    data,
    columns,
    initialState: { sorting: initialSort ?? [] },
    state: { pagination },
    onPaginationChange: setPagination,
    // Page resets are handled below, so a save doesn't throw you back to page 1.
    autoResetPageIndex: false,
  })

  const total = table.getRowCount()
  const lastPage = Math.max(Math.ceil(total / pagination.pageSize) - 1, 0)
  const resetKey = JSON.stringify([filters, table.state.sorting])
  const [lastResetKey, setLastResetKey] = useState(resetKey)
  if (resetKey !== lastResetKey) {
    setLastResetKey(resetKey)
    setPagination({ ...pagination, pageIndex: 0 })
  } else if (pagination.pageIndex > lastPage) {
    setPagination({ ...pagination, pageIndex: lastPage })
  }

  const rows = table.getRowModel().rows
  const first = pagination.pageIndex * pagination.pageSize

  return (
    <div className="grid gap-3">
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((group) => (
            <TableRow key={group.id}>
              {group.headers.map((header) => {
                const { column } = header
                const meta = column.columnDef.meta
                const sorted = column.getIsSorted()
                return (
                  <TableHead
                    key={header.id}
                    aria-sort={
                      sorted === 'asc' ? 'ascending' : sorted === 'desc' ? 'descending' : undefined
                    }
                    className={cn(meta?.numeric && 'text-right', meta?.headerClassName)}
                  >
                    {header.isPlaceholder ? null : column.getCanSort() ? (
                      <button
                        type="button"
                        onClick={column.getToggleSortingHandler()}
                        className="group/sort inline-flex items-center gap-1 rounded-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <table.FlexRender header={header} />
                        {sorted === 'asc' ? (
                          <ArrowUpIcon className="size-3.5" />
                        ) : sorted === 'desc' ? (
                          <ArrowDownIcon className="size-3.5" />
                        ) : (
                          <ChevronsUpDownIcon className="size-3.5 text-muted-foreground opacity-50 group-hover/sort:opacity-100" />
                        )}
                      </button>
                    ) : (
                      <table.FlexRender header={header} />
                    )}
                  </TableHead>
                )
              })}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {rows.length === 0 && (
            <TableRow>
              <TableCell
                colSpan={table.getAllLeafColumns().length}
                className="py-8 text-center text-muted-foreground"
              >
                {empty}
              </TableCell>
            </TableRow>
          )}
          {rows.map((row) => (
            <TableRow
              key={row.id}
              className={cn(onRowClick && 'relative cursor-pointer', rowClassName?.(row.original))}
            >
              {row.getAllCells().map((cell, index) => {
                const meta = cell.column.columnDef.meta
                return (
                  <TableCell
                    key={cell.id}
                    className={cn(meta?.numeric && 'text-right tabular-nums', meta?.className)}
                  >
                    {onRowClick && index === 0 ? (
                      // Stretched over the whole row, so the row is one big button.
                      <button
                        type="button"
                        onClick={() => onRowClick(row.original)}
                        className="text-left outline-none after:absolute after:inset-0 focus-visible:after:ring-2 focus-visible:after:ring-ring"
                      >
                        <table.FlexRender cell={cell} />
                      </button>
                    ) : (
                      <table.FlexRender cell={cell} />
                    )}
                  </TableCell>
                )
              })}
            </TableRow>
          ))}
        </TableBody>
        {footer && <TableFooter>{footer}</TableFooter>}
      </Table>
      {total > 0 && (
        <div className="flex flex-wrap items-center justify-end gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            Rows per page
            <Select
              value={String(pagination.pageSize)}
              onValueChange={(size) => table.setPageSize(Number(size))}
            >
              <SelectTrigger size="sm" aria-label="Rows per page" className="bg-paper">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {pageSizes.map((size) => (
                  <SelectItem key={size} value={String(size)}>
                    {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <span className="tabular-nums">
            {count.format(first + 1)}–{count.format(first + rows.length)} of {count.format(total)}
          </span>
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="icon-sm"
              aria-label="Previous page"
              disabled={!table.getCanPreviousPage()}
              onClick={() => table.previousPage()}
            >
              <ChevronLeftIcon />
            </Button>
            <Button
              variant="outline"
              size="icon-sm"
              aria-label="Next page"
              disabled={!table.getCanNextPage()}
              onClick={() => table.nextPage()}
            >
              <ChevronRightIcon />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
