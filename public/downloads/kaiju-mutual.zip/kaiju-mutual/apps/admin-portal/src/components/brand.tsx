import { cn } from '@/lib/utils'

// Same shield as the website header (apps/website/src/lib/components/Header.svelte).
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 28 28" aria-hidden="true" className={cn('size-7 shrink-0', className)}>
      <path d="M14 2 L26 8 V15 C26 21 20 25 14 27 C8 25 2 21 2 15 V8 Z" fill="currentColor" />
      <path d="M9 12 L14 8 L19 12 L17 19 L11 19 Z" fill="var(--siren)" />
    </svg>
  )
}
