import type { ReactNode } from 'react'

type Props = { title: string; description?: string; actions?: ReactNode }

export function PageHeader({ title, description, actions }: Props) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div className="grid gap-1">
        <h1 className="text-2xl font-extrabold">{title}</h1>
        {description && <p className="max-w-[70ch] text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions}
    </div>
  )
}
