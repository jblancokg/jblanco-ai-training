import { createColumnHelper } from '@tanstack/react-table'
import type { ClientResponse } from 'hono/client'
import { PencilIcon, PlusIcon, Trash2Icon } from 'lucide-react'
import { type FormEvent, type ReactNode, useState } from 'react'
import { useSave } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// The server owns these. Everything else on a row is editable.
type Server = 'id' | 'createdAt' | 'updatedAt' | 'deletedAt'
type Row = { id: string; createdAt: string; updatedAt: string; deletedAt: string | null }
type Editable<T> = Exclude<keyof T, Server> & string
type Fields<T> = Omit<T, Server>

// One variant per field, so `options` has to match that field's type.
export type Column<T> = {
  [K in Editable<T>]: {
    key: K
    label: string
    options?: readonly T[K][]
    render?: (row: T) => ReactNode
    numeric?: boolean
  }
}[Editable<T>]

// The part of a list's API client this uses, e.g. `api.reference.regions`.
type ListClient<T> = {
  $post: (args: { json: Fields<T> }) => Promise<ClientResponse<unknown>>
  ':id': {
    $patch: (args: {
      param: { id: string }
      json: Partial<Fields<T>>
    }) => Promise<ClientResponse<unknown>>
    $delete: (args: { param: { id: string } }) => Promise<ClientResponse<unknown>>
  }
}

type Props<T extends Row & Record<Editable<T>, string | number>> = {
  title: string
  description: string
  noun: string
  rows: readonly T[]
  client: ListClient<T>
  columns: Column<T>[]
  // The add dialog starts from this.
  blank: Fields<T>
}

// Add, edit and delete for a reference list, saved straight to the API.
// See docs/training/admin-portal.md.
export function ListManager<T extends Row & Record<Editable<T>, string | number>>({
  title,
  description,
  noun,
  rows,
  client,
  columns,
  blank,
}: Props<T>) {
  const save = useSave()
  // `editing` is null while adding.
  const [draft, setDraft] = useState<{ editing: T | null; fields: Fields<T> } | null>(null)
  const isNew = draft?.editing === null

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!draft) return
    const { editing, fields } = draft
    const saved = await save(
      editing
        ? client[':id'].$patch({ param: { id: editing.id }, json: fields })
        : client.$post({ json: fields }),
      `${editing ? 'Saved' : 'Added'} ${noun}`,
    )
    if (saved) setDraft(null)
  }

  const edit = (row: T) => {
    const { id, createdAt, updatedAt, deletedAt, ...fields } = row
    setDraft({ editing: row, fields })
  }

  const remove = (row: T) => {
    if (!confirm(`Delete this ${noun}? It can't be undone here.`)) return
    save(client[':id'].$delete({ param: { id: row.id } }), `Deleted ${noun}`)
  }

  const col = createColumnHelper<Features, T>()
  const tableColumns = col.columns([
    ...columns.map((column) =>
      col.accessor((row: T) => row[column.key], {
        id: column.key,
        header: column.label,
        meta: { numeric: column.numeric },
        cell: ({ row }) =>
          column.render?.(row.original) ?? row.original[column.key].toLocaleString('en-US'),
      }),
    ),
    col.display({
      id: 'actions',
      header: () => <span className="sr-only">Actions</span>,
      meta: { className: 'text-right', headerClassName: 'w-24' },
      cell: ({ row }) => (
        <>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={`Edit ${noun}`}
            onClick={() => edit(row.original)}
          >
            <PencilIcon />
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={`Delete ${noun}`}
            onClick={() => remove(row.original)}
          >
            <Trash2Icon />
          </Button>
        </>
      ),
    }),
  ])

  return (
    <>
      <PageHeader
        title={title}
        description={description}
        actions={
          <Button onClick={() => setDraft({ editing: null, fields: blank })}>
            <PlusIcon />
            Add {noun}
          </Button>
        }
      />
      <Card>
        <CardContent>
          <DataTable data={rows} columns={tableColumns} empty="Nothing here yet." />
        </CardContent>
      </Card>

      <Dialog open={draft !== null} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent>
          {draft && (
            <form onSubmit={submit} className="grid gap-6">
              <DialogHeader>
                <DialogTitle>
                  {isNew ? 'Add' : 'Edit'} {noun}
                </DialogTitle>
              </DialogHeader>
              <FieldGroup>
                {columns.map((column) => {
                  const value = draft.fields[column.key]
                  const set = (next: string | number) =>
                    setDraft({ ...draft, fields: { ...draft.fields, [column.key]: next } })
                  const id = `field-${column.key}`
                  return (
                    <Field key={column.key}>
                      <FieldLabel htmlFor={id}>{column.label}</FieldLabel>
                      {column.options ? (
                        <Select
                          value={String(value)}
                          onValueChange={(next) =>
                            set(column.options?.find((option) => String(option) === next) ?? next)
                          }
                        >
                          <SelectTrigger id={id} className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {column.options.map((option) => (
                              <SelectItem key={String(option)} value={String(option)}>
                                {String(option)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          id={id}
                          required
                          type={typeof value === 'number' ? 'number' : 'text'}
                          value={value}
                          onChange={(event) =>
                            set(
                              typeof value === 'number'
                                ? event.target.valueAsNumber
                                : event.target.value,
                            )
                          }
                        />
                      )}
                    </Field>
                  )
                })}
              </FieldGroup>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDraft(null)}>
                  Cancel
                </Button>
                <Button type="submit">{isNew ? `Add ${noun}` : 'Save'}</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
