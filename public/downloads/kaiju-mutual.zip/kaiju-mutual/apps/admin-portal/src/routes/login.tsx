import { createFileRoute, redirect, useNavigate } from '@tanstack/react-router'
import { type FormEvent, useState } from 'react'
import { getUser, signIn } from '@/auth'
import { BrandMark } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'

type LoginSearch = { redirect?: string }

export const Route = createFileRoute('/login')({
  validateSearch: (search: Record<string, unknown>): LoginSearch => ({
    redirect: typeof search.redirect === 'string' ? search.redirect : undefined,
  }),
  beforeLoad: () => {
    if (getUser()) throw redirect({ to: '/' })
  },
  component: Login,
})

function Login() {
  const { redirect: back } = Route.useSearch()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')

  const submit = (event: FormEvent) => {
    event.preventDefault()
    signIn(email)
    navigate({ to: back ?? '/' })
  }

  return (
    <div className="grid min-h-svh lg:grid-cols-[1.1fr_1fr]">
      <aside className="relative flex flex-col justify-between gap-12 overflow-hidden bg-night p-8 text-paper md:p-12">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:repeating-linear-gradient(-45deg,var(--paper)_0_2px,transparent_2px_14px)]"
        />
        <div className="relative flex items-center gap-3 text-xl font-extrabold tracking-tight">
          <BrandMark className="size-8" />
          Kaiju Mutual
        </div>
        <div className="relative grid gap-5">
          <h1 className="max-w-[14ch] text-5xl leading-[0.95] font-extrabold tracking-[-0.035em] md:text-6xl">
            Staff portal
          </h1>
          <p className="max-w-[44ch] text-lg text-sidebar-foreground">
            Work the claims queue and look up policyholders.
          </p>
        </div>
        <p className="relative text-sm text-sidebar-foreground/80">
          For Kaiju Mutual staff only. Policyholders sign in to the consumer portal.
        </p>
      </aside>

      <main className="flex items-center justify-center bg-paper p-8 md:p-12">
        <form onSubmit={submit} className="grid w-full max-w-sm gap-8">
          <div className="grid gap-2">
            <h2 className="text-3xl font-extrabold">Sign in</h2>
            <p className="text-muted-foreground">Use your work email address.</p>
          </div>
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="email">Email</FieldLabel>
              <Input
                id="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@kaijumutual.example"
                className="h-10 bg-white"
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="password">Password</FieldLabel>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                className="h-10 bg-white"
              />
              <FieldDescription>
                Any password works while the portal is in training.
              </FieldDescription>
            </Field>
          </FieldGroup>
          <Button type="submit" size="lg" className="h-11 text-base">
            Sign in
          </Button>
        </form>
      </main>
    </div>
  )
}
