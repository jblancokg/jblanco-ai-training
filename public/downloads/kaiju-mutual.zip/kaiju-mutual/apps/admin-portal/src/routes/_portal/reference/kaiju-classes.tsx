import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'

export const Route = createFileRoute('/_portal/reference/kaiju-classes')({
  loader: () => unwrap(api.reference['kaiju-classes'].$get()),
  component: () => (
    <ListManager
      title="Kaiju classes"
      description="Size bands used to rate kaiju and price the risk they pose."
      noun="class"
      rows={Route.useLoaderData()}
      client={api.reference['kaiju-classes']}
      blank={{ name: '', minHeightM: 0, maxHeightM: 0, description: '' }}
      columns={[
        { key: 'name', label: 'Class' },
        { key: 'minHeightM', label: 'From (m)', numeric: true },
        { key: 'maxHeightM', label: 'To (m)', numeric: true },
        { key: 'description', label: 'What it means' },
      ]}
    />
  ),
})
