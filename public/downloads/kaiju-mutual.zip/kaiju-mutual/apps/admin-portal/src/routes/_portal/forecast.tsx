import { threatLevels } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { ThreatBadge, threatTone } from '@/components/threat-badge'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/_portal/forecast')({
  loader: () => unwrap(api.forecast.$get()),
  component: Forecast,
})

const weekday = new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone: 'UTC' })

type DistrictForecast = InferResponseType<typeof api.forecast.$get, 200>[number]

const col = createColumnHelper<Features, DistrictForecast>()
const columns = col.columns([
  col.accessor('district', { header: 'District', meta: { className: 'font-semibold' } }),
  ...Array.from({ length: 7 }, (_, offset) =>
    // Sorts by threat level, not alphabetically.
    col.accessor(
      (row) => {
        const level = row.days[offset]
        return level ? threatLevels.indexOf(level) : -1
      },
      {
        id: `day-${offset}`,
        // Every district's forecast starts on the same day.
        header: ({ table }) => {
          if (offset === 0) return 'Today'
          const date = new Date(table.options.data[0]?.startsOn ?? Date.now())
          date.setUTCDate(date.getUTCDate() + offset)
          return `${weekday.format(date)} ${date.getUTCDate()}`
        },
        meta: { className: 'p-1', headerClassName: 'text-center' },
        cell: ({ row }) => {
          const level = row.original.days[offset]
          return (
            level && (
              <div
                title={level}
                className={cn(
                  'grid h-9 min-w-16 place-items-center rounded-md text-xs font-semibold',
                  threatTone[level],
                )}
              >
                {level}
              </div>
            )
          )
        },
      },
    ),
  ),
  col.accessor((row) => row.driver ?? '', {
    id: 'driver',
    header: 'Driven by',
    meta: { className: 'min-w-64 whitespace-normal' },
    cell: ({ row }) => (
      <>
        <div className="font-medium">{row.original.driver ?? 'Nothing nearby'}</div>
        <div className="text-xs text-muted-foreground">{row.original.note}</div>
      </>
    ),
  }),
])

function Forecast() {
  const forecast = Route.useLoaderData()
  // Worst week first.
  const byRisk = forecast.toSorted(
    (a, b) =>
      b.days.reduce((sum, level) => sum + threatLevels.indexOf(level), 0) -
      a.days.reduce((sum, level) => sum + threatLevels.indexOf(level), 0),
  )
  return (
    <>
      <PageHeader
        title="7-day forecast"
        description="Expected civil-defence threat level per district, from the coastal watch's tracks. Worst week first."
        actions={
          <div className="flex flex-wrap gap-1.5">
            {threatLevels.map((level) => (
              <ThreatBadge key={level} level={level} />
            ))}
          </div>
        }
      />
      <Card>
        <CardContent>
          <DataTable data={byRisk} columns={columns} empty="No forecast yet." />
        </CardContent>
      </Card>
    </>
  )
}
