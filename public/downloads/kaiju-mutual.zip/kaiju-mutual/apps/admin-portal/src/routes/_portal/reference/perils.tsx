import { perilCoverage } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'

export const Route = createFileRoute('/_portal/reference/perils')({
  loader: () => unwrap(api.reference.perils.$get()),
  component: () => (
    <ListManager
      title="Perils"
      description="The kinds of damage a claim can be filed under, and which plans cover them."
      noun="peril"
      rows={Route.useLoaderData()}
      client={api.reference.perils}
      blank={{ name: '', covered: 'All plans' }}
      columns={[
        { key: 'name', label: 'Peril' },
        { key: 'covered', label: 'Covered on', options: perilCoverage },
      ]}
    />
  ),
})
