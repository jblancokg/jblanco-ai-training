import { claimStages } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ClaimsTable } from '@/components/claims-table'
import { PageHeader } from '@/components/page-header'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export const Route = createFileRoute('/_portal/claims')({
  loader: async () => {
    const [claims, handlers] = await Promise.all([
      unwrap(api.claims.$get()),
      unwrap(api.reference.handlers.$get()),
    ])
    return { claims, handlers }
  },
  component: Claims,
})

function Claims() {
  const { claims, handlers } = Route.useLoaderData()
  const tabs = [
    { value: 'All', claims },
    ...claimStages.map((stage) => ({
      value: stage,
      claims: claims.filter((claim) => claim.stage === stage),
    })),
  ]
  return (
    <>
      <PageHeader
        title="Claims queue"
        description="Every claim across all policyholders, newest first."
      />
      <Tabs defaultValue="All">
        <TabsList className="bg-rule/50">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.value} value={tab.value} className="data-active:bg-paper">
              {tab.value} ({tab.claims.length})
            </TabsTrigger>
          ))}
        </TabsList>
        {tabs.map((tab) => (
          <TabsContent key={tab.value} value={tab.value} className="mt-2">
            <Card>
              <CardContent>
                <ClaimsTable
                  claims={tab.claims}
                  handlers={handlers}
                  empty={`No claims at ${tab.value}.`}
                />
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </>
  )
}
