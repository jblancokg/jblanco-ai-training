import { type EventType, eventTypes } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { useState } from 'react'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { ALL, FilterSelect } from '@/components/filter-select'
import { PageHeader } from '@/components/page-header'
import { ThreatBadge } from '@/components/threat-badge'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { dateTime, money } from '@/lib/format'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/_portal/events')({
  loader: async () => {
    const [events, districts] = await Promise.all([
      unwrap(api.events.$get()),
      unwrap(api.reference.districts.$get()),
    ])
    return { events, districts }
  },
  component: Events,
})

const typeTone: Record<EventType, string> = {
  Sighting: 'border-[#e8b13a]/50 bg-[#e8b13a]/15 text-foreground',
  Landfall: 'border-transparent bg-[#d43f0a] text-paper',
  Containment: 'border-hide/30 bg-hide/10 text-hide',
  Retreat: 'border-rule bg-muted text-muted-foreground',
  'Threat level': 'border-night/30 bg-night text-paper',
}

type KaijuEvent = InferResponseType<typeof api.events.$get, 200>[number]

const col = createColumnHelper<Features, KaijuEvent>()
const columns = col.columns([
  col.accessor('at', {
    header: 'When',
    meta: { className: 'tabular-nums' },
    cell: ({ getValue }) => dateTime.format(new Date(getValue())),
  }),
  col.accessor('type', {
    header: 'Event',
    cell: ({ row }) => (
      <div className="flex items-center gap-1.5">
        <Badge variant="outline" className={cn('font-semibold', typeTone[row.original.type])}>
          {row.original.type}
        </Badge>
        {row.original.level && <ThreatBadge level={row.original.level} />}
      </div>
    ),
  }),
  col.accessor('kaiju', { header: 'Kaiju', meta: { className: 'font-medium' } }),
  col.accessor('district', { header: 'District' }),
  col.accessor('summary', {
    header: 'What happened',
    enableSorting: false,
    meta: { className: 'min-w-60 whitespace-normal' },
  }),
  col.accessor('claims', { header: 'Claims', meta: { numeric: true } }),
  col.accessor('paidOut', {
    header: 'Paid out',
    meta: { numeric: true },
    cell: ({ getValue }) => {
      const paidOut = getValue()
      return paidOut ? money.format(paidOut) : '–'
    },
  }),
])

function Events() {
  const { events, districts } = Route.useLoaderData()
  const kaijuNames = [...new Set(events.map((event) => event.kaiju))].sort()
  const [type, setType] = useState<string>(ALL)
  const [kaiju, setKaiju] = useState<string>(ALL)
  const [district, setDistrict] = useState<string>(ALL)

  const rows = events.filter(
    (event) =>
      (type === ALL || event.type === type) &&
      (kaiju === ALL || event.kaiju === kaiju) &&
      (district === ALL || event.district === district),
  )

  return (
    <>
      <PageHeader
        title="Event history"
        description="What every kaiju has done, newest first, and the claims each event led to."
      />
      <div className="flex flex-wrap gap-3">
        <FilterSelect label="Type" value={type} onChange={setType} options={eventTypes} />
        <FilterSelect label="Kaiju" value={kaiju} onChange={setKaiju} options={kaijuNames} />
        <FilterSelect
          label="District"
          value={district}
          onChange={setDistrict}
          options={districts.map((d) => d.name)}
        />
      </div>
      <Card>
        <CardContent>
          <DataTable
            data={rows}
            columns={columns}
            empty="No events match."
            initialSort={[{ id: 'at', desc: true }]}
            filters={[type, kaiju, district]}
          />
        </CardContent>
      </Card>
    </>
  )
}
