import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { useState } from 'react'
import { api, unwrap, useSave } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { day, money } from '@/lib/format'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/_portal/quotes')({
  validateSearch: (search): { withdrawn?: true } =>
    search.withdrawn === true ? { withdrawn: true } : {},
  loaderDeps: ({ search }) => ({ withdrawn: search.withdrawn }),
  loader: ({ deps }) =>
    unwrap(api.quotes.$get({ query: deps.withdrawn ? { withdrawn: 'true' } : {} })),
  component: Quotes,
})

type Quote = InferResponseType<typeof api.quotes.$get, 200>[number]

const col = createColumnHelper<Features, Quote>()
const columns = col.columns([
  col.accessor('id', {
    header: 'Quote',
    cell: ({ row: { original: quote } }) => (
      <>
        <div className="font-mono">{quote.id}</div>
        {quote.deletedAt ? (
          <Badge variant="outline" className="border-rule bg-muted">
            Withdrawn
          </Badge>
        ) : (
          // Same UTC date the API sets expiries from.
          quote.expiresOn < new Date().toISOString().slice(0, 10) && (
            <Badge variant="outline" className="border-siren/40 bg-siren/10">
              Expired
            </Badge>
          )
        )}
      </>
    ),
  }),
  col.accessor('name', {
    header: 'Customer',
    cell: ({ row: { original: quote } }) => (
      <>
        <div className={cn('font-medium', quote.deletedAt && 'line-through')}>{quote.name}</div>
        <div className="max-w-52 truncate text-xs text-muted-foreground" title={quote.email}>
          {quote.email}
        </div>
      </>
    ),
  }),
  col.accessor('plan', { header: 'Plan' }),
  col.accessor('property', {
    header: 'Property',
    meta: { className: 'min-w-32 whitespace-normal' },
    cell: ({ row: { original: quote } }) => (
      <>
        <div>{quote.property}</div>
        <div className="text-xs text-muted-foreground">{quote.district}</div>
      </>
    ),
  }),
  col.accessor('monthly', {
    header: 'Per month',
    meta: { numeric: true },
    cell: ({ getValue }) => money.format(getValue()),
  }),
  col.accessor('expiresOn', {
    header: 'Expires',
    cell: ({ getValue }) => day.format(new Date(getValue())),
  }),
  col.accessor('createdAt', {
    header: 'Created',
    // SQLite timestamps are UTC, so the date part is enough for `day`.
    cell: ({ getValue }) => day.format(new Date(getValue().slice(0, 10))),
  }),
  col.display({
    id: 'actions',
    header: () => <span className="sr-only">Actions</span>,
    meta: { className: 'text-right' },
    cell: ({ row: { original: quote } }) => !quote.deletedAt && <WithdrawButton id={quote.id} />,
  }),
])

function WithdrawButton({ id }: { id: string }) {
  const save = useSave()
  const [withdrawing, setWithdrawing] = useState(false)

  const withdraw = async () => {
    if (!confirm(`Withdraw ${id}? The customer's price stops being valid.`)) return
    setWithdrawing(true)
    await save(api.quotes[':id'].$delete({ param: { id } }), `Withdrew ${id}`)
    setWithdrawing(false)
  }

  return (
    <Button variant="outline" size="xs" disabled={withdrawing} onClick={withdraw}>
      Withdraw
    </Button>
  )
}

function Quotes() {
  const quotes = Route.useLoaderData()
  const { withdrawn } = Route.useSearch()
  const navigate = Route.useNavigate()

  return (
    <>
      <PageHeader
        title="Quotes"
        description="Prices customers got from the website, newest first. A quote can't be changed, only withdrawn."
        actions={
          <Label className="font-normal">
            <input
              type="checkbox"
              checked={withdrawn ?? false}
              onChange={(event) =>
                navigate({ search: event.target.checked ? { withdrawn: true } : {} })
              }
              className="size-4 accent-night"
            />
            Show withdrawn
          </Label>
        }
      />
      <Card>
        <CardContent>
          <DataTable
            data={quotes}
            columns={columns}
            empty="No quotes yet."
            initialSort={[{ id: 'createdAt', desc: true }]}
            filters={[withdrawn]}
            rowClassName={(quote) => (quote.deletedAt ? 'text-muted-foreground' : undefined)}
          />
        </CardContent>
      </Card>
    </>
  )
}
