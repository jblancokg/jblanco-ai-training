import { createFileRoute, Outlet, redirect } from '@tanstack/react-router'
import { api } from '@/api'
import { getUser } from '@/auth'
import { AppSidebar } from '@/components/app-sidebar'
import { Badge } from '@/components/ui/badge'
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'

// Every page behind sign-in lives under this layout.
export const Route = createFileRoute('/_portal')({
  beforeLoad: ({ location }) => {
    const user = getUser()
    if (!user) throw redirect({ to: '/login', search: { redirect: location.href } })
    return { user }
  },
  // Drives the API badge in the header. A down API shouldn't take the layout with it.
  loader: async () => {
    try {
      const res = await api.health.$get()
      return res.ok ? await res.json() : null
    } catch {
      return null
    }
  },
  component: PortalLayout,
})

function PortalLayout() {
  const { user } = Route.useRouteContext()
  const health = Route.useLoaderData()
  return (
    <SidebarProvider>
      <AppSidebar user={user} />
      <SidebarInset className="bg-background">
        <header className="sticky top-0 z-10 flex h-12 items-center gap-3 border-b border-rule/60 bg-background/90 px-4 backdrop-blur md:px-6">
          <SidebarTrigger className="-ml-1" />
          <Badge
            variant="outline"
            className="ml-auto gap-1.5 font-normal"
            title={health ? `SQLite ${health.sqlite}` : undefined}
          >
            <span className={`size-2 rounded-full ${health ? 'bg-hide' : 'bg-destructive'}`} />
            {health ? 'API online' : 'API unreachable'}
          </Badge>
        </header>
        <div className="grid w-full gap-6 px-4 py-6 md:px-6">
          <Outlet />
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
