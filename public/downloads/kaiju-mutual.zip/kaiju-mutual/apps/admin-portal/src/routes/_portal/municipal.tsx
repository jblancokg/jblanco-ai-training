import { threatLevels } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { ThreatBadge } from '@/components/threat-badge'
import { Card, CardContent, CardDescription, CardHeader } from '@/components/ui/card'
import { TableCell, TableRow } from '@/components/ui/table'

export const Route = createFileRoute('/_portal/municipal')({
  loader: () => unwrap(api.municipal.$get()),
  component: Municipal,
})

const compact = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  notation: 'compact',
  maximumFractionDigits: 1,
})

type Estimate = InferResponseType<typeof api.municipal.$get, 200>[number]

const col = createColumnHelper<Features, Estimate>()
const columns = col.columns([
  col.accessor('asset', {
    header: 'Asset',
    meta: { className: 'min-w-48 whitespace-normal' },
    cell: ({ row }) => (
      <>
        <div className="font-medium">{row.original.asset}</div>
        <div className="text-xs text-muted-foreground">
          {row.original.kind} · <span className="font-mono">{row.original.policyId}</span>
        </div>
      </>
    ),
  }),
  col.accessor('municipality', { header: 'Municipality' }),
  col.accessor('district', { header: 'District' }),
  col.accessor((row) => threatLevels.indexOf(row.peak), {
    id: 'peak',
    header: 'Worst day',
    cell: ({ row }) => <ThreatBadge level={row.original.peak} />,
  }),
  col.accessor('insuredValue', {
    header: 'Insured',
    meta: { numeric: true },
    cell: ({ getValue }) => compact.format(getValue()),
  }),
  col.accessor('damageRatio', {
    header: 'Damage ratio',
    meta: { numeric: true },
    cell: ({ getValue }) => `${(getValue() * 100).toFixed(1)}%`,
  }),
  col.accessor('loss', {
    header: 'Expected loss',
    meta: { numeric: true, className: 'font-semibold' },
    cell: ({ getValue }) => compact.format(getValue()),
  }),
])

function Municipal() {
  // The API estimates each asset at the worst level its district hits this week.
  const estimates = Route.useLoaderData()

  const insured = estimates.reduce((sum, row) => sum + row.insuredValue, 0)
  const loss = estimates.reduce((sum, row) => sum + row.loss, 0)

  const lossByMunicipality = new Map<string, number>()
  for (const row of estimates) {
    lossByMunicipality.set(
      row.municipality,
      (lossByMunicipality.get(row.municipality) ?? 0) + row.loss,
    )
  }
  const [worstName, worstLoss] = [...lossByMunicipality].sort(([, a], [, b]) => b - a)[0] ?? [
    'None',
    0,
  ]

  const totals = [
    { label: 'Insured municipal assets', value: compact.format(insured) },
    { label: 'Expected loss this week', value: compact.format(loss) },
    { label: `Most exposed: ${worstName}`, value: compact.format(worstLoss) },
  ]

  return (
    <>
      <PageHeader
        title="Municipal estimates"
        description="Expected loss on insured public assets if each district hits its worst forecast day this week. Insured value times the damage ratio for that threat level."
      />
      <div className="grid gap-4 md:grid-cols-3">
        {totals.map((total) => (
          <Card key={total.label} size="sm">
            <CardHeader>
              <CardDescription>{total.label}</CardDescription>
              <p className="text-3xl font-extrabold tabular-nums">{total.value}</p>
            </CardHeader>
          </Card>
        ))}
      </div>
      <Card>
        <CardContent>
          <DataTable
            data={estimates}
            columns={columns}
            empty="No insured municipal assets."
            initialSort={[{ id: 'loss', desc: true }]}
            footer={
              <TableRow>
                <TableCell colSpan={4}>Total</TableCell>
                <TableCell className="text-right tabular-nums">{compact.format(insured)}</TableCell>
                <TableCell />
                <TableCell className="text-right tabular-nums">{compact.format(loss)}</TableCell>
              </TableRow>
            }
          />
        </CardContent>
      </Card>
    </>
  )
}
