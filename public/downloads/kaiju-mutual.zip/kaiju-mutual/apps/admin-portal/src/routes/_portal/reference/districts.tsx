import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'

export const Route = createFileRoute('/_portal/reference/districts')({
  loader: async () => {
    const [districts, regions] = await Promise.all([
      unwrap(api.reference.districts.$get()),
      unwrap(api.reference.regions.$get()),
    ])
    return { districts, regions }
  },
  component: Districts,
})

function Districts() {
  const { districts, regions } = Route.useLoaderData()
  return (
    <ListManager
      title="Districts"
      description="The areas we price, forecast and report threat levels for."
      noun="district"
      rows={districts}
      client={api.reference.districts}
      blank={{ code: '', name: '', region: regions[0]?.name ?? '', shelterBeds: 0 }}
      columns={[
        {
          key: 'code',
          label: 'Code',
          render: (row) => <span className="font-mono">{row.code}</span>,
        },
        { key: 'name', label: 'Name' },
        { key: 'region', label: 'Region', options: regions.map((region) => region.name) },
        { key: 'shelterBeds', label: 'Shelter beds', numeric: true },
      ]}
    />
  )
}
