import { planNames, policyStatuses } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { SearchIcon } from 'lucide-react'
import { useState } from 'react'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { ALL, FilterSelect } from '@/components/filter-select'
import { PageHeader } from '@/components/page-header'
import { PolicyStatusBadge } from '@/components/policy-status-badge'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { day, money } from '@/lib/format'

export const Route = createFileRoute('/_portal/policies')({
  loader: () => unwrap(api.policies.$get()),
  component: Policies,
})

type Policy = InferResponseType<typeof api.policies.$get, 200>[number]

const col = createColumnHelper<Features, Policy>()
const columns = col.columns([
  col.accessor('id', {
    header: 'Policy',
    meta: { className: 'min-w-48 whitespace-normal' },
    cell: ({ row }) => (
      <>
        <div className="font-medium">{row.original.property}</div>
        <div className="font-mono text-xs text-muted-foreground">{row.original.id}</div>
      </>
    ),
  }),
  col.accessor('policyholderName', { header: 'Policyholder' }),
  col.accessor('plan', { header: 'Plan' }),
  col.accessor('district', { header: 'District' }),
  col.accessor('status', {
    header: 'Status',
    cell: ({ getValue }) => <PolicyStatusBadge status={getValue()} />,
  }),
  col.accessor('renewsOn', {
    header: 'Renews',
    cell: ({ getValue }) => day.format(new Date(getValue())),
  }),
  col.accessor('monthly', {
    header: 'Per month',
    meta: { numeric: true },
    cell: ({ getValue }) => money.format(getValue()),
  }),
])

function Policies() {
  const policies = Route.useLoaderData()
  const [query, setQuery] = useState('')
  const [plan, setPlan] = useState<string>(ALL)
  const [status, setStatus] = useState<string>(ALL)

  const needle = query.trim().toLowerCase()
  const rows = policies.filter(
    (row) =>
      (plan === ALL || row.plan === plan) &&
      (status === ALL || row.status === status) &&
      [row.id, row.property, row.policyholderName].some((field) =>
        field.toLowerCase().includes(needle),
      ),
  )

  return (
    <>
      <PageHeader
        title="Policies"
        description="Every policy on the books. Search by policy number, property or policyholder."
      />
      <div className="flex flex-wrap gap-3">
        <div className="relative w-full sm:w-72">
          <SearchIcon className="absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search"
            aria-label="Search policies"
            className="bg-paper pl-8"
          />
        </div>
        <FilterSelect label="Plan" value={plan} onChange={setPlan} options={planNames} />
        <FilterSelect label="Status" value={status} onChange={setStatus} options={policyStatuses} />
      </div>
      <Card>
        <CardContent>
          <DataTable
            data={rows}
            columns={columns}
            empty="No policies match."
            initialSort={[{ id: 'id', desc: false }]}
            filters={[needle, plan, status]}
          />
        </CardContent>
      </Card>
    </>
  )
}
