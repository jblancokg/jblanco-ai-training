import { regionCoasts } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'

export const Route = createFileRoute('/_portal/reference/regions')({
  loader: () => unwrap(api.reference.regions.$get()),
  component: () => (
    <ListManager
      title="Regions"
      description="Groups of districts that share a coastline and a civil-defence command."
      noun="region"
      rows={Route.useLoaderData()}
      client={api.reference.regions}
      blank={{ name: '', coast: 'Bay' }}
      columns={[
        { key: 'name', label: 'Name' },
        { key: 'coast', label: 'Coast', options: regionCoasts },
      ]}
    />
  ),
})
