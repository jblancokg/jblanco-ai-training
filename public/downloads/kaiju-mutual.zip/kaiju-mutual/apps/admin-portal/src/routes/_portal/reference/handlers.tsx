import { handlerTeams } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'

export const Route = createFileRoute('/_portal/reference/handlers')({
  loader: () => unwrap(api.reference.handlers.$get()),
  component: () => (
    <ListManager
      title="Claim handlers"
      description="Staff who can be assigned claims, and the team that routes work to them."
      noun="handler"
      rows={Route.useLoaderData()}
      client={api.reference.handlers}
      blank={{ name: '', email: '', team: 'Household' }}
      columns={[
        { key: 'name', label: 'Name' },
        { key: 'email', label: 'Email' },
        { key: 'team', label: 'Team', options: handlerTeams },
      ]}
    />
  ),
})
