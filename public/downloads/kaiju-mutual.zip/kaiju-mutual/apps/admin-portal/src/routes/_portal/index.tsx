import { createFileRoute, Link } from '@tanstack/react-router'
import { ArrowRightIcon } from 'lucide-react'
import { api, unwrap } from '@/api'
import { type Claim, ClaimsTable } from '@/components/claims-table'
import { PageHeader } from '@/components/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { money } from '@/lib/format'

export const Route = createFileRoute('/_portal/')({
  loader: async () => {
    const [claims, handlers] = await Promise.all([
      unwrap(api.claims.$get()),
      unwrap(api.reference.handlers.$get()),
    ])
    return { claims, handlers }
  },
  component: Overview,
})

// A claim waits on staff until someone picks it up, and again once it's ready for a decision.
const waitingOnStaff = (claim: Claim) =>
  claim.stage === 'Decision' || (claim.stage === 'Reported' && !claim.handler)

function Overview() {
  const { user } = Route.useRouteContext()
  const { claims, handlers } = Route.useLoaderData()
  const open = claims.filter((claim) => claim.stage !== 'Paid')
  const waiting = claims.filter(waitingOnStaff)

  const totals = [
    { label: 'Open claims', value: open.length },
    { label: 'Unassigned', value: open.filter((claim) => !claim.handler).length },
    { label: 'Awaiting decision', value: open.filter((c) => c.stage === 'Decision').length },
    { label: 'Open estimate', value: money.format(open.reduce((sum, c) => sum + c.estimate, 0)) },
  ]

  return (
    <>
      <PageHeader
        title="Overview"
        description={`Signed in as ${user.name}. What the queue looks like right now.`}
      />
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {totals.map((total) => (
          <Card key={total.label} size="sm">
            <CardHeader>
              <CardDescription>{total.label}</CardDescription>
              <p className="text-3xl font-extrabold tabular-nums">{total.value}</p>
            </CardHeader>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Waiting on staff</CardTitle>
          <CardDescription>
            New claims nobody has picked up, and claims ready for a decision.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ClaimsTable
            claims={waiting}
            handlers={handlers}
            empty="Nothing waiting. Enjoy the quiet."
          />
        </CardContent>
      </Card>
      <Button asChild variant="outline" className="justify-self-start">
        <Link to="/claims">
          Full claims queue
          <ArrowRightIcon />
        </Link>
      </Button>
    </>
  )
}
