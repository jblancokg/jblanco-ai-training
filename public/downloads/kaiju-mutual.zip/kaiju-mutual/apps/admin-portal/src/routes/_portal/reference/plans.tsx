import { planNames } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { api, unwrap } from '@/api'
import { ListManager } from '@/components/list-manager'
import { money } from '@/lib/format'

export const Route = createFileRoute('/_portal/reference/plans')({
  loader: () => unwrap(api.reference.plans.$get()),
  component: () => (
    <ListManager
      title="Plans"
      description="The products we sell. Prices here are the starting point before district loading."
      noun="plan"
      rows={Route.useLoaderData()}
      client={api.reference.plans}
      blank={{ name: 'Household', monthlyFrom: 0, excess: 0 }}
      columns={[
        { key: 'name', label: 'Plan', options: planNames },
        {
          key: 'monthlyFrom',
          label: 'From per month',
          numeric: true,
          render: (row) => money.format(row.monthlyFrom),
        },
        {
          key: 'excess',
          label: 'Excess',
          numeric: true,
          render: (row) => money.format(row.excess),
        },
      ]}
    />
  ),
})
