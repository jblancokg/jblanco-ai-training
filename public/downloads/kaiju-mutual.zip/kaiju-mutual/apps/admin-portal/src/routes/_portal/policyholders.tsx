import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { SearchIcon } from 'lucide-react'
import { useState } from 'react'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { day } from '@/lib/format'

export const Route = createFileRoute('/_portal/policyholders')({
  loader: () => unwrap(api.policyholders.$get()),
  component: Policyholders,
})

type Policyholder = InferResponseType<typeof api.policyholders.$get, 200>[number]

const col = createColumnHelper<Features, Policyholder>()
const columns = col.columns([
  col.accessor('name', {
    header: 'Policyholder',
    cell: ({ row }) => (
      <>
        <div className="font-medium">{row.original.name}</div>
        <div className="text-xs text-muted-foreground">
          <span className="font-mono">{row.original.id}</span> · {row.original.email}
        </div>
      </>
    ),
  }),
  col.accessor('district', { header: 'District' }),
  col.accessor((holder) => holder.policies.length, {
    id: 'policies',
    header: 'Policies',
    cell: ({ row }) => (
      <div className="flex flex-wrap gap-1">
        {row.original.policies.map((policy) => (
          <Badge
            key={policy.id}
            variant="outline"
            title={`${policy.plan}: ${policy.property}`}
            className="font-mono"
          >
            {policy.id}
          </Badge>
        ))}
      </div>
    ),
  }),
  col.accessor('openClaims', { header: 'Open claims', meta: { className: 'tabular-nums' } }),
  col.accessor('customerSince', {
    header: 'Customer since',
    cell: ({ getValue }) => day.format(new Date(getValue())),
  }),
])

function Policyholders() {
  const policyholders = Route.useLoaderData()
  const [query, setQuery] = useState('')
  const needle = query.trim().toLowerCase()
  const matches = policyholders.filter((holder) =>
    [holder.name, holder.email, holder.id, ...holder.policies.map((p) => p.id)].some((field) =>
      field.toLowerCase().includes(needle),
    ),
  )

  return (
    <>
      <PageHeader
        title="Policyholders"
        description="Search by name, email, policyholder ID or policy number."
        actions={
          <div className="relative w-full sm:w-72">
            <SearchIcon className="absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search"
              aria-label="Search policyholders"
              className="bg-paper pl-8"
            />
          </div>
        }
      />
      <Card>
        <CardContent>
          <DataTable
            data={matches}
            columns={columns}
            empty={`No policyholder matches “${query}”.`}
            initialSort={[{ id: 'name', desc: false }]}
            filters={[needle]}
          />
        </CardContent>
      </Card>
    </>
  )
}
