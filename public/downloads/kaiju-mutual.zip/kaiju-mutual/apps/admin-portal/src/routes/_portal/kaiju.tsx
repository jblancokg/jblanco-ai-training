import { kaijuStatuses } from '@kaiju/api/enums'
import { createFileRoute } from '@tanstack/react-router'
import { createColumnHelper } from '@tanstack/react-table'
import type { InferResponseType } from 'hono/client'
import { api, unwrap } from '@/api'
import { DataTable, type Features } from '@/components/data-table'
import { PageHeader } from '@/components/page-header'
import { KaijuStatusBadge } from '@/components/threat-badge'
import { Card, CardContent, CardDescription, CardHeader } from '@/components/ui/card'
import { dateTime } from '@/lib/format'

export const Route = createFileRoute('/_portal/kaiju')({
  loader: () => unwrap(api.kaiju.$get()),
  component: KaijuStatusPage,
})

type Kaiju = InferResponseType<typeof api.kaiju.$get, 200>[number]

const col = createColumnHelper<Features, Kaiju>()
const columns = col.columns([
  col.accessor('name', {
    header: 'Kaiju',
    cell: ({ row }) => (
      <>
        <div className="font-semibold">{row.original.name}</div>
        <div className="text-xs text-muted-foreground">
          {row.original.class}, {row.original.heightM} m
        </div>
      </>
    ),
  }),
  // Sorts by severity, not alphabetically.
  col.accessor((k) => kaijuStatuses.indexOf(k.status), {
    id: 'status',
    header: 'Status',
    cell: ({ row }) => <KaijuStatusBadge status={row.original.status} />,
  }),
  col.accessor('location', { header: 'Where', meta: { className: 'whitespace-normal' } }),
  col.accessor((k) => k.heading ?? '', {
    id: 'heading',
    header: 'Heading',
    cell: ({ getValue }) => getValue() || <span className="text-muted-foreground">Stationary</span>,
  }),
  col.accessor('nearestDistrict', { header: 'Nearest district' }),
  col.accessor('lastSeen', {
    header: 'Last seen',
    meta: { className: 'tabular-nums' },
    cell: ({ getValue }) => dateTime.format(new Date(getValue())),
  }),
])

function KaijuStatusPage() {
  const kaiju = Route.useLoaderData()
  return (
    <>
      <PageHeader
        title="Kaiju status"
        description="Every kaiju we track, most worrying first. Positions come from the coastal watch."
      />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        {kaijuStatuses.toReversed().map((status) => (
          <Card key={status} size="sm">
            <CardHeader>
              <CardDescription>
                <KaijuStatusBadge status={status} />
              </CardDescription>
              <p className="text-3xl font-extrabold tabular-nums">
                {kaiju.filter((k) => k.status === status).length}
              </p>
            </CardHeader>
          </Card>
        ))}
      </div>
      <Card>
        <CardContent>
          <DataTable
            data={kaiju}
            columns={columns}
            empty="No kaiju tracked."
            initialSort={[{ id: 'status', desc: true }]}
          />
        </CardContent>
      </Card>
    </>
  )
}
