export const money = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
})

// Placeholder dates are plain `YYYY-MM-DD`, which JS parses as UTC midnight.
export const day = new Intl.DateTimeFormat('en-US', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  timeZone: 'UTC',
})

export const time = new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' })

// For local timestamps like `2026-09-29T09:10:00`. Don't pair `day` with `time`:
// `day` reads in UTC and can land on the wrong date.
export const dateTime = new Intl.DateTimeFormat('en-US', {
  day: 'numeric',
  month: 'short',
  hour: 'numeric',
  minute: '2-digit',
})
