// Fake sign-in: any email and password is accepted and the email is kept in
// localStorage. See docs/training/admin-portal.md.
const KEY = 'kaiju.email'

export type User = { email: string; name: string }

export function getUser(): User | null {
  const email = localStorage.getItem(KEY)
  if (!email) return null
  const local = email.split('@')[0] ?? email
  const name = local
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part[0]?.toUpperCase() + part.slice(1))
    .join(' ')
  return { email, name: name || email }
}

export function signIn(email: string) {
  localStorage.setItem(KEY, email.trim())
}

export function signOut() {
  localStorage.removeItem(KEY)
}
