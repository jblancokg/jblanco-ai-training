# Public website

The marketing site for Kaiju Mutual, at [apps/website](../../apps/website). It has no login and no data of its own. Its one job is to make a prospective customer want a quote and give them one on the spot.

## Goals

- Treat kaiju attacks the way a real insurer treats floods: calmly, specifically, with a straight face. The humour is in the sincerity, not in jokes.
- Look like a company you would trust with your house. The site should feel like a modern insurer with civil-defence roots, not a movie poster.
- One memorable moment: the hero on the home page is a 3D night-time city rendered with three.js in [KaijuScene.svelte](../../apps/website/src/lib/scene/KaijuScene.svelte). It plays a 30-second loop: the kaiju walks out of the fog down the avenue, flattens the buildings beside it, stops near the camera to roar, and the scene fades and resets. The timeline lives in [scene.ts](../../apps/website/src/lib/scene/scene.ts). Everything below the hero stays quiet.
- Work without the 3D: the page must read fine if WebGL is unavailable, and must not animate when the visitor prefers reduced motion.

## Pages

| Route | Job |
| --- | --- |
| `/` | Hero, what's covered, how a claim works, plans, current activity, FAQ |
| `/coverage` | What each plan covers and excludes |
| `/claims` | What to do during and after an attack, and how a claim is settled |
| `/about` | Who Kaiju Mutual is, with the figures that back it up |

"Sign in" links to the consumer portal (see [apps.md](apps.md) for where it runs). Getting a quote happens on the website itself; see below.

## Get a quote

Every "Get a quote" button opens [QuoteModal.svelte](../../apps/website/src/lib/components/QuoteModal.svelte) in place, so a visitor never leaves the page they were reading. The plan buttons preselect their plan, and the Municipal "Talk to us" button opens the same form with Municipal chosen. The visitor picks a plan and describes the property; every text field is required and marked with an asterisk. The modal sends that to the [API](api.md#endpoints) at `POST /api/quotes`. The API sets the price and the expiry, so the plan cards show a starting price ("from $48") and the quote can come out higher for a riskier district or property. The modal shows the quote it saved: the id to quote back to us, the monthly premium and the date the price runs out. When the call fails, the message carries the API's `requestId` so the customer can quote it to support.

The modal is a native `<dialog>`, so the browser owns the parts people expect: focus stays inside it, Escape closes it, and focus returns to the button that opened it. A click on the backdrop closes it too, the page behind it does not scroll, and open and close animations are off for anyone who prefers reduced motion.

While the form is open, what the visitor has typed is kept in the browser under one key, so closing the modal or reloading the page does not lose it. A quote that comes back clears the draft. The quote itself is never kept.

This is the one place the website calls the API. In dev the website proxies `/api` to the API the same way the portals do; see [apps.md](apps.md).

## Content

Copy and plan data live in [src/lib/content](../../apps/website/src/lib/content) so the pages stay layout-only. Photos for a planned gallery on the about page are in [src/lib/assets/gallery](../../apps/website/src/lib/assets/gallery), with who took each one and its licence in [CREDITS.md](../../apps/website/src/lib/assets/gallery/CREDITS.md). Nothing uses them yet. Kaiju activity on the home page is static sample data for now; a later exercise may move it to the API.

## The kaiju model

The kaiju is a low-poly model at [static/models/kaiju.glb](../../apps/website/static/models/kaiju.glb), generated in Blender by [tools/kaiju.py](../../apps/website/tools/kaiju.py). Re-run that script in Blender to rebuild the model rather than editing the GLB by hand. Body parts are named so the scene can animate the walk without a baked animation.
