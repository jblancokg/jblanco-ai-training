# Consumer portal

The customer's side of Kaiju Mutual, at [apps/consumer-portal](../../apps/consumer-portal). A policyholder signs in to see their cover, start and follow claims, and pay their premium.

## Goals

- Same voice as the [website](website.md): calm, specific, straight-faced. A portal you would trust during an evacuation.
- Same brand as the website (palette and typeface) so moving from the website's "Get a quote" to the portal feels like one company.
- Built from [shadcn/ui](https://ui.shadcn.com) components in [src/components/ui](../../apps/consumer-portal/src/components/ui), so trainees work with a component kit they are likely to meet on real projects.

## Sign in

Sign-in goes through the [API](api.md#consumer-session). The email has to belong to a policyholder in the database, and the password is ignored. Try `dana.okafor@example.com` from the seed data. The API remembers who signed in with a cookie, and every page behind sign-in asks the API who that is, so the portal never decides on its own whose data to show. See [auth.ts](../../apps/consumer-portal/src/auth.ts).

The password check is still fake, and so is the cookie: it holds the policyholder's id unsigned, so anyone can edit it to become someone else. A later exercise makes this real.

## Pages

| Route | Job |
| --- | --- |
| `/login` | Sign in |
| `/` | Overview: current threat level for your district, your policies, open claims, next payment |
| `/policies` | Each policy and what it covers |
| `/new-quote` | Get a quote for another property without leaving the portal |
| `/claims` | Claims you have made and where each one is |
| `/claims/new` | Start a claim (the website's "Start a claim" link lands here) |
| `/billing` | Upcoming and past payments, with a receipt for each one from the row's menu |
| `/profile` | Contact details and notification preferences |

## Get a quote

A policyholder can ask for a quote from inside the portal, at `/new-quote` ([new-quote.tsx](../../apps/consumer-portal/src/routes/_portal/new-quote.tsx)), with its own sidebar item. A prospect who isn't a policyholder yet gets one from the [website](website.md#get-a-quote) instead. The page uses [quote-form.tsx](../../apps/consumer-portal/src/components/quote-form.tsx), which sends the plan and the property to the [API](api.md#endpoints) through the typed client in [api.ts](../../apps/consumer-portal/src/api.ts). The API sets the price and the expiry, and the page shows the quote it saved: the id to quote back to us, the monthly premium and the date the price runs out. When the call fails, the message carries the API's `requestId` so the customer can quote it to support.

The portal fills in what it already knows: name and email from the profile, and the home district as a starting value. It leaves the property and address blank, because a new quote is usually for somewhere the existing policies don't cover. A quote from the portal is saved the same way as one from a prospect and isn't linked to the account.

## Start a claim

The claim form saves to the API, and the claim shows up straight away in the admin portal's claims queue at the `Reported` stage. The customer picks one of their own policies, what caused the damage from the perils that policy's plan covers, and the kaiju if they know it. Not knowing which kaiju is fine: staff match it later. The API sets the id, the stage and the reported date.

## Threat level

The overview's threat board shows today's level from the forecast for the policyholder's home district, and the kaiju driving it. The advice for each level is portal copy, in [threat-board.tsx](../../apps/consumer-portal/src/components/threat-board.tsx), because it is how we talk to customers, not data staff manage.

## What is real yet

Every page reads from the [API](api.md#consumer-endpoints), and only ever the signed-in policyholder's own rows. The quote form, the claim form and the profile save. The payment card is read-only: changing it is a phone call for now.
