# Workspace

Work inside herdr with one workspace for this repo and at least two panes:

- **Servers**: runs every app at once, using the `dev` script in the root [package.json](../../../package.json). Leave it running.
- **Agent**: your AI agent, started from the repo root.

Start the servers pane only after the workspace dependencies are installed, the API knows where the outside vendors are (see [apps.md](../apps.md#outside-services)) and the database is set up. A fresh clone has an empty database, so the portals have nothing to show until you create the tables and load the sample data:

```sh
bun run --filter @kaiju/api db:migrate
bun run --filter @kaiju/api db:seed
```

Run `db:migrate` again after pulling a change that adds a migration. Run `db:seed` whenever you want the sample data back; it replaces whatever is there. See [api.md](../api.md#local-database) for more.

The agent can read the servers pane to see logs and errors, so paste only what it can't see there.
