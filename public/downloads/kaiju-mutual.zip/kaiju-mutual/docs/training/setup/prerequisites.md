# Prerequisites

Install these tools before starting. Each one lists how to check that it installed correctly.

## Bun

Runtime and package manager for the whole repo. Bun installs the dependencies for every app in one go from the repo root.

```sh
curl -fsSL https://bun.sh/install | bash   # or: brew install oven-sh/bun/bun
bun --version
```

## herdr

A terminal multiplexer for AI agents. You run the apps and your agent side by side in herdr, and the agent can read the other panes, such as server logs. See [workspace.md](workspace.md) for the layout.

```sh
curl -fsSL https://herdr.dev/install.sh | sh   # or: brew install herdr
herdr --version
```

Then install the integration for your agent so herdr can show whether it's working, blocked or done:

```sh
herdr integration install claude   # or codex, cursor, opencode, ...
```

## agent-browser

A browser the agent can drive: open pages, click, take screenshots. The agent uses it to check the apps in a real browser.

```sh
brew install agent-browser   # or: npm install -g agent-browser
agent-browser install        # downloads the Chrome build it drives
```

The agent can learn the tool from `agent-browser skills get core`.
