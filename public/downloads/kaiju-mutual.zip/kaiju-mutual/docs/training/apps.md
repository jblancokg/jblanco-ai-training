# Apps

Where each app runs locally once the servers are up.

| App | URL |
| --- | --- |
| Public website | http://localhost:5173 |
| Consumer portal | http://localhost:5174 |
| Admin portal | http://localhost:5175 |
| API | http://localhost:3000/api/health |

The portals call the API through `/api` on their own origin, so the API has to be running for them to load data. The website does the same for its quote modal.

## Outside services

Kaiju Mutual works with outside vendors. They aren't part of this repo and don't run on your machine: you reach them over the internet.

| Vendor | What for | URL |
| --- | --- | --- |
| Tidewatch | Kaiju monitoring feed | https://tidewatch.konrad.dev |
| Coinpurse | Card payments | https://coinpurse.konrad.dev |
| Skyreach Surveys | Drone damage surveys | https://skyreach-api.konrad.dev |

The API reads kaiju watch data from Tidewatch, so it needs Tidewatch's address and key. Copy [apps/api/.env.example](../../apps/api/.env.example) to `apps/api/.env` before starting the servers; it already holds the right values. Without it the API still starts, but kaiju watch shows only the sample data and the API logs a warning.

## Changing a port

The ports in the first table are defaults. If one clashes with something else on your machine, copy that app's `.env.example` to `.env` in the same folder and change `PORT`. Each `.env.example` lists every variable the app reads.

If you move the API, set `API_URL` in both portals' `.env` and the website's so their `/api` proxy follows it.

If you move the consumer portal, set `PUBLIC_CONSUMER_PORTAL_URL` in the website's `.env` so its "Sign in" and "Start a claim" links follow it.
