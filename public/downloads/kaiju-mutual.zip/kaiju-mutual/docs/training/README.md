# Training docs

Material that ships to trainees: what Kaiju Mutual is, how the apps fit together, and how to work on them.

- [setup/prerequisites.md](setup/prerequisites.md): tools to install
- [setup/workspace.md](setup/workspace.md): how to lay out your terminal
- [apps.md](apps.md): where each app runs
- [website.md](website.md): what the public website is for and how it is built
- [consumer-portal.md](consumer-portal.md): what the consumer portal is for and what is real yet
- [admin-portal.md](admin-portal.md): what the admin portal is for and what is real yet
- [api.md](api.md): what data the API holds and how to set up the local database

## The company

Kaiju Mutual insures policyholders against kaiju attacks. Its software has four parts:

| App | Who uses it | Code |
| --- | --- | --- |
| Public website | Prospective customers | [apps/website](../../apps/website) |
| Consumer portal | Policyholders | [apps/consumer-portal](../../apps/consumer-portal) |
| Admin portal | Kaiju Mutual staff | [apps/admin-portal](../../apps/admin-portal) |
| API | Backs both portals | [apps/api](../../apps/api) |

The API also talks to outside vendors, such as a kaiju monitoring feed. [apps.md](apps.md#outside-services) lists them.
