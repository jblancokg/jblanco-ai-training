# Admin portal

Kaiju Mutual staff use this side, at [apps/admin-portal](../../apps/admin-portal). Claims handlers sign in to work the claims queue, look up policyholders and policies, and keep an eye on the kaiju that drive the next wave of claims.

## Goals

- A working tool, not a brochure. Dense tables and short labels beat the [consumer portal](consumer-portal.md)'s reassuring copy. Staff are here all day.
- Every table can be sorted and is paged, so pages stay usable when the data grows from a demo-sized seed to thousands of rows. They all use one table component ([data-table.tsx](../../apps/admin-portal/src/components/data-table.tsx)).
- Same brand and component kit as the consumer portal ([shadcn/ui](https://ui.shadcn.com) in [src/components/ui](../../apps/admin-portal/src/components/ui)), so a trainee who learned one portal can find their way around the other.
- Each portal keeps its own copy of the components and theme rather than a shared package. shadcn is built around owning the copy, and the two portals will drift in what they need.

## Sign in

Sign-in is fake for now, the same as the consumer portal. Any email and password gets you in. See [auth.ts](../../apps/admin-portal/src/auth.ts).

## Pages

The nav is grouped by the job at hand.

### Claims handling

| Route | Job |
| --- | --- |
| `/login` | Staff sign in |
| `/` | Overview: queue totals and claims waiting on staff |
| `/claims` | The claims queue across all policyholders. Open a claim to assign a handler, move it to the next stage or change the estimate |
| `/policies` | Every policy, filterable by plan and status |
| `/policyholders` | Look up a policyholder and their policies |
| `/quotes` | Quotes customers got from the website, including withdrawn ones. Staff can withdraw a quote |

### Kaiju watch

| Route | Job |
| --- | --- |
| `/kaiju` | Every tracked kaiju: class, where it is, what it's doing |
| `/forecast` | Threat level per district for the next seven days, and which kaiju drives it |
| `/municipal` | Expected loss on insured municipal assets, from each district's worst forecast day |
| `/events` | History of kaiju events (sightings, landfalls, containments, threat level changes) and the claims each one caused |

Kaiju watch is read-only. Staff watch kaiju, they don't move them. The data comes from Tidewatch, a kaiju monitoring feed; see [api.md](api.md#kaiju-watch-feed).

The API works out the municipal estimate: the insured value times a damage ratio for the threat level. The ratios live in [routes/municipal.ts](../../apps/api/src/routes/municipal.ts), so a change to the forecast shows up in the estimates.

### Reference lists

The lists that feed dropdowns and labels elsewhere: regions, districts, kaiju classes, perils, plans and claim handlers, under `/reference/*`. Each one is a plain table with add, edit and delete, built on one shared component ([list-manager.tsx](../../apps/admin-portal/src/components/list-manager.tsx)). Renaming an entry renames it everywhere it's used, and the dropdowns on other pages pick up changes straight away.

## What is real yet

Every page reads from and writes to the [API](api.md). There is no placeholder data left in the portal. Sign-in is still fake, so the API doesn't know which staff member made a change.
