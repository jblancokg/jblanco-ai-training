# API

The backend for both portals, at [apps/api](../../apps/api). Both portals use it for everything. The website calls it for one thing: a quote.

## Data

Tables live in [schema.ts](../../apps/api/src/db/schema.ts). Field names are the ones the portals show, so a page uses API rows as they come.

Every table has `createdAt`, `updatedAt` and `deletedAt`. Rows are never deleted. Setting `deletedAt` hides a row, so staff can still see what a customer was quoted after the quote was withdrawn, and reads must skip rows where `deletedAt` is set.

The tables fall into four groups, matching the [admin portal](admin-portal.md#pages):

- **Reference lists**: regions, districts, kaiju classes, perils, plans and claim handlers.
- **Claims handling**: policyholders, policies, claims and payments. A policyholder also holds their contact details, their notification choices and the card premiums are taken from. What each plan covers, and up to what limit, is a list per plan.
- **Kaiju watch**: kaiju, the seven-day forecast per district, kaiju events and insured municipal assets.
- **Quotes**, below.

Other tables point at a reference list entry, or a kaiju, by its name, not an id, so a row reads the same in the database as on screen. Names are unique, and renaming an entry updates every row that uses it. Policyholders, policies, claims and events have their own ids, and rows point at them by id.

A claim can be linked to the kaiju event that caused it. The events page counts those claims and adds up what was paid on them, so the totals always match the claims.

Lists the code checks against, such as claim stages and threat levels, are in [enums.ts](../../apps/api/src/enums.ts). The portals import them from there, so a new stage only has to be added once.

### Quotes

A quote is a price for one property on one plan, given to someone who isn't a policyholder yet. It holds who asked, what they want covered, the monthly premium in whole dollars, and the date the price stops being valid. It doesn't record whether the person bought the policy.

The plan names and districts match the portals: `Household`, `Business` or `Municipal`, and a district name such as `Lower Cheswick`.

#### Endpoints

The quote routes live in [routes/quotes.ts](../../apps/api/src/routes/quotes.ts), mounted under `/api/quotes`. The [website's quote modal](website.md#get-a-quote) creates quotes, and the admin portal lists and withdraws them.

- `POST /api/quotes` takes only the customer's details: plan, name, email, property, address and district. It returns the saved quote with its id, price and expiry.
- The server sets the price and the expiry. A client can't choose its own premium or keep a price valid forever. A quote is valid for 30 days.
- The price comes from the rating engine, [legacy/rating-engine.js](../../apps/api/src/legacy/rating-engine.js): a base rate for the plan, adjusted for the district's risk and for what the property is. Household and Business never go below the starting prices on the [website](website.md), which lists Municipal as quoted. The engine predates this codebase and is due a rewrite, so it's kept apart and the linter skips it.
- The id and the timestamps are defaults in [schema.ts](../../apps/api/src/db/schema.ts), so a client can't forge or reuse an id. Ids are `QT-` and a short random code that's easy to read back over the phone; the seed data keeps older six-digit ids to show the format isn't enforced.
- `GET /api/quotes` lists live quotes. `?withdrawn=true` includes withdrawn ones, so staff can see what a customer was offered.
- `DELETE /api/quotes/:id` withdraws a quote by setting `deletedAt`.
- A quote can't be changed. A customer who wants a different price gets a new quote.

Bodies are validated with `zod`, so a plan outside [`planNames`](../../apps/api/src/enums.ts) or a blank field is a 400. Every error response carries the `requestId`, and every new quote logs one line with the `quoteId`, so a customer's report can be matched to the log without logging names or emails.

## Endpoints

Each group has its own file in [routes/](../../apps/api/src/routes), and [app.ts](../../apps/api/src/app.ts) mounts them under `/api`. These routes are built for what the admin portal's pages need; the consumer portal has [its own](#consumer-endpoints):

- Reference lists each have list, add, edit and delete.
- Claims can be listed and changed: the handler, the stage, the estimate and the customer note. Policies and policyholders are read-only.
- Kaiju watch is read-only.

Responses use the same field names as the database, plus whatever a page needs from related rows, such as the policyholder's name on a claim. Errors follow the same rules as quotes: invalid input is a 400, no session is a 401, a missing row is a 404, a name that's already taken is a 409, and every error carries the `requestId`.

## Kaiju watch feed

Kaiju, forecasts and kaiju events come from Tidewatch, an outside kaiju monitoring service. The API copies Tidewatch's data into the database when it starts and then every few minutes, and the portals read the copy. If Tidewatch is down, the portals show the last copy instead of failing. The sync is in [tidewatch.ts](../../apps/api/src/tidewatch.ts).

- Kaiju, forecasts and events sync separately, so one failing doesn't hold up the others.
- Tidewatch names districts by their code, and the sync matches them to ours. It doesn't classify kaiju, so the sync picks the class whose height range fits from the kaiju classes list.
- Rows Tidewatch no longer sends are left alone, so seeded and older rows stay.
- Only rows that changed are written, and each change logs the id and the fields that changed. A row that can't be matched, such as a district code we don't have, is skipped with a warning.
- Every call to Tidewatch logs its `X-Trace-Id`, so a failure can be reported to Tidewatch with an ID they can look up.
- The seed holds a copy of the feed, so the portals have data before the first sync.

`TIDEWATCH_URL`, `TIDEWATCH_API_KEY` and `TIDEWATCH_SYNC_MINUTES` in [.env.example](../../apps/api/.env.example) control it. The URL and key have no default: without them the API skips the sync, logs a warning and the portals show the seeded data.

## Consumer session

The consumer portal signs in with `POST /api/session` and an email. If a policyholder has that email, the API sets a cookie with their id. `DELETE /api/session` signs out. Routes are in [routes/session.ts](../../apps/api/src/routes/session.ts).

This is deliberately thin: no password check and an unsigned cookie. It exists so the API, not the browser, decides whose rows a request may see. A missing or unknown cookie is a 401.

## Consumer endpoints

Everything for the signed-in policyholder lives under `/api/me`, in [routes/me.ts](../../apps/api/src/routes/me.ts). Every query is scoped to the policyholder from the cookie, so there is no way to ask for someone else's policy or claim by id. A policy or claim that exists but isn't theirs is a 404, the same as one that doesn't exist.

- `GET /api/me` returns the profile: contact details, notification choices and the payment card (brand, last four digits and expiry, never a full number).
- `PATCH /api/me` changes contact details and notification choices. Sign-in finds people by email, so an email another policyholder already uses is a 409.
- `GET /api/me/policies` lists their policies, each with what its plan covers.
- `GET /api/me/claims` lists their claims, newest first. `POST /api/me/claims` starts one on one of their policies, for a peril that policy's plan covers ([`plansCovered`](../../apps/api/src/enums.ts)). The kaiju and the date it happened are optional. The server sets the id, the `Reported` stage, the reported date and an estimate of zero.
- `GET /api/me/payments` lists their payments, newest first.
- `GET /api/me/district` returns today's forecast level for their home district and the kaiju driving it.

A claim carries a `note`: the latest update in words a customer reads, such as when the assessor is booked. Staff set it with the claim's other changes. It's free text, so the log records that it changed, not what it says.

## Logging

The API logs a lot, on purpose. Trainees debug from these logs, so a request should be traceable from start to finish. Logging uses [pino](https://getpino.io), set up in [log.ts](../../apps/api/src/log.ts).

- One JSON object per line, to stdout, and also to `LOG_FILE` if it's set. `LOG_LEVEL` picks how much: `debug` (the default) also logs every SQL statement and what each route read.
- Every line logged during a request carries its `requestId`, including the SQL ones.
- Each change logs the ids it touched and which fields changed. A rejected request logs why it was rejected.
- Logs never hold request bodies, query parameters bound to SQL, names, emails or addresses. pino redacts those fields if one slips through.

## Local database

The database is a SQLite file, `apps/api/kaiju.db`. It's gitignored, so every clone starts with an empty one. The scripts in [package.json](../../apps/api/package.json) create the tables and fill them:

- `db:migrate` applies the migrations in [drizzle/](../../apps/api/drizzle)
- `db:seed` replaces the rows with the sample data in [seed.ts](../../apps/api/src/db/seed.ts)
- `db:generate --name <what_it_does>` writes a new migration after a change to `schema.ts`, e.g. `--name add_policies`. Name each migration for what it changes, because drizzle-kit otherwise picks a random name. Commit the migration and the `meta/` folder with the schema change.
