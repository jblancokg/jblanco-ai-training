# Docs

Kaiju Mutual is a training platform for learning to work with AI agents, built around a fake insurer that covers kaiju attacks.

- [training/](training/README.md): written for trainees working in this repo.
